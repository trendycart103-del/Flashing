# FlashForge UI Upgrade v1.20

## এই আপডেটে
- প্রধান অ্যাকশন বাটনে press-scale/bounce animation, pressed-state translation, metallic dual-edge border এবং deeper elevation যোগ করা হয়েছে।
- ActionTile/quick-action এবং bottom navigation item-এ একই premium beveled visual language প্রয়োগ করা হয়েছে।
- আইকনের চারপাশে glossy beveled tile, metallic edge এবং elevation যোগ করা হয়েছে যাতে বিদ্যমান vector icon-গুলো আরও dimensional দেখায়।
- App background-এ deep-navy gaming atmosphere, subtle steel gear linework এবং restrained cyan circuit accents যোগ করা হয়েছে।
- Gear/circuit artwork low-opacity রাখা হয়েছে এবং opaque UI cards-এর পেছনে থাকে, যাতে লেখা ও control-এর contrast বজায় থাকে।

## সীমাবদ্ধতা / যাচাই
- এই সংস্করণে নতুন raster 3D wallpaper তৈরি বা যোগ করা হয়নি; image-generation সুবিধা সাময়িকভাবে সীমাবদ্ধ থাকায় background-টি native Compose Canvas দিয়ে আঁকা হয়েছে।
- বিদ্যমান কার্যকারিতা, device database, navigation এবং flashing workflow ইচ্ছাকৃতভাবে পরিবর্তন করা হয়নি।
- এই পরিবেশে Gradle executable/wrapper নেই, তাই Android build চালিয়ে compile verification করা সম্ভব হয়নি। Android Studio-তে Sync ও Build করে চূড়ান্ত যাচাই করতে হবে।
