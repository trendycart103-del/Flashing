# v1.28 – UI Stage 2
- Added 25 user-reference 3D PNG icons.
- Redesigned navigation tabs with glossy purple 3D tiles.
- Rebuilt shared device-mode wheel as five radial action sectors.
- Restyled Flash tools dashboard with matching 3D icons and tiles.
- Added eight ROM & Root launch tiles; unsupported tools remain non-executing placeholders.
- Added four persistent built-in visual themes.
- Preserved existing device detection, flashing and safety workflows.
- Android compile/device runtime verification pending: Gradle and Android SDK unavailable in the build environment.
