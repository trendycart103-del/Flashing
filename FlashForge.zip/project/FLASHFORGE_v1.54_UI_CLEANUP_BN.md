# FlashForge v1.54 — UI Cleanup (বাংলা)

## এই আপডেটে
- Flash/ROM/Device-এর circular action wheel-এর ওপর ভেসে থাকা Flash Workflow hero panel সরানো হয়েছে।
- Action wheel এখন নিজস্ব জায়গায় থাকে; পেজের নির্দেশনা আর wheel-এর ওপর overlay হয় না।
- Flash page-এর পাঁচটি section plain text tab থেকে icon-সহ দৃশ্যমান strong segmented controls-এ রূপান্তর করা হয়েছে।
- Flash style selector ও selected/total queue count বড় banner নয়; Flash page-এর ভেতরে এক লাইনের compact control strip।
- সাধারণ Panel-এর content আর collapse/hidden হয় না; panel header এখন section heading, প্রয়োজনীয় controls সবসময় প্রসারিত থাকে।
- Panel-এর ভিতরের বিদ্যমান Btn/ConfirmBtn-এর bold label ও 3D gradient style বজায় আছে।
- 3D circular action wheel এবং supplied icon assets অপরিবর্তিত।
- Version: 1.54, versionCode: 23।

## পরীক্ষা ও সীমাবদ্ধতা
- ZIP integrity এবং source-level smoke checks চালানো হয়েছে।
- এই পরিবেশে Android SDK/Gradle build চালানো যায়নি; GitHub Actions-এ assembleDebug, lint ও unit test সফল হয়েছে—এমন দাবি করা হচ্ছে না।
- বাস্তব Android ফোনে layout/scroll পরীক্ষা প্রয়োজন। সব panel expanded হওয়ায় কিছু পেজে বেশি vertical scrolling লাগতে পারে; তবে গুরুত্বপূর্ণ control আর collapsed header-এর আড়ালে থাকবে না।
