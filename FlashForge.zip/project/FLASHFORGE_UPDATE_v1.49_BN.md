# FlashForge v1.49 — Update Summary (Bangla)

- Device Page Circle Menu-এর আকার কমানো হয়েছে, যাতে Mode Entry Guide ও Device তথ্যের জন্য বেশি জায়গা থাকে।
- ROM & Root-এর ROM tab-এ পুরোনো Image Flash Queue UI পুনরুদ্ধার করা হয়েছে।
- Log Page-এর floating USB EVENT LOG action panel সরানো হয়েছে; Save, Copy, Filter, Export ও Clear controls সরাসরি Log Page-এ রাখা হয়েছে।
- Safety Page-এ প্রধান safety status ও acknowledgement controls সামনে রাখা হয়েছে এবং Read More/Read Less দিয়ে বিস্তারিত expandable করা হয়েছে।
- ROM Queue Circle Menu hub-কে ROM QUEUE action হিসেবে সাজানো হয়েছে।
- Version Name 1.49, Version Code 16 এবং UI Layout ID V149 করা হয়েছে।
- GitHub Actions workflow-তে Android SDK setup ও Gradle 8.7 build verification ধাপ গুছানো হয়েছে।

## Verification

Local compile/APK build এই environment-এ করা যায়নি, কারণ Gradle executable এবং Android SDK install নেই। GitHub Actions workflow-তে `testDebugUnitTest`, `lintDebug` ও `assembleDebug` চালানোর ব্যবস্থা রয়েছে।

## Included UI and navigation changes

- Log page actions (Save, Copy, Filter, Export, Clear) are directly on the Log page; the former floating USB EVENT LOG action panel is no longer shown.
- Safety page primary actions (acknowledge, clear acknowledgement, open ROM queue, resume interrupted flash when available) are visible before Read More. Detailed trust, queue, controller health, analyzer, recovery, and decision information expands below.
- ROM tab restores the queue UI from the prior v1.48 ZIP; image, ZIP unpack, manual vbmeta, partition selection, per-file verification, individual flash, and selected-queue flash controls remain wired to the existing MainVM.
- ROM, Root, Unlock, Partition, Device, Log, Safety and Flash content use a bounded page area with scrolling only for overflow.

## Files updated

- `app/src/main/java/com/flashforge/Pages.kt`
- `app/src/main/java/com/flashforge/GamingUi.kt`
- `app/src/main/java/com/flashforge/Ui.kt`
- `app/build.gradle.kts`
- `.github/workflows/build.yml`

## Local verification status

- Kotlin parser check: no syntax errors reported for the edited Kotlin files.
- Full Android Gradle compile, lint, unit tests and APK build: not run locally because this environment does not have Gradle or the Android SDK installed. GitHub Actions is configured to run these checks and upload the debug APK/reports.
- ZIP integrity: to be checked on final archive.
