# FlashForge v1.55 — Visible Controls UI Update

This source update keeps the existing device, flash, ROM/root, reset, chipset, backup, log, safety, settings and about workflows. It makes Safety details and Advanced Settings permanently visible, converts the Flash engine style selector to a wrapped visible grid, makes all five top navigation destinations fit without horizontal clipping, and makes About/Settings content vertically scrollable on smaller phones. Destructive actions still use explicit confirmation dialogs by design.

# FlashForge v1.54

UI cleanup update: removed the floating hero overlay above the circular action wheel, made Flash section navigation prominent, compacted the flash-style selector into the Flash page, and made Panel content permanently visible instead of collapsible. The circular wheel and supplied icon assets are preserved.

FlashForge v1.53.1: Settings/About are header-only actions; Reset & Repair now exposes a guarded Factory Reset (userdata + metadata) action. See FLASHFORGE_UI_CORRECTION_v1.53.1_BN.md.

# FlashForge v1.53 — UI Organization & Clutter Reduction (2026-11-25)

This update keeps the existing 3D neon design and all feature pages while simplifying the main navigation to seven primary tabs. Reset & Repair, Chipset Service and Backup & Restore remain available through visible contextual shortcuts. The oversized Flash banner and persistent bottom log sentence have been replaced/removed to reduce screen clutter. See `FLASHFORGE_UI_ORGANIZATION_v1.53_BN.md` for details and validation limits.

---

# FlashForge v1.52 — UI Organization Update (2026-11-24)

This update reorganizes the existing workflow without replacing the established 3D design:
- Device identity and the current-mode guide are consolidated on DEVICE; GPS/location is not used for USB device identification.
- Firmware Sites now appears only in its own FLASH tab.
- Firmware image selection, ZIP extraction, partition mapping, SHA-256 verification and flash queue are grouped under FLASH > QUEUE instead of being split into ROM & ROOT.
- ROM & ROOT retains Unlock, Custom ROM, Root and Partition tools; the duplicate queue panel is removed.
- The extra duplicate Device-page Fastboot status panel is removed. Existing 10 pages, theme, wheel and icon assets remain.
- Version 1.52 / versionCode 19. Gradle build and hardware validation still require GitHub Actions and a real test device.

See `FLASHFORGE_UI_ORGANIZATION_v1.52_BN.md` for the change report.

---

# FlashForge v1.51 — Smart Connectivity Update (2026-11-24)

This section supersedes earlier version-status summaries below. See `FLASHFORGE_UPDATE_v1.51_BN.md` for the Bengali audit and complete limitations.

- Automatic pre-flash backup is enabled by default for normal Fastboot image writes. It re-hashes the selected image, attempts a verified `fastboot fetch` backup of the target partition, and stops the write if that backup cannot be completed. It can be disabled explicitly for ordinary flash operations; Device-Compatible Clean Flash always requires backups.
- Device-Compatible Clean Flash requires explicit confirmation, exact product/OEM identity, acknowledged Safety Analyzer warnings, a fully mapped and checksum-verified `.img` queue, target backups, then userdata erase and conditional metadata erase. It is not universal and does not erase protected calibration/identity partitions.
- Android 10+ firmware downloads are copied to public `Downloads/FlashForge` using MediaStore; the private Firmware Library copy remains. Existing files can be selected from public storage with the document picker.
- USB mode navigation routes Fastboot with verified OEM identity to Flash, ADB to ROM & ROOT, and chipset/download modes to Chipset. Exact model identity still depends on available descriptors, bootloader data and database coverage.
- Qualcomm, MediaTek, Samsung and Unisoc write engines remain disabled/detection-only. FRP bypass and security bypass are not implemented.
- GitHub Actions accepts exactly one root ZIP, extracts the project, runs tests/lint/debug APK build, and uploads available artifacts. The workflow must already exist in the repository to react to a ZIP upload.
- Build and physical device tests were not run in this editing environment because Android SDK/Gradle and test hardware are unavailable. CI must pass before release.

---

# FlashForge v1.42 — Current Status (2026-11-21)

This section supersedes older status statements in this README and historical audit reports.

- Logical partition operations are exposed as guarded Fastbootd controls. CREATE/RESIZE require a positive byte size; DELETE requires a verified existing logical partition. Exact identity, OEM confidence, controller battery, Fastbootd and `super` size checks are required. Dynamic-partition group limits are still OEM/bootloader-enforced and cannot be fully inferred by this generic app.
- Firmware download partials are retained in a URL-specific partial file and resumed with HTTP Range only when the server returns a valid `206 Content-Range`; otherwise the download restarts from zero.
- Backup restore is available only for app-created image/metadata pairs and checks product, size and SHA-256 before the standard flash gate.
- Interrupted flash recovery restarts the interrupted image from byte zero after revalidation; completed queue items are not automatically replayed.
- The experimental FlashReadinessAudit module and its test/report were removed; it was analysis-only and not part of the application feature set.
- Device database: 18 USB vendor IDs, 34 model/codename profiles, 22 firmware-link groups. These are profiles, not complete region/variant/firmware coverage. Exact SKU and release compatibility must still be verified.

---

# FlashForge — Safety Remediation Build

This is an update of the supplied FlashForge Android Studio project, not a replacement application. The original package/application ID (`com.flashforge`), Kotlin/Compose architecture, device database, navigation, theme, and existing pages are retained.

## Main safety changes

- Every image write path (`Flash Queue`, Recovery Image, and patched Boot Image) reaches `MainVM.executeVerifiedFlash()` and then the only USB write entry point, `Fastboot.flash()`.
- `Fastboot.flash()` invokes the mandatory authorization callback before `download:` and verifies the bytes again while streaming. A raw `flash:` command is rejected by `Fastboot.cmd()`; raw `download:` and unreviewed Fastboot commands are rejected as well.
- The pre-flash gate re-reads the live product ID, requires the user-confirmed expected product ID, publisher-provided SHA-256, controller-phone battery >= 40%, current slot layout, `has-slot`, logical/physical partition status, and the bootloader-reported partition size. The Safety Analyzer page shows the actual latest check results and warning details.
- Non-critical unresolved warnings (publisher checksum source authenticity and unavailable universal hardware-variant/build proof) remain visibly `WARNING`; the user must explicitly acknowledge them for the current device session before the first image write. Acknowledgement never changes the result to PASS, and critical failures remain BLOCKED.
- Android sparse images are parsed for their expanded footprint before partition-capacity comparison. Malformed or unsupported sparse structures are blocked.
- A queue item must have an explicit partition. Partition names are never inferred from filenames. The UI exposes a partition field for each queue item and for standalone recovery/boot images. The Fastboot image path accepts `.img` only; ZIPs must be unpacked first and other formats require a reviewed parser.
- Standalone Recovery and patched Boot image paths now have their own publisher-checksum verification control. Missing or mismatched checksums block the write.
- Logical partition CREATE/RESIZE/DELETE are available only through explicit confirmation in verified Fastbootd with exact product/OEM and battery checks. Fastbootd must report a valid `super` size and logical partition state; group capacity/geometry is not exposed by every OEM, so the bootloader may reject an operation. This is a high-risk tool and requires an OEM recovery path. Bootloader locking and automatic vbmeta modification remain disabled. A manual vbmeta image can be queued only by explicit selection and must pass the same checksum and device/partition Safety Analyzer; the app does not patch vbmeta.
- Erase, wipe, unlock, and slot modification are protected by a command-level authorization callback. The generic Fastboot command interface allows only reviewed read-only/reboot commands or specifically authorized destructive commands.
- Wipe stops immediately if userdata erase fails; metadata erase is not attempted after a failure.
- USB transfer errors, zero-byte reads, malformed responses, and timeouts mark the Fastboot protocol state uncertain. The connection is invalidated and must be re-detected; destructive operations are never automatically retried.
- Operation state is journaled in app preferences. If the app restarts with an operation still marked RUNNING, it is recorded as INTERRUPTED and the app instructs the operator not to retry automatically.
- Firmware ZIP extraction is staged and committed only after the entire archive has been read successfully. Failed extraction does not add partial images to the queue.
- HTTPS downloads reject redirects to non-HTTPS URLs, validate declared total size and received bytes, and retain a `.partial` file for HTTP Range resume when the server supports it. If Range is not supported, the download safely restarts from byte zero.
- Backup uses a temporary file, checks the bootloader-reported partition size and available storage, computes SHA-256, writes metadata, and refuses overwrite.
- ADB sideload requires the ADB USB interface and a Recovery/Sideload banner (normal Android ADB `device` state is blocked), requires a publisher SHA-256, stages the package in private app cache before protocol negotiation, checks package size, and accepts recovery block requests in any order (as real recoveries issue them) and re-hashes the staged package after the transfer. Recovery ADB product/hardware identity is not yet queried by this transport; package/device compatibility must be checked against OEM instructions.

## Important operator workflow

1. Connect the target phone in Fastboot mode and select **RECONNECT USB** if the link has been invalidated.
2. Confirm the detected product ID using the Model Guard. Do not copy a product ID from a similar model.
3. Add the image or select a Recovery/Boot image.
4. Enter the exact target partition manually.
5. Obtain the expected SHA-256 from a trusted OEM or independently verified source and run **VERIFY SHA-256**.
6. Open the Safety Analyzer page, read the unresolved warnings, and explicitly acknowledge them for this device session. Critical failures cannot be acknowledged away.
7. Run the flash action. The checks are repeated at the USB transport boundary immediately before download and the transfer is hashed again.
8. If USB fails during a flash, reconnect and identify the device. Resume re-hashes and re-runs the safety checks, then restarts the interrupted current image from byte zero; it does not resume at an arbitrary USB byte offset or replay completed images.

A PASS means the checks implemented by this build passed. It is not a guarantee against unknown hardware, firmware, bootloader, or vendor-specific behavior.

## Build environment and validation

- Android namespace/application ID: `com.flashforge`
- `compileSdk`: 34
- Android Gradle Plugin: 8.5.2 (Gradle 8.7 is the matching distribution)
- Kotlin Gradle plugin: 1.9.24
- Java target: 17

The supplied project does not include `gradlew`, `gradle/wrapper/gradle-wrapper.jar`, or a Gradle wrapper distribution. The current editing environment also has no installed Gradle executable or Android SDK. Therefore `clean`, `assembleDebug`, `test`, and `lint` were **not run successfully** and no APK is included. Open the project in Android Studio with the matching Android SDK and Gradle installation, sync, then run:

```bash
gradle clean assembleDebug test lint
```

Do not perform destructive tests on a personal phone. Start with mock tests and non-destructive device identification on an explicitly authorized test device.

## Known incomplete features

- No physical USB/Fastboot device testing has been performed in this environment.
- ADB Recovery Sideload needs validation against actual supported recoveries; ADB AUTH/key authorization is not implemented, and transport completion is not the same as confirmed installation success.
- Backup creation is available only when the bootloader supports `fetch`. Restore is available for app-created backups with metadata, matching product ID, exact size and SHA-256; the restore still passes the standard flash safety gate.
- Firmware download resume uses HTTP Range when the server supports it; unsupported Range responses cause a safe restart.
- Full firmware package metadata parsing (build/region/CSC/device compatibility) is incomplete; product ID, checksum, slot, partition type, and size gates are implemented.
- Qualcomm EDL/Sahara/Firehose, MediaTek BROM/DA, Samsung Download Mode flashing, and Unisoc FDL write protocols are not implemented. Detection must not be treated as flash support.
- Bootloader relocking and automatic vbmeta patching are intentionally blocked. Logical partition operations require Fastbootd, exact identity and explicit confirmation; generic super-group capacity cannot be proven on every OEM.
- Interrupted image resume restarts the current image from byte zero after fresh safety checks; no arbitrary byte-offset resume, automatic retry or automatic reboot is performed.

See `TECHNICAL_AUDIT_AND_CHANGELOG_BN.md` for the Bengali audit, changed files, validation details, and remaining risks.

## Latest UI update
- Home header logo: slowly auto-rotating gear inside a rounded-square tile.
- Bottom tab labels centered under their icons (tabs spread evenly when they fit the screen).
- Top-right link pill reads "NOT CONNECTED" when no device is linked.
- Button audit: downloaded-files list now refreshes after delete; EXPORT in Log now also opens the share sheet.

## Latest fixes (code review pass)
- USB permission: pressing **Deny** no longer re-opens the dialog in a loop. Permission is asked again only after a re-plug or the RECONNECT button. Unplugging while the dialog is open clears the pending state.
- Device selection: with several USB devices attached, the already-connected device is kept, otherwise one in a recognised mode (Fastboot/ADB/...) is preferred over unrelated devices.
- ADB sideload: recovery block requests are served in any order (real recoveries read the ZIP non-sequentially); integrity is checked by re-hashing the staged package after the transfer. Previously the first non-sequential request aborted every sideload.
- `Fastboot.fetch()` validates the partition name at the transport boundary; `backup()` no longer shadows a variable.
- An interrupted read-only operation (connect, refresh, hash, download, unpack, backup) at app restart is logged but no longer forces the Safety Analyzer to BLOCKED.
- Not changed / still open: no Gradle wrapper and no build or hardware test could be run in this environment.

## Tab layout change
- The former UNLOCK, CUSTOM ROM and ROOT tabs are merged into one **ROM & Root** tab (8 tabs instead of 10).
- The page opens with a small status strip (mode, bootloader, model guard, warnings) and a three-button tab strip: UNLOCK, ROM, ROOT. Only the chosen tab is shown, so the page stays short. Step numbers are gone; buttons are compact, side by side, and the less urgent notes sit in a collapsed GOOD TO KNOW table at the end of each tab. Every button, safety gate and confirmation works as before, except two disabled-only controls that were dropped: the LOCK button (now a note) and the vbmeta file picker (now a note).
- The MODES tab is removed (8 tabs). Its duplicate "current mode" table is gone (DEVICE already shows mode, vendor and chip); the unsupported/unknown-mode notice now appears under DETECTED DEVICE, and the "How to enter each mode" guide is a panel at the end of the DEVICE page (open automatically when no device or an unknown device is connected). Unsupported modes (EDL, BROM, Samsung Download, Unisoc) now open the DEVICE page on connect. The optional EDL/MediaTek loader selection stays on the FLASH page.

## Mode wheel
- New round control on the DEVICE page (large) and at the top of the FLASH page (smaller): four coloured quarters EDL, VROOM (BROM), DOWNLOAD, FASTBOOT around a RESTART button.
- FASTBOOT sends `reboot-bootloader` (Fastboot) or the ADB `reboot:bootloader` service (recovery ADB). RESTART opens a menu with Reboot System and Reboot to Recovery. EDL, VROOM and DOWNLOAD ask for confirmation first.
- EDL: `oem edl` in Fastboot, `reboot:edl` in recovery ADB. DOWNLOAD: `reboot:download` in recovery ADB only (Samsung). VROOM/BROM: `reboot:brom` in recovery ADB; there is no standard software command, so many phones need the key steps in HOW TO ENTER EACH MODE. Unsupported cases are reported in the log, never faked.
- The old SYSTEM, BOOTLOADER, RECOVERY and FASTBOOTD quick buttons are removed; REFRESH and RECONNECT stay. The REBOOT buttons inside the ROM tab are unchanged.
- `oem edl` is treated like the other reboot commands (not a write); every other `oem` command keeps its destructive gate.



## Analyzer and OEM protocol scope (important)

- The brand-specific Flash screens now include a **Live Operation Log** panel backed by the app's actual ViewModel log stream. It displays recent events only; it does not invent file-transfer progress or device replies.
- Brand-specific layouts are presentation profiles. They do not mean that the matching vendor's proprietary flashing protocol is implemented.
- The only implemented image-write transport in this project is the guarded generic Fastboot image path. Qualcomm EDL/Firehose, MediaTek BROM/DA, Samsung Download, and Unisoc FDL remain fail-closed (`writeEnabled = false`) until their protocol implementations can be reviewed and tested with authorized device-specific material and hardware.
- A CI workflow now runs local unit tests, Android Lint, and the debug APK build, and uploads available reports. A workflow file is not evidence that CI has passed; check the GitHub Actions run after pushing.


## UI refinements in v1.2
- A compact USB speed-limit indicator is fixed in the app header beside connection status.
- It shows the configured minimum throughput while idle and only shows live MiB/s after a real transfer measurement. No idle USB link speed or synthetic benchmark is displayed.
- The separate background flash-progress overlay remains for active operations and critical warnings only. Overlay permission is no longer requested automatically at app launch.
- Core workflow tabs (Device, Flash, Partition, ROM/Root, Safety, Settings) are protected from being hidden.


## Update v1.3

Includes the Universal Unknown Device Analyzer, mode-specific identification guidance, USB identity recheck, Fastboot identity refresh, and fail-closed protection against firmware writes/destructive Fastboot commands when the phone OEM is unverified. This source update has not been Gradle-built or physically tested in this environment.


## Connectivity indicator and wallpaper stock update
- The top status is now a plain corner indicator with a state-coloured lamp; it is not enclosed in a rounded status card.
- `SPEED LIMIT` starts at `0.0 MiB/s` while idle and displays measured transfer speed only during an active transfer. Random/fake throughput values are not generated.
- Refresh/Reconnect and the mode wheel are confined to the Device Connectivity and Flash pages.
- The bundled background stock contains only Midnight Circuit, Soft Cyan, Electric Grid and Deep Navy (plus the optional user-selected custom image).


## Floating Bubble v1.8.1
The background bubble now uses a small status LED (green=ready, yellow=checking/warning, red=disconnected/error), real operation percentage, and measured USB transfer speed. It contains no connection-status words. On a real flash/USB error, the bubble temporarily expands to show a concise error message; tapping it returns to the Flash page.

### v1.9 Settings screen
The Settings screen uses a compact Android-style grouped preference list. Existing appearance, USB warning, safety threshold, default partition, and log preferences are exposed as list rows. Floating bubble runtime behavior is unchanged; no bubble test/toggle controls are placed in Settings.

## v1.6 source review update

- Restores a persisted custom background image URI when the app starts; invalid/stale image URIs still fall back to the bundled background.
- App version is `1.6` (`versionCode` 6).
- See `FINAL_AUDIT_AND_FIX_REPORT_BN.md` for the source audit, feature status, limitations, and validation status.
- This archive has not been Android-built or hardware-tested in the current environment.


## v1.8 update

See `UPDATE_REPORT_BN_v1.8.md` and `FINAL_AUDIT_AND_FIX_REPORT_BN_v1.8.md` for localization/resolver changes and verified limitations.

## v1.21 — Navigation 3D Slider Refinement

Bottom navigation tabs now use a spring-loaded metallic selector, 3D press compression, subtle perspective tilt, and an expanding cyan-accent track. Existing navigation actions and screen destinations are preserved. See `NAVIGATION_3D_SLIDER_REFINEMENT_v1.21_BN.md`.

## v1.30 Gaming UI reference update

The latest user-provided UI references are recorded in `FLASHFORGE_GAMING_UI_REFERENCE_UPDATE_v1.30_BN.md`. This update adds the black slow-motion gaming wallpaper and uses cropped original icon art from the supplied icon sheet on the main navigation/About cards. Custom wallpaper selection remains supported. The full circular wheel redesign and app-wide icon replacement are not yet complete. Build/test was not run because this project archive has no Gradle wrapper and this environment has no Android SDK/Gradle installation.

## UI Kit integration v1.44

The native Compose UI now uses the supplied FlashForge Android UI Kit: four primary tabs, the fixed-size multi-ring radial wheel, the UI Kit icon pack, a neon header/tab bar, a pedestal and 150dp information panel. Build identity: `FLASHFORGE_UIKIT_V2_144`. See `UI_KIT_INTEGRATION_REPORT_BN_v1.44.md` for integration scope and validation limits.

Build and installation steps for this revision are in `BUILD_AND_INSTALL_BN_v1.44.md`.

## v1.50 — Ten-page service architecture

The top navigation now includes Device, Flash, ROM & ROOT, Reset & Repair, Chipset, Backup, Log, Safety, Settings and About. Reset/Chipset pages clearly distinguish supported functions from detection-only or unavailable engines. Backup uses the existing guarded Fastboot backup/restore implementation and metadata/hash checks. Qualcomm EDL, MediaTek BROM, Samsung Download and Unisoc remain detection-only until their exact authorized protocol engines are implemented and validated; selecting a loader is not equivalent to flashing.
## FlashForge v1.56 — UI Readability & Wheel Refinement
- Improved contrast for secondary text and key/value rows on the dark neon interface.
- Refined panel backgrounds and spacing for clearer hierarchy.
- Reduced the radial wheel maximum size to 220dp.
- Preserved existing reset, clean-flash, backup, and safety gates. See `FLASHFORGE_UI_READABILITY_v1.56_BN.md`.
