# FlashForge v1.56 — UI Readability & Wheel Refinement

## লক্ষ্য
v1.55-এর UI-তে পাওয়া কম contrast, dim text এবং অতিরিক্ত বড় radial wheel-এর সমস্যা কমানো; কোনো কার্যকরী reset/flash/backup feature বাদ না দেওয়া।

## পরিবর্তন
- `Ui.kt`: সাধারণ body text-এ dim/amber color ব্যবহৃত হলে dark cyber background-এর জন্য উজ্জ্বল readable color mapping যোগ করা হয়েছে।
- `Ui.kt`: Key/Value rows-এ স্থির high-contrast label ও value color, stronger weight এবং উন্নত letter spacing।
- `Ui.kt`: panel background gradient সামান্য উজ্জ্বল করা হয়েছে; padding কমিয়ে content density উন্নত করা হয়েছে।
- `GamingUi.kt`: radial wheel-এর সর্বোচ্চ মাপ 250dp থেকে 220dp করা হয়েছে।
- `Pages.kt`: Reset & Repair-এর destructive warning, blocked status এবং clean-flash explanation আরও স্পষ্ট ও সংক্ষিপ্ত করা হয়েছে।
- Version: 1.56, versionCode 26.

## সংরক্ষিত
- Device, Flash, ROM & Root, Reset, Chipset, Backup, Log, Safety, Settings, About screens.
- Factory Reset / Userdata Wipe, Device-Compatible Clean Flash, pre-flash backup and existing safety gates.
- Existing 3D icons, circular wheel assets, page actions and app navigation.

## যাচাইয়ের সীমা
ZIP integrity, AndroidManifest XML এবং workflow YAML structure পরীক্ষা করা হয়েছে। এই পরিবেশে Android SDK/Gradle build ও বাস্তব ফোনে rendering test চালানো হয়নি। GitHub Actions build এবং physical-device screenshot দিয়ে final visual confirmation প্রয়োজন।
