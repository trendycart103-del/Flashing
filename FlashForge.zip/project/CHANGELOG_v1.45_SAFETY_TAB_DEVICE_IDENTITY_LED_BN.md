# FlashForge v1.45 — Safety Tab, Device Identity & Connection LED

- Moved the Safety/Shield entry from the header into the main page tab bar.
- Kept the Information button in the header.
- Added a 3D neon connection LED beside Settings. It reflects the existing live `MainVM.link` state: red disconnected, yellow connecting/unstable, green stable/ready.
- The LED is a layered metallic bezel, recessed socket and luminous glass dome with a subtle pulse; it reuses the existing USB link state machine and disconnect-flap detection rather than creating a second detector.
- Moved the Device Identity panel from Safety to Device and show it only after the target is stably connected and identified.
- Preserved the existing Safety Analyzer and its underlying checks.

Build verification: not run in this editing environment. The repository GitHub Actions workflow remains the intended build path.
