# FlashForge Gaming UI Reference Update v1.30

## User-provided visual requirements
- Black / near-black animated gaming wallpaper.
- Slow white light streaks, subtle particles, faint circuit/HUD traces and restrained glow. Background motion must not impair text readability.
- Circular segmented 3D gaming menu reference: cyan and magenta neon segments, central hub, outer HUD rings, slow motion and touch feedback.
- User-supplied 3D icon sprite sheet is the icon design source. Preserve the supplied icon artwork, colors and proportions; avoid redrawing/recoloring/stretching.
- Navigation cards follow the purple 3D glossy reference: Device, Flash, ROM & Root, Log, Safety, Settings, About. Icons above labels, neon edge, depth and press effect; About remains a wide separate tile.
- Typography should be futuristic/stylish, bold and high contrast, while remaining readable. Keep text on dark surfaces and avoid light streaks directly behind labels.

## Changes applied in this update
- Replaced the default background with a black/near-black Compose background featuring slow white streaks, sparse particles, and faint edge circuit lines.
- Preserved custom wallpaper selection (setting choice 2) and its image rendering.
- Added cropped original icon artwork from the user's supplied sprite sheet as drawable-nodpi assets for the seven main navigation/About cards.
- Updated main navigation/About card artwork to use the supplied reference icons (Device, Flash, ROM, Terminal, Safety, Settings, About). The original image art is retained; only transparent background extraction and crop were applied for app placement.

## Not yet implemented
- Full circular segmented feature wheel redesign across every page.
- Replacing every icon throughout all pages with the supplied pack.
- Full custom animated 3D button/card system and typography overhaul.
- Animated circular outer HUD, rotation, and segment-specific touch animation.

## Verification
- Build/test not run: source ZIP contains no Gradle wrapper and the environment has no Android SDK/Gradle installation. Open in Android Studio and run `gradle clean assembleDebug test lint` after syncing.
