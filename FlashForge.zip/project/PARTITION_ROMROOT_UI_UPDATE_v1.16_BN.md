# FlashForge v1.16 — Partition tools inside ROM & Root

- Removed the standalone PARTITION bottom-navigation screen.
- Added PARTITIONS as a fourth sub-tab inside ROM & ROOT (UNLOCK / ROM / ROOT / PARTITIONS).
- Reused the existing PartPage workflows inside the new sub-tab, preserving device-info display, selected partition actions, backup/metadata-based restore, and guarded logical-partition controls.
- Added icon-bearing section panels for partition table, selected partition, backups/restore, and logical partitions.
- Removed PART from the always-visible core navigation list.
- Version: 1.16 / code 15.

Build limitation: Android Gradle compilation and device testing were not performed in this environment. This change is source-level only; validate with GitHub Actions before use.
