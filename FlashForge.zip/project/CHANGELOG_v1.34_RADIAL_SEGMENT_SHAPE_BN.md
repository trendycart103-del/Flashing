# v1.34 — Radial Segment Shape Correction

- Clarified the reference shape: radial pie-wedge segments around a center hub, not individual round buttons.
- Locked the supplied reference image as the shape/layout source of truth.
- Preserved existing segmented radial components in main navigation, Flash tools, ROM & Root, and device mode selection.
- Added label-fit rule: text stays inside segment; if it cannot fit clearly, icon-only is preferred.
- Added interaction/color requirement: 3D press/release feedback and slow, smooth border color transition.
- No claim of full conversion of all remaining conventional action buttons; remaining pages still require follow-up implementation.
- Build not verified (no Gradle wrapper in archive).
