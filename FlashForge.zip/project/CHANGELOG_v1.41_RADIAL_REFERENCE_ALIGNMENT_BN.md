# FlashForge v1.41 — Radial Reference Alignment

## UI-only changes
- Flash action selector now uses a four-segment circular wheel with a central FLASH FIRMWARE hub, aligned to the supplied reference layout.
- The three additional Flash destinations (PHONE FW, DOWNLOADED, DOWNLOAD) remain available as compact neon selector controls beneath the wheel. All seven original selection IDs and their existing content panels are preserved.
- Main page navigation is a single horizontal scrolling tab strip; the first four primary tabs are visible first, while SAFETY, SETTINGS and ABOUT remain reachable by horizontal scrolling.
- Shared action buttons and in-page segmented tabs use consistent beveled neon gradients, rounded metallic borders and a raised 3D lower edge.
- Build metadata updated to version 1.41 / versionCode 11.

## Protected scope
No device, USB, ADB, Fastboot, firmware flashing, ROM, root, chipset, partition, safety-audit, or command-execution logic was intentionally modified. Changes are limited to `Ui.kt`, `Pages.kt`, build version metadata, and this changelog.

## Validation
ZIP integrity and source-diff scope checked. Android Gradle compilation was not run because this environment has no Gradle executable, Gradle wrapper, or configured Android SDK. Run a Gradle build in Android Studio / CI before installing.
