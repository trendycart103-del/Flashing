# FlashForge v1.53.1 — Navigation ও Reset সংশোধন

## পরিবর্তন
- প্রধান ট্যাববার থেকে Settings ও About সরানো হয়েছে; এগুলো স্থায়ী Header-এর Gear ও Information আইকন থেকে খোলা যাবে।
- Device পেজের দৃশ্যমান RESET & REPAIR শর্টকাট বজায় রাখা হয়েছে।
- Reset & Repair পেজে আলাদা Factory Reset / Userdata Wipe প্যানেল যোগ করা হয়েছে।
- Reset বাটন কেবল verified Fastboot connection এবং live product ID expected product ID-এর সঙ্গে মিললে সক্রিয় হবে।
- অপারেশনটি userdata erase করে metadata erase করার চেষ্টা করে; এটি destructive এবং OEM Settings reset-এর সমতুল্য নয়।
- Clean Flash আলাদা workflow হিসেবে আগের মতো রয়েছে এবং pre-flash backup/verified image শর্ত বজায় রাখে।

## সীমাবদ্ধতা
- Android-এর Settings থেকে OEM factory reset trigger করার কোনো universal API নেই। এই বাটন বিদ্যমান Fastboot wipe workflow ব্যবহার করে।
- Metadata erase সব ফোনে সমর্থিত নয়; ব্যর্থ হলে userdata ইতিমধ্যে erase হয়ে থাকতে পারে।
- এই ZIP তৈরি ও structural checks করা হয়েছে; Android Gradle build এবং বাস্তব ডিভাইস পরীক্ষা GitHub Actions/ফোনে করতে হবে।
