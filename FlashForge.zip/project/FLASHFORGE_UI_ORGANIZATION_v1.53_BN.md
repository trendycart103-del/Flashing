# FlashForge v1.53 — UI Organization & Clutter Reduction (2026-11-25)

## Changes applied

- Reduced the primary top navigation from ten entries to the requested seven: Device, Flash, ROM & Root, Log, Safety, Settings and About.
- Kept Reset & Repair, Chipset Service and Backup & Restore available as visible contextual destinations rather than deleting their pages or features.
- Added a visible Device-page Quick Service Tools panel with direct entries to Chipset Service, Reset & Repair, Backup & Restore and Device Log.
- Added direct Backup & Restore and Clean Flash entries at the top of ROM & Root.
- Kept secondary-page selection visually associated with its parent top-level tab (Reset/Chipset under Device; Backup under ROM & Root).
- Replaced the oversized Flash hero/banner with a compact inline status strip. Queue selection count and brand-style controls remain visible.
- Reduced the 3D action-stage wheel size and compressed its extra Flash workflow panel to give the actual page controls more usable screen space.
- Removed the persistent bottom-most latest-log text from every page; detailed operation messages remain in the Log page and relevant operation screens.
- Removed the unnecessary GPS clarification sentence from the Device page. Device identification continues to use USB/bootloader information, not GPS.
- Preserved the existing 3D theme, wheel assets, icons, device database, feature pages, and safety/authorization checks.

## Not changed / limitations

- No chipset write engine was added. Qualcomm EDL, MediaTek BROM, Samsung Download and Unisoc support remain at the previously documented capability level.
- No FRP/security bypass was added.
- Some detailed pages still scroll where the amount of content cannot fit on a small phone display. This update reduces unnecessary vertical occupation; it does not force destructive or lengthy forms into unreadable fixed-height layouts.
- The screenshot mentioned by the user was not attached with this request; the compact Flash banner and persistent footer text were identified from the supplied source ZIP and revised accordingly.

## Version

- versionName: 1.53
- versionCode: 21
- Package: com.flashforge

## Validation

- ZIP integrity checked after packaging.
- Source-level checks verify seven primary navigation destinations, contextual shortcuts, compact Flash banner, and version metadata.
- Android Gradle compile, lint, unit tests, and physical-device UI tests were not run in this environment. GitHub Actions must confirm the actual APK build before installation/release.
