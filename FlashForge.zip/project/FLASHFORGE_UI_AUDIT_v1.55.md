# FlashForge v1.55 — UI visibility and page audit

## Source baseline
Updated from the user-uploaded `FlashForge.zip` (v1.54.1, versionCode 24).

## Changes
- Safety details are expanded permanently; removed the READ MORE / READ LESS gate.
- Advanced preferences are a visible Settings group; no expand/collapse trigger is needed.
- Flash engine style selection is a wrapped 4-column grid, so OEM styles are not hidden in a horizontal scroller.
- The five top-level destinations fit the available width without horizontal scrolling.
- Settings and About pages scroll vertically so their content is not clipped on shorter displays.
- Existing Panel composable already renders its content permanently; the legacy `startOpen` argument remains only for source compatibility.
- Reset, chipset, backup, ROM/root, flash, log and safety tools are retained. Destructive operations still require explicit confirmation dialogs intentionally.

## Scope and limitations
This is a source/UI organization update. It does not add new chipset write engines, bypass FRP, or claim new hardware support. The screenshot's large `FLASH WORKFLOW` panel string is not present in the uploaded v1.54.1 source; the current source already has an inline flash style selector. The selector is now presented as a clear, fully visible in-page grid.

## Validation
- ZIP structure and CRC integrity checked after packaging.
- Source-level checks confirm READ MORE and expandable Advanced Settings controls are removed.
- Android Gradle build, lint, and physical-device UI tests were not run in this environment; use the included GitHub Actions workflow to compile and test.
