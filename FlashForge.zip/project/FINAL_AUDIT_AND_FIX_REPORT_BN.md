**ঐতিহাসিক রিপোর্ট:** এই রিপোর্টের বর্তমান-অবস্থা অংশগুলো v1.12 দ্বারা superseded। বর্তমান Logical Partition, Resume, Restore ও Database অবস্থা `UPDATE_REPORT_BN_v1.12.md` এবং README-তে দেখুন।

---

# FlashForge Android — সম্পূর্ণ সোর্স অডিট ও সংশোধন রিপোর্ট (v1.6)

**অডিটের ভিত্তি:** ব্যবহারকারীর দেওয়া `FlashForge_Android_Settings_List_v1.9.zip`-এর সোর্স কোড।  
**কাজের ধরন:** source review, confirmed bug fix, configuration update, report/changelog.  
**সীমাবদ্ধতা:** এই পরিবেশে Android SDK/Gradle executable এবং Gradle wrapper নেই। তাই Android compile, APK build, emulator test বা বাস্তব USB hardware validation চালানো সম্ভব হয়নি। এই রিপোর্ট compile-tested বলে দাবি করে না।

## 1. নিশ্চিতভাবে সংশোধিত সমস্যা

### Custom background image app restart-এর পর হারিয়ে যেত
- `SettingsPage.kt`-এ OpenDocument picker URI এবং read permission persist করার চেষ্টা করে; `Settings.kt`-এর `persist()`-ও `bg_uri` লিখে রাখে।
- কিন্তু `AppSettings.init()` প্রতিবার `bgUri = ""` করে দিত এবং saved URI পড়ত না। ফলে custom image selection পুনরায় launch-এর পর restore হতো না।
- **Fix:** saved `bg_uri` restore করা হয়; `bg_choice`-এর validation-এ custom wallpaper (choice 2) URI থাকলে restore হয়। Invalid/stale URI হলে `AppBackground()`-এর বিদ্যমান bundled wallpaper fallback বজায় থাকে।
- ফাইল: `app/src/main/java/com/flashforge/Settings.kt`.

### App version
- `versionCode` 5 → 6; `versionName` 1.5 → 1.6.
- ফাইল: `app/build.gradle.kts`.

## 2. ফিচার ও সক্ষমতা তালিকা

| ক্ষেত্র | সোর্সে উপস্থিত | অবস্থা / সীমা |
|---|---|---|
| USB host scan & permission | আছে | Android/device/hardware test বাকি |
| Fastboot detection/connect | আছে | USB hardware validation বাকি |
| ADB/recovery sideload | আছে | recovery protocol ও authorized-device test বাকি |
| Fastboot device/product identity | আছে | exact model identification সব vendor-এ নিশ্চিত নয় |
| Firmware source links | আছে | official support portals; সব model-এর direct firmware URL নয় |
| Firmware HTTPS download | আছে | declared size/stream constraints; redirect ও server behaviour test বাকি |
| ZIP image extraction/queue | আছে | source audit-এ staged extraction ও limits নথিভুক্ত; malformed archive test বাকি |
| SHA-256 verification | আছে | publisher checksum trusted source থেকে user-কে দিতে হয় |
| Flash Safety Analyzer | আছে | fail-closed gate; PASS hardware compatibility guarantee নয় |
| Fastboot image flash | আছে | Safety Gate ও device/product/partition checks-এর আওতায়; hardware test বাকি |
| Recovery/Boot image path | আছে | shared verified path; model/variant risk রয়ে যায় |
| Fastboot erase/unlock/slot | আংশিক | explicit guard; destructive operations hardware test ছাড়া production-safe বলা যাবে না |
| Logical partition create/resize/delete | disabled | অসম্পূর্ণ safety validation-এর কারণে disabled |
| Bootloader relock | disabled | modified image compatibility যাচাই করা হয় না |
| Automatic vbmeta patch | disabled | Verified Boot weakening path disabled |
| Qualcomm EDL | detection/engine registry | write protocol implemented নয়; fail-closed |
| MediaTek BROM | detection/engine registry | DA/protocol execution implemented নয়; fail-closed |
| Samsung Download | detection/engine registry | Samsung flashing protocol implemented নয়; fail-closed |
| Unisoc FDL | detection/engine registry | FDL protocol execution implemented নয়; fail-closed |
| Optional loader selection | UI/storage slot | file selection নিজে protocol execute বা write authorize করে না |
| Partition backup | আছে | bootloader fetch support, size/storage checks দরকার; device-specific support সীমিত |
| Backup restore | নেই | implement করা হয়নি |
| Device database | আছে | local JSON + HTTPS update; authenticity/signature verification নেই |
| Device database model list | আছে | database coverage/accuracy আলাদাভাবে যাচাই প্রয়োজন |
| USB speed/connection warnings | আছে | বাস্তব USB transfer test প্রয়োজন |
| Operation journal/log export | আছে | app/process interruption-এর পর safe resume দাবি করা হয় না |
| Settings/background image | আছে | custom image persistence bug fixed in v1.6 |
| Floating bubble/notification | আছে | Android OS version, notification/overlay permissions, FGS restrictions test বাকি |
| CI workflow | আছে | GitHub Actions workflow উপস্থিত; execution এখানে করা হয়নি |

## 3. উচ্চ অগ্রাধিকারের যাচাই/পরবর্তী কাজ

1. **Build verification:** Android Studio/Gradle wrapper দিয়ে clean build, unit tests, lint চালানো।
2. **USB device matrix:** Pixel/Google, Samsung, Qualcomm EDL, MTK BROM, Unisoc, composite USB interfaces এবং USB hub-এর authorized/read-only detection পরীক্ষা।
3. **Fastboot failure tests:** disconnect, timeout, malformed response, insufficient storage, hash mismatch, wrong product ID, unsupported partition ও partial transfer।
4. **Recovery sideload tests:** recovery banner, package checksum, block request ordering, transport interruption, recovery installation result।
5. **Database update trust:** HTTPS transport থাকলেও JSON update signing/authenticity নেই; signed database অথবা trusted release hash যোগ করার আগে remote database-কে trusted firmware compatibility source ধরা যাবে না।
6. **Firmware resolver:** brand portal ও domain-restricted search link official-domain discovery-তে সহায়ক, কিন্তু exact model/region/build match বা direct download authenticity নিশ্চিত করে না।
7. **Permissions/background:** Android 13+ notification permission, overlay permission, foreground-service restrictions এবং OEM battery-management behaviour পরীক্ষা।
8. **UI/accessibility:** small-screen layout, keyboard, text scaling, contrast, screen-reader labels এবং dark/light theme যাচাই।
9. **Device database:** model aliases, region variants, chipset ambiguity, vendor ID coverage ও firmware links audit/maintain করতে হবে।
10. **Backup:** supported bootloader fetch devices-এ backup/metadata integrity পরীক্ষা; restore feature এখনো নেই।

## 4. নিরাপত্তা ও বাস্তবায়ন সীমা

Chipset engine registry-তে Qualcomm EDL, MediaTek BROM, Samsung Download এবং Unisoc FDL capability metadata আছে; এটি সম্পূর্ণ vendor flashing implementation নয়। `writeEnabled` false থাকা এবং unsupported paths fail-closed থাকা বজায় রাখা হয়েছে। Loader selection-কে executable/write capability হিসেবে দেখানো যাবে না। Anti-theft protection/FRP bypass, credential bypass বা unauthorized device access feature যোগ করা হয়নি।

## 5. যাচাইয়ের ফল

- Source files inspected: Android manifest, build configuration, settings persistence, firmware resolver, device database, mode detector, chipset engine registry, tests, MainActivity এবং audit/changelog.
- Confirmed code change: custom wallpaper URI persistence.
- Version bumped: 1.6 / code 6.
- Existing fail-closed chipset write registry regression tests retained.
- **Build/test status: NOT RUN** — Gradle executable/wrapper এবং Android SDK এই runtime-এ পাওয়া যায়নি।
- **Hardware status: NOT TESTED** — কোনো ফোন/USB target সংযুক্ত করে পরীক্ষা করা হয়নি।

## 6. এই রিলিজে পরিবর্তিত ফাইল

- `app/src/main/java/com/flashforge/Settings.kt`
- `app/build.gradle.kts`
- `FINAL_AUDIT_AND_FIX_REPORT_BN.md` (এই রিপোর্ট)

অন্যান্য সোর্স ফাইল অডিট করা হয়েছে, কিন্তু compile/test ছাড়া ব্যাপক refactor করা হয়নি—কারণ এতে অজানা regression হওয়ার ঝুঁকি আছে।
