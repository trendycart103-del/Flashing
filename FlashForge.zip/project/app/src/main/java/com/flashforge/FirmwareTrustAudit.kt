package com.flashforge

import java.security.MessageDigest

/** Read-only firmware trust checks. A checksum match proves byte integrity against the
 * supplied digest only; it does NOT authenticate the publisher or source. */
object FirmwareTrustAudit {
    enum class Status { PASS, WARNING, BLOCKED }
    data class Result(val status: Status, val message: String, val sha256: String? = null)

    fun validateSource(url: String): Result {
        val normalized = url.trim()
        if (normalized.isBlank()) return Result(Status.BLOCKED, "Firmware source URL is missing")
        return try {
            val uri = java.net.URI(normalized)
            if (!uri.scheme.equals("https", true) || uri.host.isNullOrBlank())
                Result(Status.BLOCKED, "Only HTTPS URLs with a host are accepted")
            else Result(Status.WARNING, "HTTPS transport is present; publisher authenticity is not independently verified")
        } catch (_: Exception) {
            Result(Status.BLOCKED, "Firmware source URL is invalid")
        }
    }

    fun compareSha256(actual: String, expected: String?): Result {
        val digest = actual.trim().lowercase()
        if (!digest.matches(Regex("[a-f0-9]{64}"))) return Result(Status.BLOCKED, "Computed SHA-256 is malformed")
        val wanted = expected?.trim()?.lowercase()
        if (wanted.isNullOrBlank()) return Result(Status.WARNING, "No trusted expected SHA-256 supplied", digest)
        if (!wanted.matches(Regex("[a-f0-9]{64}"))) return Result(Status.BLOCKED, "Expected SHA-256 is malformed", digest)
        return if (MessageDigest.isEqual(digest.toByteArray(), wanted.toByteArray()))
            Result(Status.PASS, "SHA-256 matches the supplied digest; publisher identity remains unverified", digest)
        else Result(Status.BLOCKED, "SHA-256 mismatch: file integrity check failed", digest)
    }

    fun assessCompatibility(
        detectedModel: String?, expectedModel: String?,
        detectedRegion: String? = null, expectedRegion: String? = null,
        detectedChipset: String? = null, expectedChipset: String? = null
    ): Result {
        val model = detectedModel.normalized()
        val expected = expectedModel.normalized()
        if (model.isBlank() || expected.isBlank()) return Result(Status.BLOCKED, "Exact model identity is required")
        if (model != expected) return Result(Status.BLOCKED, "Model mismatch: detected '$model', expected '$expected'")
        val regionA = detectedRegion.normalized(); val regionB = expectedRegion.normalized()
        if (regionA.isNotBlank() && regionB.isNotBlank() && regionA != regionB)
            return Result(Status.BLOCKED, "Region/variant mismatch")
        val chipA = detectedChipset.normalized(); val chipB = expectedChipset.normalized()
        if (chipA.isNotBlank() && chipB.isNotBlank() && chipA != chipB)
            return Result(Status.BLOCKED, "Chipset mismatch")
        val missing = listOf(regionA to regionB, chipA to chipB).any { (a,b) -> a.isBlank() || b.isBlank() }
        return if (missing) Result(Status.WARNING, "Model matches, but region and/or chipset evidence is incomplete")
        else Result(Status.PASS, "Model, region and chipset identifiers match")
    }

    private fun String?.normalized(): String = this.orEmpty().trim().replace(Regex("\\s+"), " ").uppercase()
}
