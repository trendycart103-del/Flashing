package com.flashforge

/** Fail-closed capability registry. Detection does not imply a device is safe/authorized to write. */
object ChipsetFlashEngines {
    data class EngineInfo(
        val title: String,
        val mode: Mode,
        val transport: String,
        val requirements: String,
        /** Optional user-supplied file slot; selecting a file does not authorize or execute it. */
        val optionalLoaderLabel: String? = null,
        val writeEnabled: Boolean = false
    )

    val engines = listOf(
        EngineInfo("Qualcomm EDL", Mode.QUALCOMM_EDL, "Sahara / Firehose", "Exact model-matched, OEM-authorized signed programmer and supported Firehose protocol", optionalLoaderLabel = "Optional EDL programmer"),
        EngineInfo("MediaTek BROM", Mode.MEDIATEK_BROM, "BROM / Download Agent", "Exact model-matched, OEM-authorized DA; Secure Boot / SLA / DAA authorization where required", optionalLoaderLabel = "Optional MediaTek Download Agent"),
        EngineInfo("Samsung Download", Mode.SAMSUNG_DOWNLOAD, "Samsung Download protocol", "Model/bootloader-compatible signed firmware package and supported Samsung protocol implementation"),
        EngineInfo("Unisoc FDL", Mode.UNISOC, "FDL1 / FDL2", "Exact model-matched, OEM-authorized FDL files and supported security authorization")
    )

    fun forMode(mode: Mode): EngineInfo? = engines.firstOrNull { it.mode == mode }
}
