package com.flashforge

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.layout
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.PI
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Soft light palette: navy text, orange section accents, pastel background. */
object C {
    val bg: Color get() = AppSettings.color("bg")
    val panel: Color get() = AppSettings.color("panel")
    val line: Color get() = AppSettings.color("text")
    val ink: Color get() = AppSettings.color("text")
    val blue: Color get() = AppSettings.color("blue")
    val orange: Color get() = AppSettings.color("orange")
    val amber: Color get() = AppSettings.color("amber")
    val green: Color get() = AppSettings.color("green")
    val red: Color get() = AppSettings.color("red")
    val yellow: Color get() = AppSettings.color("yellow")
    val yellowDark = Color(0xFF8A5A00)
    val text: Color get() = AppSettings.color("text")
    val dim: Color get() = AppSettings.color("dim")
    val off = Color(0xFFD9DEEA)
}

val Sans = FontFamily.SansSerif

/** Consistent display/body/label hierarchy for the metallic interface. */
private val ForgeTypography = Typography(
    displayLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.ExtraBold, fontSize = 32.sp, lineHeight = 38.sp, letterSpacing = (-0.45).sp),
    headlineLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, lineHeight = 31.sp, letterSpacing = (-0.2).sp),
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 27.sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 24.sp, letterSpacing = 0.15.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp, letterSpacing = 0.15.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 13.sp, lineHeight = 17.sp, letterSpacing = 0.35.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 15.sp, letterSpacing = 0.25.sp)
)

/** Lamp colour and readable text colour for each connection state. */
val Link.tint: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellow
    Link.GREEN -> C.green
}
val Link.ink: Color get() = when (this) {
    Link.RED -> C.red
    Link.YELLOW -> C.yellowDark
    Link.GREEN -> C.green
}
val Link.pill: String get() = when (this) {
    Link.RED -> "NOT CONNECTED"
    Link.YELLOW -> "Connecting"
    Link.GREEN -> "Connected"
}

// ---------------- shapes ----------------

val CardShape = RoundedCornerShape(32.dp)
val PanelShape = RoundedCornerShape(28.dp)
val FieldShape = RoundedCornerShape(18.dp)
val TabShape = RoundedCornerShape(50)
val NavShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

/** Pill button: fully rounded ends (same shape as the SYSTEM reboot button). */
val BtnShape = RoundedCornerShape(20.dp)

// ---------------- background ----------------

fun Modifier.blueprint(): Modifier = this.background(C.bg)

// ---------------- text helpers ----------------

private val Acronyms = setOf("ROM", "ZIP", "ADB", "USB", "OEM", "SHA", "EDL", "OTG", "GSI", "FRP", "IMG", "AB", "AP", "BL", "CP", "CSC")

/** "REBOOT TO RECOVERY" -> "Reboot to recovery"; acronyms and one-letter words stay as they are. */
fun nice(t: String): String {
    val out = t.split(" ").joinToString(" ") { w ->
        val core = w.filter { it.isLetter() }
        if (core.length > 1 && core.all { it.isUpperCase() } && core !in Acronyms) w.lowercase() else w
    }
    return out.replaceFirstChar { it.uppercase() }
}

@Composable
fun T(s: String, c: Color = C.text, sz: Int = 12, bold: Boolean = false, mod: Modifier = Modifier) {
    Text(
        localized(s), color = c, fontFamily = Sans, fontSize = (sz + 2).sp, lineHeight = ((sz + 2) * 1.42f).sp,
        fontWeight = if (bold) FontWeight.ExtraBold else FontWeight.Medium,
        letterSpacing = if (bold) 0.18.sp else 0.sp,
        modifier = mod
    )
}

private val GoodValues = setOf("yes", "unlocked", "granted", "allowed", "on")

@Composable
fun KV(k: String, v: String) {
    val vc = if (v.trim().lowercase() in GoodValues) C.green else C.text
    Row(
        Modifier.fillMaxWidth()
            .drawBehind { drawLine(C.ink.copy(alpha = 0.08f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(k, color = C.dim, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.5f))
        Text(
            v, color = vc, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End, modifier = Modifier.weight(0.5f)
        )
    }
}

/** Rounded white card with an orange dot title. The outline turns blue on touch or focus. */
@Composable
fun Panel(title: String, startOpen: Boolean = true, icon: Int = 0, accent: Color = C.orange, dense: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    // Important controls must never be hidden behind collapsible panel headers.
    // Keep the parameter for source compatibility with existing call sites.
    var focused by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val active = focused || pressed
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(450), label = "appear")
    val bw by animateDpAsState(if (active) 2.dp else 1.dp, tween(200), label = "bw")
    val bc by animateColorAsState(if (active) C.blue else C.ink.copy(alpha = 0.06f), tween(250), label = "bc")
    val glow by animateFloatAsState(if (active) 0.08f else 0f, tween(300), label = "glow")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = if (dense) 4.dp else 7.dp)
            .graphicsLayer { alpha = appear; translationY = (1f - appear) * 48f }
            .background(Brush.verticalGradient(listOf(Color(0xFF25203A), Color(0xFF100F1D), Color(0xFF090A12))), PanelShape)
            .background(C.blue.copy(alpha = glow), PanelShape)
            .border(bw, Brush.linearGradient(listOf(Color(0xFF5BE8FF), Color(0xFF9C5BFF), Color(0xFFEF63D5))), PanelShape)
            .onFocusChanged { focused = it.hasFocus }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        pressed = e.changes.any { it.pressed }
                    }
                }
            }
            .padding(horizontal = if (dense) 14.dp else 20.dp, vertical = if (dense) 8.dp else 14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clip(FieldShape).padding(vertical = if (dense) 2.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != 0) IconTile(icon, accent, if (dense) 38.dp else 46.dp) else Box(Modifier.size(13.dp).background(C.orange, CircleShape))
            Spacer(Modifier.width(if (icon != 0) 12.dp else 10.dp))
            Text(
                title, color = Color(0xFFE8E4FF), fontFamily = Sans, fontSize = if (dense) 14.sp else 16.sp,
                fontWeight = FontWeight.ExtraBold, letterSpacing = 0.85.sp,
                modifier = Modifier.weight(1f)
            )
            Text("•", color = Color(0xFF63E7FF), fontFamily = Sans, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column {
            Spacer(Modifier.height(if (dense) 6.dp else 10.dp))
            content()
        }
    }
}

/** Prominent icon: the picture sits on a tinted, outlined rounded square so it is easy to spot. */
@Composable
fun IconTile(icon: Int, accent: Color, box: androidx.compose.ui.unit.Dp = 46.dp) {
    val sh = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(box).background(
            Brush.linearGradient(listOf(Color(0xFF39216F), Color(0xFF111B48), Color(0xFF07152F))), sh
        ).border(1.6.dp, Brush.linearGradient(listOf(Color.White, Color(0xFF3DE7FF), accent, Color(0xFF9D4BFF))), sh)
            .drawBehind {
                drawRoundRect(accent.copy(alpha = .12f), style = androidx.compose.ui.graphics.drawscope.Stroke(4.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()))
                drawLine(Color.White.copy(alpha = 0.72f), Offset(8.dp.toPx(), 2.dp.toPx()), Offset(size.width - 8.dp.toPx(), 2.dp.toPx()), 1.dp.toPx())
            },
        contentAlignment = Alignment.Center
    ) { Image(painterResource(icon), null, Modifier.size(box - 10.dp)) }
}

/** One numbered row of a step table. */
class TableStep(val no: Int, val icon: Int, val title: String, val what: String)

/** A table block: a coloured group band followed by numbered rows (number | icon | title and purpose). */
@Composable
fun StepGroup(name: String, groupIcon: Int, accent: Color, rows: List<TableStep>) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp).background(accent.copy(alpha = 0.14f), FieldShape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(groupIcon), null, Modifier.size(34.dp))
        Spacer(Modifier.width(10.dp))
        Text(name, color = C.text, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    }
    rows.forEach { r ->
        Row(
            Modifier.fillMaxWidth()
                .drawBehind { drawLine(C.ink.copy(alpha = 0.08f), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${r.no}", color = accent, fontFamily = Sans, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.width(34.dp)
            )
            IconTile(r.icon, accent, 44.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(r.title, color = C.text, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(r.what, color = C.dim, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Rw(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

/** PC-software style tab strip: icon + label, the chosen tab is filled with its colour. */
@Composable
fun SegTabs(labels: List<String>, icons: List<Int>, accents: List<Color>, sel: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .background(Brush.verticalGradient(listOf(Color(0xFF21183B), Color(0xFF090D25))), RoundedCornerShape(18.dp))
            .border(1.4.dp, Brush.linearGradient(listOf(Color(0xFF45E8FF), Color(0xFF9B4DFF), Color(0xFF45E8FF))), RoundedCornerShape(18.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        labels.forEachIndexed { i, l ->
            val on = i == sel
            val a = accents[i]
            Row(
                Modifier.weight(1f).heightIn(min = 52.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.verticalGradient(if (on) listOf(Color(0xFFB95BFF), Color(0xFF3D20A0), Color(0xFF071D55)) else listOf(Color(0xFF29213D), Color(0xFF17132B), Color(0xFF090D20))))
                    .border(if (on) 2.dp else 1.dp, Brush.linearGradient(if (on) listOf(Color.White, Color(0xFF39E7FF), Color(0xFFB64DFF)) else listOf(a.copy(alpha=.7f), Color(0xFF344A80))), RoundedCornerShape(16.dp))
                    .clickable { onSel(i) }.padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(30.dp),
                    contentAlignment = Alignment.Center
                ) { Image(painterResource(icons[i]), null, Modifier.size(28.dp)) }
                Spacer(Modifier.width(6.dp))
                Text(
                    l, color = Color.White, fontFamily = Sans, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }
    }
}

/** Small status cells, two per row: label on top, value below. */
@Composable
fun StatusStrip(items: List<Pair<String, String>>) {
    items.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            pair.forEach { (k, v) ->
                val vc = if (v.trim().lowercase() in GoodValues) C.green else C.text
                Column(
                    Modifier.weight(1f)
                        .background(C.panel.copy(alpha = 0.98f), FieldShape)
                        .border(1.dp, C.ink.copy(alpha = 0.06f), FieldShape)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(k, color = C.dim, fontFamily = Sans, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    Text(v, color = vc, fontFamily = Sans, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** Compact two-column reference table: short label | explanation. */
@Composable
fun NoteTable(rows: List<Pair<String, String>>, accent: Color = C.amber) {
    Column(Modifier.fillMaxWidth().border(1.dp, C.ink.copy(alpha = 0.10f), FieldShape).clip(FieldShape)) {
        rows.forEachIndexed { i, (k, v) ->
            Row(
                Modifier.fillMaxWidth()
                    .background(if (i % 2 == 0) accent.copy(alpha = 0.07f) else Color.Transparent)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(k, color = C.text, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.32f))
                Text(v, color = C.dim, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.68f))
            }
        }
    }
}

/** Picks the graphical icon that is drawn inside a button, from the button label. */
fun iconFor(t: String): Int {
    val u = t.uppercase()
    return when {
        u.startsWith("REFRESH") || u.startsWith("READ TABLE") -> R.drawable.b_refresh
        u.startsWith("SLOT") -> R.drawable.b_slot
        u.startsWith("REBOOT TO RECOVERY") || u == "RECOVERY" -> R.drawable.b_recovery
        u == "SYSTEM" || u.startsWith("REBOOT SYSTEM") -> R.drawable.b_power
        u == "BOOTLOADER" -> R.drawable.b_boot
        u == "FASTBOOTD" -> R.drawable.b_term
        u.startsWith("ADD IMAGE") -> R.drawable.b_image
        u.startsWith("UNPACK") -> R.drawable.b_zip
        u.startsWith("FLASH") -> R.drawable.b_bolt
        u.startsWith("SAVE") -> R.drawable.b_save
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> R.drawable.b_download
        u.startsWith("ERASE") || u.startsWith("DELETE") || u.startsWith("WIPE") -> R.drawable.b_trash
        u.startsWith("BACKUP") -> R.drawable.b_backup
        u.startsWith("CREATE") -> R.drawable.b_plus
        u.startsWith("RESIZE") -> R.drawable.b_resize
        u.startsWith("UNLOCK") -> R.drawable.b_unlock
        u.startsWith("LOCK") -> R.drawable.b_lock
        u.startsWith("CHOOSE") -> R.drawable.b_folder
        u.startsWith("SIDELOAD") -> R.drawable.b_upload
        u.startsWith("EXPORT") -> R.drawable.b_export
        u.startsWith("CLEAR") -> R.drawable.b_clear
        u.startsWith("GRANT") || u.startsWith("BUBBLE") || u.startsWith("TEST") -> R.drawable.b_bubble
        u.startsWith("ALLOW") -> R.drawable.b_bell
        else -> 0
    }
}

/** Compact neon-metal 3D icon button using the bundled glossy icon pack. */
@Composable
fun IconBtn(res: Int, on: () -> Unit) {
    val sh = RoundedCornerShape(13.dp)
    Box(
        Modifier.padding(horizontal = 3.dp).size(42.dp)
            .background(Brush.linearGradient(listOf(Color(0xFF8A4DCE), Color(0xFF25165C), Color(0xFF071D43))), sh)
            .border(1.5.dp, Brush.linearGradient(listOf(Color.White, Color(0xFF48E8FF), Color(0xFFB34CFF))), sh)
            .drawBehind { drawLine(Color.White.copy(alpha=.72f), Offset(7.dp.toPx(), 2.dp.toPx()), Offset(size.width-7.dp.toPx(), 2.dp.toPx()), 1.2.dp.toPx()) }
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(res), null, Modifier.size(29.dp)) }
}

/** Gradient pairs (start, end) in the style of the reference screenshot. */
private val BtnGradients = listOf(
    Color(0xFFB34DFF) to Color(0xFF075BCE),
    Color(0xFF8E4BEB) to Color(0xFF063D92),
    Color(0xFF36DFFF) to Color(0xFF25206F),
    Color(0xFFB75BFF) to Color(0xFF242064),
    Color(0xFF38CFFF) to Color(0xFF143A9C),
    Color(0xFF8E57F3) to Color(0xFF101A54)
)
private val DangerGradient = Color(0xFFFF6B9E) to Color(0xFF75133F)

private fun gradFor(t: String, danger: Boolean): Pair<Color, Color> {
    if (danger) return DangerGradient
    val u = t.uppercase()
    return when {
        u.startsWith("FLASH") -> BtnGradients[0]
        u.startsWith("REFRESH") || u.startsWith("READ") -> BtnGradients[1]
        u.startsWith("UNLOCK") || u.startsWith("LOCK") -> BtnGradients[2]
        u.startsWith("BACKUP") || u.startsWith("SAVE") -> BtnGradients[3]
        u.startsWith("DOWNLOAD") || u.startsWith("UPDATE") -> BtnGradients[4]
        else -> BtnGradients[(t.hashCode() and 0x7fffffff) % BtnGradients.size]
    }
}

@Composable
fun Btn(t: String, enabled: Boolean = true, danger: Boolean = false, mod: Modifier = Modifier, icon: Int = iconFor(t), compact: Boolean = false, on: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.94f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "btnScale"
    )
    val (g1, g2) = gradFor(t, danger)
    val brush = if (enabled) Brush.linearGradient(listOf(g1, g2)) else Brush.linearGradient(listOf(C.off, C.off))
    Button(
        onClick = on, enabled = enabled,
        modifier = mod
            .padding(vertical = 4.dp)
            .fillMaxWidth()
            .heightIn(min = if (compact) 44.dp else 56.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc; translationY = if (pr) 2.dp.toPx() else 0f }
            .background(brush, BtnShape)
            .drawBehind {
                val glow = if (pr) 0.38f else 0.22f
                val cr = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx())
                drawRoundRect(Color(0xFF02051A).copy(alpha = .82f), topLeft = Offset(0f, 3.dp.toPx()), cornerRadius = cr)
                drawRoundRect(Color(0xFF32DFFF).copy(alpha = glow), style = androidx.compose.ui.graphics.drawscope.Stroke(4.dp.toPx()), cornerRadius = cr)
                drawLine(Color.White.copy(alpha = .82f), Offset(14.dp.toPx(), 2.dp.toPx()), Offset(size.width - 14.dp.toPx(), 2.dp.toPx()), 1.5.dp.toPx())
            }
            .border(2.dp, Brush.linearGradient(listOf(Color.White, Color(0xFF35E8FF), Color(0xFFB84DFF), Color(0xFF4D8DFF))), BtnShape),
        shape = BtnShape,
        interactionSource = src,
        elevation = null,
        contentPadding = PaddingValues(horizontal = if (compact) 10.dp else 20.dp, vertical = if (compact) 4.dp else 8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent, contentColor = Color.White,
            disabledContainerColor = Color.Transparent, disabledContentColor = Color(0xFF8994B5)
        )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != 0) {
                Box(Modifier.size(if (compact) 30.dp else 36.dp), contentAlignment = Alignment.Center) {
                    Image(painterResource(icon), null, Modifier.size(if (compact) 27.dp else 33.dp), alpha = if (enabled) 1f else 0.48f)
                }
                Spacer(Modifier.width(7.dp))
            }
            Text(
                nice(t), color = Color.White, fontFamily = Sans, fontSize = if (compact) 13.sp else 15.sp, fontWeight = FontWeight.ExtraBold,
                maxLines = 2, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ConfirmBtn(t: String, msg: String, enabled: Boolean = true, danger: Boolean = true, mod: Modifier = Modifier, compact: Boolean = false, go: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Btn(t, enabled, danger, mod, compact = compact) { open = true }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false; go() }) { Text("CONFIRM", color = C.red, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("CANCEL", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
            title = { Text(nice(t), fontFamily = Sans, fontWeight = FontWeight.Bold) },
            text = { Text(msg, fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium) },
            shape = PanelShape,
            containerColor = C.panel, titleContentColor = C.amber, textContentColor = C.text
        )
    }
}

@Composable
fun Field(v: String, onv: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = v, onValueChange = onv, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = FieldShape,
        label = { Text(label, fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium) },
        textStyle = TextStyle(fontFamily = Sans, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = C.text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = C.text, unfocusedTextColor = C.text,
            focusedContainerColor = C.panel.copy(alpha = 0.85f),
            unfocusedContainerColor = C.panel.copy(alpha = 0.55f),
            focusedBorderColor = C.blue, unfocusedBorderColor = C.ink.copy(alpha = 0.22f),
            focusedLabelColor = C.blue, unfocusedLabelColor = C.dim, cursorColor = C.blue
        )
    )
}

@Composable
fun PickBtn(label: String, mod: Modifier = Modifier, compact: Boolean = false, on: (Uri) -> Unit) {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) on(u) }
    Btn(label, mod = mod, compact = compact) { l.launch(arrayOf("*/*")) }
}

// ---------------- header card ----------------

/** Approved FlashForge two-phone OTG/flashing artwork used as the in-app logo. */
@Composable
fun AppLogo(size: androidx.compose.ui.unit.Dp = 56.dp) {
    Image(
        painter = painterResource(R.drawable.flashforge_logo),
        contentDescription = "FlashForge app logo",
        modifier = Modifier.size(size).clip(FieldShape),
        contentScale = androidx.compose.ui.layout.ContentScale.Fit
    )
}

/** Two solid, sharp-toothed pinions with small central bores, continuously meshing in opposite directions. */
@Composable
fun AnimatedGearMark(size: androidx.compose.ui.unit.Dp = 56.dp) {
    val motion = rememberInfiniteTransition(label = "headerPinions")
    val largeRotation by motion.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4500, easing = LinearEasing)), label = "largePinion"
    )
    val smallRotation by motion.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "smallPinion"
    )

    Canvas(Modifier.size(size).semantics { contentDescription = "Two continuously rotating interlocking pinion gears" }) {
        val unit = this.size.minDimension
        val largeRadius = unit * 0.335f
        val smallRadius = unit * 0.285f
        // Centers are deliberately closer so the pointed teeth visibly engage.
        val largeCenter = Offset(this.size.width * 0.365f, this.size.height * 0.365f)
        val smallCenter = Offset(this.size.width * 0.685f, this.size.height * 0.685f)

        fun pinionPath(center: Offset, radius: Float, teeth: Int): Path {
            val path = Path()
            // Each tooth has a narrow, pointed crest and a deep root like a machined pinion.
            val pointsPerTooth = 6
            val count = teeth * pointsPerTooth
            for (i in 0 until count) {
                val toothPhase = i % pointsPerTooth
                val radial = when (toothPhase) {
                    0, 5 -> 0.765f
                    1, 4 -> 0.805f
                    2, 3 -> 1.0f
                    else -> 0.765f
                }
                val angle = (i.toFloat() / count * (2.0 * Math.PI) - Math.PI / 2.0).toFloat()
                val x = center.x + kotlin.math.cos(angle) * radius * radial
                val y = center.y + kotlin.math.sin(angle) * radius * radial
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            return path
        }

        // Large blue pinion: solid metal face, not a hollow ring.
        rotate(largeRotation, largeCenter) {
            drawPath(pinionPath(largeCenter, largeRadius, 10), Color(0xFF2478D0))
            drawCircle(Color(0xFF3E91E8), largeRadius * 0.70f, largeCenter)
            drawCircle(Color(0xFF172A45), largeRadius * 0.105f, largeCenter)
        }

        // Smaller orange pinion rotates in the opposite direction.
        rotate(smallRotation, smallCenter) {
            drawPath(pinionPath(smallCenter, smallRadius, 9), Color(0xFFFF982E))
            drawCircle(Color(0xFFFFB65F), smallRadius * 0.70f, smallCenter)
            drawCircle(Color(0xFF172A45), smallRadius * 0.105f, smallCenter)
        }
    }
}

/** Two-tone wordmark: "Flash" in text colour, "Forge" in the logo orange. */
@Composable
fun AppWordmark(fontSize: androidx.compose.ui.unit.TextUnit = 22.sp) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = C.text)) { append("Flash") }
            withStyle(SpanStyle(color = Color(0xFF9B78D6))) { append("Forge") }
        },
        fontFamily = Sans, fontSize = fontSize, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.2.sp,
        maxLines = 1, softWrap = false
    )
}

/** Plain corner status: no capsule/card; the lamp colour follows the real USB link state. */
@Composable
fun LinkPill(vm: MainVM) {
    val l = vm.link
    val inf = rememberInfiniteTransition(label = "link")
    val blink by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse), label = "blink")
    val main by animateColorAsState(l.tint, tween(300), label = "linkColor")
    val dotAlpha = if (l == Link.YELLOW && blink < 0.5f) 0.2f else 1f
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp, 52.dp).background(Color(0xFF11131C), RoundedCornerShape(13.dp))
            .border(1.5.dp, Color(0xFF667085), RoundedCornerShape(13.dp)).padding(vertical = 4.dp, horizontal = 5.dp),
            contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(14.dp).background(if (l == Link.RED) main.copy(alpha = dotAlpha) else Color(0xFF3B2027), CircleShape).border(1.dp, Color.White.copy(alpha = .25f), CircleShape))
                Box(Modifier.size(14.dp).background(if (l == Link.YELLOW) main.copy(alpha = dotAlpha) else Color(0xFF3A3020), CircleShape).border(1.dp, Color.White.copy(alpha = .25f), CircleShape))
                Box(Modifier.size(14.dp).background(if (l == Link.GREEN) main.copy(alpha = dotAlpha) else Color(0xFF193426), CircleShape).border(1.dp, Color.White.copy(alpha = .25f), CircleShape))
            }
        }
        Spacer(Modifier.width(7.dp))
        Text(l.pill, color = l.ink, fontFamily = Sans, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Shows measured transfer throughput only. No transfer means 0.0; never fabricate/randomise a speed. */
@Composable
fun UsbSpeedIndicator(vm: MainVM) {
    val value = if (vm.busy) vm.transferSpeed.coerceAtLeast(0.0) else 0.0
    val label = String.format(java.util.Locale.US, "SPEED LIMIT  %.1f MiB/s", value)
    val speedColor = when {
        !vm.busy || value <= 0.0 -> C.dim
        value < AppSettings.slowMbs -> C.red
        else -> C.green
    }
    Text(label, color = speedColor, fontFamily = Sans, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
}

@Composable
fun Header(vm: MainVM) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedGearMark()
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                AppWordmark()
                if (vm.mode != Mode.NONE) {
                    Text(vm.vendor + " | " + vm.usbId, color = C.dim, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LinkPill(vm)
                UsbSpeedIndicator(vm)
            }
        }
        if (vm.mode != Mode.NONE) {
            val status = buildList {
                add(vm.mode.label)
                vm.product.takeIf { it.isNotBlank() }?.let { add(it) }
                if (vm.slot != "?") add("slot " + vm.slot)
                if (vm.unlocked != "?") add("unlocked " + vm.unlocked)
            }.joinToString("  ·  ")
            Text(status, color = C.text, fontFamily = Sans, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(vm.linkNote + "  " + vm.linkPct.toString() + "%", color = C.dim, fontFamily = Sans, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}


// ---------------- always-visible quick actions ----------------

/** Look of one quick action. Each action gets its own style so they are easy to tell apart, all in the app's palette. */
enum class TileStyle { HERO, OUTLINE, SOLID, DARK, SOFT, SPLIT }

@Composable
fun ActionTile(
    label: String, icon: Int, accent: Color, style: TileStyle, enabled: Boolean,
    mod: Modifier = Modifier, big: Boolean = false, on: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pr) 0.93f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tileScale"
    )
    val sh = BtnShape
    val off = !enabled
    val fill: Brush = when {
        off -> Brush.linearGradient(listOf(C.off, C.off))
        style == TileStyle.HERO -> Brush.linearGradient(listOf(accent, Color(0xFF5B5BFF)))
        style == TileStyle.SOLID -> Brush.linearGradient(listOf(accent, accent))
        style == TileStyle.DARK -> Brush.linearGradient(listOf(Color(0xFFE9DEFF), Color(0xFFC4A9F0)))
        style == TileStyle.SOFT -> Brush.linearGradient(listOf(accent.copy(alpha = 0.16f), accent.copy(alpha = 0.16f)))
        style == TileStyle.SPLIT -> Brush.verticalGradient(listOf(accent.copy(alpha = 0.22f), C.panel))
        else -> Brush.linearGradient(listOf(C.panel, C.panel))
    }
    val solidLike = !off && (style == TileStyle.HERO || style == TileStyle.SOLID || style == TileStyle.DARK)
    val ink = when {
        off -> C.dim
        solidLike -> Color(0xFF49356F)
        else -> accent
    }
    val border = when {
        off -> null
        style == TileStyle.OUTLINE -> BorderStroke(1.5.dp, accent)
        style == TileStyle.SPLIT -> BorderStroke(1.dp, accent.copy(alpha = 0.5f))
        else -> null
    }
    val base = mod.graphicsLayer { scaleX = sc; scaleY = sc; translationY = if (pr) 2.dp.toPx() else 0f }
        .heightIn(min = if (big) 54.dp else 42.dp)
        .clip(sh).background(fill, sh)
        .border(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.9f), accent.copy(alpha = 0.82f), Color(0xFFB9A2DF).copy(alpha = 0.55f))), sh)
        .let { if (border != null) it.border(border, sh) else it }
        .clickable(enabled = enabled, interactionSource = src, indication = null, onClick = on)
    if (big) {
        Row(base.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(Modifier.size(34.dp).background(Color.White.copy(alpha = if (off) 0.5f else 0.92f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Image(painterResource(icon), null, Modifier.size(24.dp), alpha = if (off) 0.45f else 1f)
            }
            Spacer(Modifier.width(8.dp))
            Text(label, color = ink, fontFamily = Sans, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.18.sp, maxLines = 1,
                )
        }
    } else {
        Column(base.padding(vertical = 4.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.size(28.dp)
                    .background(Brush.linearGradient(listOf(Color.White, Color(0xFFD7E2EF))), CircleShape)
                    .border(1.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) { Image(painterResource(icon), null, Modifier.size(20.dp), alpha = if (off) 0.45f else 1f) }
            Spacer(Modifier.height(2.dp))
            Text(label, color = ink, fontFamily = Sans, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.08.sp, maxLines = 1, textAlign = TextAlign.Center,
                )
        }
    }
}

@Composable
private fun QuickRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        content()
    }
}

/** Compact footer keeps the latest status text; progress is shown only in the active task page and floating bubble. */
@Composable
fun Footer(vm: MainVM) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 6.dp)) {
        T(vm.logs.lastOrNull() ?: "Ready", C.dim, 11, true)
    }
}

@Composable
fun AppUi(vm: MainVM) {
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * AppSettings.textScale)) {
        AppUiBody(vm)
    }
}

@Composable
private fun AppUiBody(vm: MainVM) {
    var flashSection by remember { mutableStateOf("sites") }
    var romTab by remember { mutableStateOf(0) }
    var partToolTab by remember { mutableStateOf(0) }
    var flashWheelAction by remember { mutableStateOf<String?>(null) }
    var logFilter by remember { mutableStateOf(false) }
    var pendingGamingAction by remember { mutableStateOf<String?>(null) }
    var lastUnknownAlertUsbId by remember { mutableStateOf("") }
    val unknownPhone = vm.usbId.isNotBlank() && (vm.brandName().isBlank() || vm.modelName.isBlank() || vm.modelName == "Not in database" || vm.modelNote.contains("not in the local model database", ignoreCase = true))
    val showUnknownPhoneAlert = unknownPhone && lastUnknownAlertUsbId != vm.usbId
    LaunchedEffect(vm.usbId) { if (vm.usbId.isBlank()) lastUnknownAlertUsbId = "" }
    val context = androidx.compose.ui.platform.LocalContext.current
    MaterialTheme(
        colorScheme = lightColorScheme(primary = C.blue, background = C.bg, surface = C.panel, onSurface = C.text, onBackground = C.text),
        typography = ForgeTypography
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(Color(0xFF030309), RoundedCornerShape(30.dp))
                .clip(RoundedCornerShape(30.dp))
                .border(3.dp, Brush.linearGradient(listOf(Color(0xFFA79DFF), Color(0xFF7D6CFF), Color(0xFF59D3FF))), RoundedCornerShape(30.dp))
                .padding(3.dp)
        ) {
            AppBackground()
            Column(Modifier.fillMaxSize()) {
                GamingHeader(
                    vm,
                    onSettings = { vm.screen = Screen.SETTINGS },
                    onAbout = { vm.screen = Screen.ABOUT }
                )
                GamingTabs(vm.screen) { vm.screen = it }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AnimatedContent(
                        targetState = vm.screen,
                        transitionSpec = {
                            (fadeIn(tween(260)) + scaleIn(initialScale = .975f, animationSpec = tween(300))) togetherWith
                                (fadeOut(tween(160)) + scaleOut(targetScale = .985f, animationSpec = tween(180)))
                        },
                        label = "flashforge-main-screen"
                    ) { screen ->
                        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 5.dp)) {
                            if (screen == Screen.DEVICE || screen == Screen.FLASH || screen == Screen.ROM) {
                                GamingActionStage(
                                    vm = vm,
                                    screen = screen,
                                    onItem = { index ->
                                        when (screen) {
                                            Screen.DEVICE -> pendingGamingAction = when (index) {
                                                0 -> "mode_edl"
                                                1 -> "mode_brom"
                                                2 -> "mode_download"
                                                else -> "mode_fastboot"
                                            }
                                            Screen.FLASH -> when (index) {
                                                0 -> flashSection = "sites"
                                                1 -> flashSection = "phoneFirmware"
                                                2 -> vm.screen = Screen.SAFETY
                                                else -> flashSection = "downloads"
                                            }
                                            Screen.ROM -> { romTab = index.coerceIn(0, 3) }
                                            Screen.LOG -> Unit
                                            else -> Unit
                                        }
                                    },
                                    onHub = {
                                        when (screen) {
                                            Screen.DEVICE -> pendingGamingAction = "restart"
                                            Screen.FLASH -> flashSection = "queue"
                                            Screen.ROM -> { romTab = 1 }
                                            else -> pendingGamingAction = "clear"
                                        }
                                    },
                                    onPanelAction = {
                                        when (screen) {
                                            Screen.DEVICE -> vm.modeGuideTarget = WheelMode.FASTBOOT
                                            Screen.FLASH -> flashSection = "queue"
                                            Screen.ROM -> { romTab = 1 }
                                            Screen.LOG -> vm.exportLog()
                                            else -> Unit
                                        }
                                    }
                                )
                            }
                            Box(Modifier.weight(1f).fillMaxWidth()) {
                                when (screen) {
                                    Screen.DEVICE -> DevicePage(vm)
                                    Screen.FLASH -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                                        FlashPage(
                                            vm, flashSection, { flashSection = it },
                                            wheelAction = flashWheelAction,
                                            onWheelActionConsumed = { flashWheelAction = null }
                                        )
                                    }
                                    Screen.ROM -> RomRootPage(
                                        vm, romTab, { romTab = it },
                                        selectedPartTab = partToolTab,
                                        onPartTabChange = { partToolTab = it }
                                    )
                                    Screen.LOG -> LogPage(
                                        vm, logFilter,
                                        onFilterToggle = { logFilter = !logFilter },
                                        onCopy = {
                                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("FlashForge log", vm.logs.joinToString("\n")))
                                            vm.log("Log copied to clipboard.")
                                        }
                                    )
                                    Screen.RESET -> ResetRepairPage(vm) { vm.screen = Screen.ROM; romTab = 1 }
                                    Screen.CHIPSET -> ChipsetHubPage(vm)
                                    Screen.BACKUP -> BackupHubPage(vm) { vm.screen = Screen.ROM; romTab = 1 }
                                    Screen.SAFETY -> SafetyPage(vm) { vm.screen = Screen.ROM; romTab = 1 }
                                    Screen.SETTINGS -> SettingsPage(vm)
                                    Screen.ABOUT -> AboutPage()
                                }
                            }
                        }
                    }
                }
            }
        }
        GamingConfirmDialog(
            action = pendingGamingAction,
            onDismiss = { pendingGamingAction = null },
            onConfirm = {
                when (pendingGamingAction) {
                    "restart" -> vm.enterMode(WheelMode.SYSTEM)
                    "mode_edl" -> vm.enterMode(WheelMode.EDL)
                    "mode_brom" -> vm.enterMode(WheelMode.BROM)
                    "mode_download" -> vm.enterMode(WheelMode.DOWNLOAD)
                    "mode_fastboot" -> vm.enterMode(WheelMode.FASTBOOT)
                    "flash" -> vm.flashQueue()
                    "clear" -> vm.logs.clear()
                    "unlock" -> { vm.screen = Screen.ROM; romTab = 0 }
                }
                pendingGamingAction = null
            }
        )
        if (showUnknownPhoneAlert) {
            AlertDialog(
                onDismissRequest = { lastUnknownAlertUsbId = vm.usbId },
                title = { Text("UNKNOWN DEVICE — INSTRUCTIONS AVAILABLE", fontWeight = FontWeight.ExtraBold) },
                text = { Text("${vm.vendor.ifBlank { "USB device" }} • ${vm.usbId}\n\nSuggested starting point: FASTBOOT for ordinary bootloader access; Samsung DOWNLOAD only for supported Samsung models; Qualcomm EDL and MediaTek BROM only when the exact model and required authorized loader are verified.\n\nThis phone is not verified in the local model database. FlashForge will show safe mode-entry instructions. Confirm the exact model and hardware variant before firmware, programmer or Download Agent use.") },
                confirmButton = { TextButton(onClick = { lastUnknownAlertUsbId = vm.usbId; vm.screen = Screen.DEVICE }) { Text("OPEN DEVICE GUIDE", color = Color(0xFF48DFFF), fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = { lastUnknownAlertUsbId = vm.usbId }) { Text("LATER", color = Color.Gray) } },
                containerColor = ForgePanel, titleContentColor = Color(0xFFFFC857), textContentColor = Color(0xFFE6E9FF), shape = RoundedCornerShape(22.dp)
            )
        }
        vm.modeGuideTarget?.let { target ->
            val title = when (target) {
                WheelMode.FASTBOOT -> "FASTBOOT ENTRY GUIDE"
                WheelMode.DOWNLOAD -> "DOWNLOAD MODE GUIDE"
                WheelMode.EDL -> "EDL ENTRY GUIDE"
                WheelMode.BROM -> "BROM ENTRY GUIDE"
                else -> "MODE ENTRY GUIDE"
            }
            val steps = when (target) {
                WheelMode.FASTBOOT -> "POWER ON: FlashForge can request ADB reboot-bootloader only if the device accepts the app's current ADB transport. Standard Android ADB normally requires RSA key authentication, which this build does not yet implement, so the request may be refused. POWER OFF: on many supported models hold Volume Down + Power, then connect USB. Exact key sequence varies by model."
                WheelMode.DOWNLOAD -> if (vm.brandName().equals("Samsung", true) || vm.mode == Mode.SAMSUNG_DOWNLOAD) "POWER OFF: on supported Samsung models hold Volume Up + Volume Down while connecting USB, then follow the Download Mode confirmation prompt. The exact sequence varies by generation and model." else "Download Mode is primarily OEM-specific (commonly Samsung). This phone is not verified as compatible. Check its exact model's official service instructions; do not force a generic command."
                WheelMode.EDL -> if (vm.chip.contains("qualcomm", true) || vm.vendor.equals("Qualcomm", true)) "Qualcomm chipset detected, but EDL entry is still model-specific. Some phones need a special key sequence; others require an authorized service procedure or test point. Do not short contacts or use an unverified Firehose programmer." else "EDL is not verified for this chipset/model. It is not a universal Android mode. Check the exact model and chipset before attempting service entry."
                WheelMode.BROM -> if (vm.chip.contains("mediatek", true) || vm.vendor.equals("MediaTek", true)) "MediaTek chipset detected, but BROM availability is model-specific. Power off and use only the exact model's documented Volume-key + USB sequence. A compatible, authorized Download Agent may be required." else "BROM is a MediaTek BootROM mode and is not verified for this chipset/model. Do not try random key combinations or an unrelated Download Agent."
                else -> "Follow the exact OEM instructions for this model."
            }
            AlertDialog(
                onDismissRequest = { vm.dismissModeGuide() },
                title = { Text(title, fontWeight = FontWeight.ExtraBold) },
                text = { Text("${vm.modelName.ifBlank { vm.brandName().ifBlank { "Unknown phone" } }}\n\n$steps\n\nDatabase note: ${vm.modeCompatibility(target) ?: "No exact model-specific entry is available; treat support as unknown."}\n\nA powered-off phone cannot generally receive a software command from Android. FlashForge can detect it only if its boot USB interface enumerates.") },
                confirmButton = { TextButton(onClick = { vm.dismissModeGuide() }) { Text("GOT IT", color = Color(0xFF48DFFF), fontWeight = FontWeight.Bold) } },
                containerColor = ForgePanel, titleContentColor = Color(0xFFFFC857), textContentColor = Color(0xFFE6E9FF), shape = RoundedCornerShape(22.dp)
            )
        }
        if (vm.flashScreenOpen) FlashingScreen(vm)
        vm.cableWarn?.let { why ->
            AlertDialog(
                onDismissRequest = { },
                icon = { Image(painterResource(R.drawable.ic_cable), null, Modifier.size(52.dp)) },
                title = { Text("CHANGE THE DATA CABLE", fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                text = {
                    Column {
                        Text(why, fontFamily = Sans, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Use a short, good quality DATA cable (not a charge-only cable) and plug it straight into the phone or a good OTG adapter, without a hub. The task keeps running; if it fails, swap the cable and run it again.",
                            fontFamily = Sans, fontSize = 13.sp, fontWeight = FontWeight.Medium
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { vm.cableChange() }) { Text("I WILL CHANGE IT", color = C.blue, fontFamily = Sans, fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = { vm.cableContinue() }) { Text("CONTINUE ANYWAY", color = C.dim, fontFamily = Sans, fontWeight = FontWeight.SemiBold) } },
                shape = PanelShape,
                containerColor = C.panel, titleContentColor = C.red, textContentColor = C.text
            )
        }
    }
}
