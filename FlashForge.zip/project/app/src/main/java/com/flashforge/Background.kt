package com.flashforge

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.animation.core.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Decodes a picture chosen from the phone, scaled down so that its longest side is at most [maxSide] pixels. Returns null on any problem. */
fun loadBackgroundBitmap(ctx: Context, uriText: String, maxSide: Int = 1600): ImageBitmap? {
    if (uriText.isBlank()) return null
    return try {
        val uri = Uri.parse(uriText)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (e: Exception) {
        android.util.Log.w("FlashForge", "Background image could not be loaded", e)
        null
    }
}

@Composable
fun BgThumb(choice: Int, bitmap: ImageBitmap?, modifier: Modifier) {
    when {
        choice == 2 && bitmap != null -> Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
        choice == 3 -> Image(painterResource(R.drawable.bg_default_3), null, modifier, contentScale = ContentScale.Crop)
        choice == 4 -> Image(painterResource(R.drawable.bg_default_4), null, modifier, contentScale = ContentScale.Crop)
        choice == 5 -> Image(painterResource(R.drawable.bg_default_5), null, modifier, contentScale = ContentScale.Crop)
        choice == 6 -> Image(painterResource(R.drawable.bg_default_6), null, modifier, contentScale = ContentScale.Crop)
        choice == 7 -> Image(painterResource(R.drawable.bg_default_7), null, modifier, contentScale = ContentScale.Crop)
        choice == 8 -> Image(painterResource(R.drawable.bg_default_8), null, modifier, contentScale = ContentScale.Crop)
        choice == 9 -> Image(painterResource(R.drawable.bg_default_9), null, modifier, contentScale = ContentScale.Crop)
        else -> Image(painterResource(R.drawable.bg_default_10), null, modifier, contentScale = ContentScale.Crop)
    }
}

/** Black gaming wallpaper with restrained slow-motion white light streaks and particles. */
@Composable
fun AppBackground() {
    val ctx = LocalContext.current
    val choice = AppSettings.bgChoice
    val uri = AppSettings.bgUri
    val custom by produceState<ImageBitmap?>(null, choice, uri) {
        value = if (choice == 2) withContext(Dispatchers.IO) { loadBackgroundBitmap(ctx, uri) } else null
    }
    val transition = rememberInfiniteTransition(label = "cyberForgeWallpaper")
    val travel by transition.animateFloat(0f, 1f, animationSpec = infiniteRepeatable(
        animation = tween(26000, easing = LinearEasing), repeatMode = RepeatMode.Restart), label = "energyTravel")
    val pulse by transition.animateFloat(.10f, .27f, animationSpec = infiniteRepeatable(
        animation = tween(7200, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse), label = "neonPulse")
    Box(Modifier.fillMaxSize().background(Color(0xFF03040A))) {
        if (choice == 2 && custom != null) {
            Image(custom!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Image(painterResource(R.drawable.bg_cyberforge), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x883B145E), Color(0x665E174F), Color(0x44320D45), Color(0x6642DCEB)))))
        Canvas(Modifier.fillMaxSize()) {
            val cyan = Color(0xFF31DFFF).copy(alpha = pulse * .55f)
            val violet = Color(0xFFB34CFF).copy(alpha = pulse * .48f)
            // Fine HUD/circuit traces are kept near the edges so text and controls remain readable.
            for (i in 0..6) {
                val y = size.height * (.07f + i * .145f)
                drawLine(Color(0xFF9DBBFF).copy(alpha=.075f), Offset(0f,y), Offset(size.width*.12f,y), 1.dp.toPx())
                drawLine(Color(0xFF9DBBFF).copy(alpha=.075f), Offset(size.width,y), Offset(size.width*.88f,y), 1.dp.toPx())
                drawCircle(cyan, 1.7.dp.toPx(), Offset(size.width*.12f,y))
                drawCircle(violet, 1.7.dp.toPx(), Offset(size.width*.88f,y))
            }
            val x1 = size.width * (.02f + .16f * travel)
            val x2 = size.width * (.98f - .16f * travel)
            drawLine(cyan, Offset(x1,size.height*.16f), Offset(x1+size.width*.10f,size.height*.12f), 1.8.dp.toPx())
            drawLine(violet, Offset(x2,size.height*.82f), Offset(x2-size.width*.11f,size.height*.87f), 1.8.dp.toPx())
            for (i in 0..23) {
                val phase = (travel + i*.061f) % 1f
                val x = size.width * ((i*.173f + phase*.085f) % 1f)
                val y = size.height * ((i*.239f + phase*.13f) % 1f)
                val a = .035f + .075f*(1f-phase)
                drawCircle(if (i%2==0) Color(0xFFB7F5FF).copy(alpha=a) else Color(0xFFD9A7FF).copy(alpha=a), (1f+(i%3)*.35f).dp.toPx(), Offset(x,y))
            }
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha=.14f), Color.Transparent, Color.Black.copy(alpha=.22f)))))
    }
}
