package com.flashforge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/** Shared live state between the view model, the floating bubble and the notification. */
object FlashStatus {
    @Volatile var running = false
    @Volatile var label = ""
    @Volatile var progress = 0f
    @Volatile var speed = 0.0
    @Volatile var warn = false
    @Volatile var warnText = ""
    @Volatile var warnSeq = 0
    @Volatile var result = 0      // 0 none, 1 finished, 2 failed
    @Volatile var connectionSignal = 0 // 0 red/disconnected, 1 yellow/checking, 2 green/ready
    @Volatile var errorText = ""
    @Volatile var appFg = true
    @Volatile var bubbleOn = true
}

/** The round floating bubble drawn on top of every app. */
class BubbleView(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val navy = 0xFF0B1F35.toInt()
    private val green = 0xFF22C55E.toInt()
    private val yellow = 0xFFFACC15.toInt()
    private val red = 0xFFEF4444.toInt()
    private val cyan = 0xFF35D6E8.toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true; typeface = android.graphics.Typeface.MONOSPACE }
    private val rect = RectF()

    override fun onDraw(cv: Canvas) {
        val s = FlashStatus
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val error = s.result == 2 || s.errorText.isNotBlank()
        val pct = (s.progress * 100f).toInt().coerceIn(0, 100)
        val speed = if (s.speed.isFinite()) String.format(java.util.Locale.US, "%.1f MB/s", s.speed.coerceAtLeast(0.0)) else "0.0 MB/s"
        val signalColor = when {
            s.result == 2 || s.errorText.isNotBlank() || s.connectionSignal == 0 -> red
            s.warn || s.connectionSignal == 1 -> yellow
            else -> green
        }

        fill.color = navy
        if (error) {
            rect.set(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d)
            cv.drawRoundRect(rect, 22f * d, 22f * d, fill)
            // Error state expands only while an actual error needs to be readable.
            fill.color = signalColor
            cv.drawCircle(16f * d, 16f * d, 5f * d, fill)
            txt.color = 0xFFFFFFFF.toInt()
            txt.textSize = 20f * d
            cv.drawText("$pct%", cx, 47f * d, txt)
            txt.textSize = 10f * d
            txt.color = 0xFFB7D9E8.toInt()
            cv.drawText(speed, cx, 65f * d, txt)
            txt.color = 0xFFFF7777.toInt()
            txt.textSize = 9f * d
            val msg = (s.errorText.ifBlank { s.warnText }).replace('\n', ' ').trim()
            val first = msg.take(30)
            val second = msg.drop(first.length).take(30)
            cv.drawText(first, cx, 88f * d, txt)
            if (second.isNotBlank()) cv.drawText(second, cx, 101f * d, txt)
        } else {
            cv.drawCircle(cx, cx, w / 2f - 1.5f * d, fill)
            fill.color = signalColor
            cv.drawCircle(cx, 12f * d, 4.5f * d, fill)
            txt.color = 0xFFFFFFFF.toInt()
            txt.textSize = 20f * d
            cv.drawText("$pct%", cx, 62f * d, txt)
            txt.color = 0xFFB7D9E8.toInt()
            txt.textSize = 9.5f * d
            cv.drawText(speed, cx, 80f * d, txt)
        }
        if (s.running) postInvalidateOnAnimation()
    }
}

/**
 * Foreground service. Keeps the process alive while a flash runs in the background, shows a progress
 * notification, and draws a compact live-status bubble with LED, percentage, speed and inline error text (needs overlay permission).
 */
class BubbleService : Service() {
    companion object {
        const val CH_RUN = "flashforge_run"
        const val CH_ALERT = "flashforge_alert"
        const val ID_RUN = 41
        const val ID_ALERT = 42
    }

    private var wm: WindowManager? = null
    private var view: BubbleView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private var doneAt = 0L
    private var lastKey = ""
    private var lastWarnSeq = 0
    private var finishPosted = false
    private val sizePx get() = (112 * resources.displayMetrics.density).toInt()
    private val errorWidthPx get() = (180 * resources.displayMetrics.density).toInt()
    private val errorHeightPx get() = (116 * resources.displayMetrics.density).toInt()
    private val marginPx get() = (6 * resources.displayMetrics.density).toInt()

    private val tick = object : Runnable {
        override fun run() {
            step()
            h.postDelayed(this, 250)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Flash progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Flash alerts", NotificationManager.IMPORTANCE_HIGH))
        ServiceCompat.startForeground(this, ID_RUN, buildNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        lastWarnSeq = FlashStatus.warnSeq
        addBubble()
        h.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        doneAt = 0L
        finishPosted = false
        if (view == null) addBubble()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { view?.let { wm?.removeView(it) } } catch (e: Exception) { android.util.Log.w("FlashForgeBubble", "Bubble view cleanup failed", e) }
        view = null
        super.onDestroy()
    }

    private fun appIntent(): Intent =
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(MainActivity.EXTRA_SCREEN, "FLASH")

    private fun contentPi(): PendingIntent =
        PendingIntent.getActivity(this, 0, appIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun openApp() {
        try { startActivity(appIntent()) } catch (e: Exception) {
            try { contentPi().send() } catch (e2: Exception) { android.util.Log.e("FlashForgeBubble", "Could not open app from bubble", e2) }
        }
    }

    private fun addBubble() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = BubbleView(this)
            val p = WindowManager.LayoutParams(
                sizePx, sizePx,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = resources.displayMetrics.widthPixels - sizePx - marginPx
            p.y = (160 * resources.displayMetrics.density).toInt()
            v.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0
                var sy = 0
                var tx = 0f
                var ty = 0f
                var moved = false
                override fun onTouch(view: View, e: MotionEvent): Boolean {
                    val q = lp ?: return false
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = q.x; sy = q.y; tx = e.rawX; ty = e.rawY; moved = false }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = e.rawX - tx
                            val dy = e.rawY - ty
                            if (abs(dx) > 12f || abs(dy) > 12f) moved = true
                            if (moved) {
                                q.x = sx + dx.toInt()
                                q.y = sy + dy.toInt()
                                try { wm?.updateViewLayout(view, q) } catch (ex: Exception) { android.util.Log.w("FlashForgeBubble", "Could not update bubble position", ex) }
                            }
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!moved) { view.visibility = View.GONE; openApp() } else {
                                val sw = resources.displayMetrics.widthPixels
                                q.x = if (q.x + sizePx / 2 < sw / 2) marginPx else sw - sizePx - marginPx
                                try { wm?.updateViewLayout(view, q) } catch (ex: Exception) { android.util.Log.w("FlashForgeBubble", "Could not update bubble position", ex) }
                            }
                        }
                    }
                    return true
                }
            })
            manager.addView(v, p)
            wm = manager
            view = v
            lp = p
        } catch (e: Exception) {
            view = null
        }
    }

    private fun buildNotif(): Notification {
        val s = FlashStatus
        val pct = (s.progress * 100).toInt().coerceIn(0, 100)
        val title = when {
            s.running && s.warn -> "Check the data cable"
            s.running -> "FlashForge  " + s.label
            s.result == 1 -> "Finished"
            s.result == 2 -> "Failed"
            else -> "FlashForge"
        }
        val text = when {
            s.running && s.warn -> s.warnText
            s.running -> "$pct%" + (if (s.speed > 0.0) "   " + String.format("%.1f", s.speed) + " MB/s" else "")
            else -> s.label
        }
        val b = NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFFE4501A.toInt())
            .setContentIntent(contentPi())
        if (s.running) b.setProgress(100, pct, s.progress <= 0f)
        return b.build()
    }

    private fun alert(title: String, text: String) {
        try {
            val n = NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setColor(0xFFE53935.toInt())
                .setContentIntent(contentPi())
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_ALERT, n)
        } catch (e: Exception) { android.util.Log.e("FlashForgeBubble", "Could not post bubble alert notification", e) }
    }

    private fun step() {
        val s = FlashStatus
        val now = System.currentTimeMillis()
        if (!s.running) {
            if (s.result == 0) { stopSelf(); return }
            if (doneAt == 0L) doneAt = now
            if (!finishPosted) {
                finishPosted = true
                if (!s.appFg) alert(if (s.result == 1) "FlashForge finished" else "FlashForge failed", s.label)
            }
            if (now - doneAt > 8000L) { stopSelf(); return }
        } else {
            doneAt = 0L
            finishPosted = false
        }
        val showBubble = !s.appFg && s.bubbleOn && (s.running || (s.result == 2 && doneAt > 0L && now - doneAt <= 8000L))
        view?.visibility = if (showBubble) View.VISIBLE else View.GONE
        val errorMode = s.result == 2 || s.errorText.isNotBlank()
        lp?.let { params ->
            val targetW = if (errorMode) errorWidthPx else sizePx
            val targetH = if (errorMode) errorHeightPx else sizePx
            if (params.width != targetW || params.height != targetH) {
                params.width = targetW
                params.height = targetH
                try { view?.let { wm?.updateViewLayout(it, params) } } catch (e: Exception) { android.util.Log.w("FlashForgeBubble", "Could not resize bubble", e) }
            }
        }
        view?.invalidate()
        val pct = (s.progress * 100).toInt()
        val key = "${s.running}|$pct|${s.warn}|${s.result}|${s.speed.toInt()}"
        if (key != lastKey) {
            lastKey = key
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_RUN, buildNotif())
        }
        if (s.warnSeq != lastWarnSeq) {
            lastWarnSeq = s.warnSeq
            if (s.warn && !s.appFg) alert("Change the data cable", s.warnText)
        }
    }
}
