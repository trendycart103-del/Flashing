package com.flashforge

/** Small shared UI dictionary. Dynamic/device-provided values are intentionally not translated. */
object AppStrings {
    private val bn = mapOf(
        "Ready" to "প্রস্তুত",
        "APPEARANCE & LANGUAGE" to "চেহারা ও ভাষা", "DEVICE AND CONNECTION" to "ডিভাইস ও সংযোগ", "FLASHING AND SAFETY" to "ফ্ল্যাশ ও নিরাপত্তা",
        "DEVICE" to "ডিভাইস", "FLASH" to "ফ্ল্যাশ", "PARTITION" to "পার্টিশন", "ROM & Root" to "ROM ও Root",
        "LOG" to "লগ", "SAFETY" to "নিরাপত্তা", "SETTINGS" to "সেটিংস",
        "Appearance & language" to "চেহারা ও ভাষা", "App language" to "অ্যাপের ভাষা", "Background image" to "ব্যাকগ্রাউন্ড ছবি",
        "Text size" to "লেখার আকার", "Device and connection" to "ডিভাইস ও সংযোগ", "USB host support" to "USB Host সমর্থন",
        "Available on this phone" to "এই ফোনে উপলব্ধ", "Not reported by this phone" to "ফোন থেকে তথ্য পাওয়া যায়নি",
        "OTG and USB settings" to "OTG ও USB সেটিংস", "Open Android system connection settings" to "Android সংযোগ সেটিংস খুলুন",
        "Slow transfer warning" to "ধীর ট্রান্সফার সতর্কতা", "Disconnect warning limit" to "সংযোগ বিচ্ছিন্ন সতর্কতার সীমা",
        "Flashing and safety" to "ফ্ল্যাশ ও নিরাপত্তা", "Minimum controller battery" to "কন্ট্রোলার ফোনের ন্যূনতম ব্যাটারি",
        "Default backup partition" to "ডিফল্ট ব্যাকআপ পার্টিশন", "Default recovery partition" to "ডিফল্ট Recovery পার্টিশন",
        "Default patched image partition" to "ডিফল্ট প্যাচড ইমেজ পার্টিশন", "Advanced preferences" to "অ্যাডভান্সড সেটিংস",
        "Log history and connection sampling" to "লগ ও সংযোগ পর্যবেক্ষণ", "Connection samples before warning" to "সতর্কতার আগে সংযোগ নমুনা",
        "Maximum log entries" to "সর্বোচ্চ লগ এন্ট্রি", "Default partition" to "ডিফল্ট পার্টিশন",
        "Partition name" to "পার্টিশনের নাম", "Save" to "সেভ", "Cancel" to "বাতিল", "Close" to "বন্ধ",
        "Choose from phone" to "ফোন থেকে নির্বাচন", "My image" to "আমার ছবি", "Use selected phone image" to "নির্বাচিত ছবি ব্যবহার করুন",
        "Selected" to "নির্বাচিত", "Select" to "নির্বাচন", "App language" to "অ্যাপের ভাষা",
        "Connect a phone in Fastboot or recovery ADB mode to use these buttons." to "এই বাটন ব্যবহার করতে ফোন Fastboot অথবা Recovery ADB মোডে সংযুক্ত করুন।",
        "NOT CONNECTED" to "সংযুক্ত নয়", "Connecting" to "সংযোগ হচ্ছে", "Connected" to "সংযুক্ত",
        "Unknown USB device. Put the phone into a known mode using the guide below." to "অজানা USB ডিভাইস। নিচের নির্দেশনা অনুসারে ফোনকে পরিচিত মোডে রাখুন।",
        "Queue is empty. Add images in the order they must be flashed." to "কিউ খালি। ফ্ল্যাশ করার ক্রম অনুযায়ী ইমেজ যোগ করুন।",
        "Nothing downloaded yet." to "এখনো কিছু ডাউনলোড হয়নি।", "No image preflight has run in this session yet. The first flash attempt will run it automatically." to "এই সেশনে এখনো ইমেজ প্রি-ফ্লাইট পরীক্ষা হয়নি। প্রথম ফ্ল্যাশের আগে স্বয়ংক্রিয়ভাবে পরীক্ষা হবে।",
        "Keep the cable connected. Do not close the app." to "কেবল সংযুক্ত রাখুন। অ্যাপ বন্ধ করবেন না।", "Waiting for the analyzer..." to "Analyzer-এর জন্য অপেক্ষা হচ্ছে...",
        "IMAGE" to "ইমেজ", "STATUS" to "অবস্থা", "FILE" to "ফাইল", "PARTITION" to "পার্টিশন", "STATE" to "স্টেট",
        "SLOTS" to "স্লট", "SKIPPED" to "এড়িয়ে যাওয়া", "USE" to "ব্যবহার", "RESTART" to "রিস্টার্ট", "CONFIRM" to "নিশ্চিত", "CANCEL" to "বাতিল"
    )

    fun text(value: String, language: String = AppSettings.language): String = if (language == "bn") bn[value] ?: value else value
}

fun localized(value: String): String = AppStrings.text(value)
