package com.flashforge

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun AboutPage() {
    val ctx = LocalContext.current
    val bn = AppSettings.language == "bn"
    val title = if (bn) "FlashForge সম্পর্কে" else "About FlashForge"
    val intro = if (bn) {
        "আমি মুহাম্মদ রবিউল হাসান, একজন সফটওয়্যার ডেভেলপার ও প্রযুক্তিপ্রেমী। নতুন কিছু শেখা, প্রযুক্তির মাধ্যমে বাস্তব সমস্যার সমাধান করা এবং নিজের চিন্তাকে সৃজনশীল কাজে রূপ দিতে ভালোবাসি। আমার লক্ষ্য প্রযুক্তিকে মানুষের জন্য আরও সহজ, কার্যকর ও উপকারী করে তোলা।"
    } else {
        "I'm MD Robiul Hasan, a software developer and technology enthusiast. I enjoy learning, solving practical problems with technology, and turning ideas into useful creations. My goal is to make technology easier, more effective, and helpful for people."
    }
    val qualities = if (bn) listOf("নিরন্তর শেখার আগ্রহ", "সৃজনশীল চিন্তা", "সমস্যা সমাধানের চেষ্টা", "পরিশ্রম ও অধ্যবসায়", "দায়িত্বশীলতা", "উন্নতির মানসিকতা") else listOf("Continuous learning", "Creative thinking", "Problem-solving mindset", "Hard work and persistence", "Responsibility", "Growth mindset")
    val quote = if (bn) "শেখার কোনো শেষ নেই, আর সৃষ্টির কোনো সীমা নেই। প্রতিটি ছোট পদক্ষেপই বড় সাফল্যের পথে এগিয়ে যাওয়ার একটি নতুন সুযোগ।" else "There is no end to learning, and no limit to creativity. Every small step is a new opportunity to move toward greater achievements."
    val learning = if (bn) "প্রযুক্তি, সফটওয়্যার ও মোবাইল ডিভাইস নিয়ে কাজ করতে করতে প্রতিদিন নতুন কিছু শেখার চেষ্টা করি। শেখার পথ চলা কখনো শেষ হয় না।" else "Working with technology, software, and mobile devices is a continuous learning journey. There is always something new to discover."
    val instructions = if (bn) listOf(
        "প্রথমে Device পেজে USB সংযোগ ও ডিভাইসের অবস্থা পরীক্ষা করুন।",
        "Flash বা অন্য কোনো কাজ করার আগে সঠিক মডেল ও Firmware compatibility যাচাই করুন।",
        "Firmware ফাইল ব্যবহার করার আগে উৎস, ফাইলের অখণ্ডতা এবং SHA-256 যাচাই করুন—যেখানে যাচাই সুবিধা উপলব্ধ।",
        "USB সংযোগে ভালো Data Cable ব্যবহার করুন এবং ফোনে প্রয়োজনীয় অনুমতি দিন।",
        "কোনো সতর্কতা বা Unsupported স্ট্যাটাস দেখালে সেটি উপেক্ষা করবেন না।"
    ) else listOf(
        "Start on the Device page to check USB connection and device status.",
        "Confirm the exact model and firmware compatibility before any operation.",
        "Check source, file integrity, and SHA-256 where verification is available.",
        "Use a quality data cable and grant required device permissions.",
        "Do not ignore warnings or unsupported status messages."
    )
    val safety = if (bn) "FlashForge কিছু ডিভাইস ও প্রোটোকলে সীমিত বা কেবল Read-only তথ্য দিতে পারে। অসমর্থিত বা নিরাপত্তা-সংবেদনশীল অপারেশন চালানো হয় না। ভুল Firmware, USB বিচ্ছিন্নতা বা অনুপযুক্ত প্রক্রিয়ায় ডিভাইস ক্ষতিগ্রস্ত হতে পারে। গুরুত্বপূর্ণ ডেটা ব্যাকআপ রাখুন এবং প্রস্তুতকারকের অফিসিয়াল নির্দেশনা অনুসরণ করুন।" else "Some devices and protocols may be limited or read-only. Unsupported or security-sensitive operations are not executed. Incorrect firmware, USB disconnection, or improper procedures can damage a device. Back up important data and follow official manufacturer guidance."

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Image(painterResource(R.drawable.developer_photo), contentDescription = if (bn) "ডেভেলপারের ছবি" else "Developer photo", modifier = Modifier.size(126.dp).clip(RoundedCornerShape(22.dp)))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("FlashForge", fontWeight = FontWeight.Bold, color = C.blue)
                    Text(if (bn) "ডেভেলপার পরিচিতি" else "Developer Profile", color = C.dim)
                    Text("MD Robiul Hasan", fontWeight = FontWeight.Bold, color = C.text)
                    Text("মুহাম্মদ রবিউল হাসান", fontWeight = FontWeight.Bold, color = C.text)
                    Text(if (bn) "Software Developer" else "Software Developer", color = C.blue)
                }
            }
        }
        InfoCard {
            SectionHeading(if (bn) "যোগাযোগ" else "Contact Information")
            ContactRow("⌖", if (bn) "কসবা, ব্রাহ্মণবাড়িয়া" else "Kasba, Brahmanbaria")
            ContactRow("✉", "softcare2016@gmail.com", Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:softcare2016@gmail.com"))) } })
            ContactRow("☎", "+8801703315191", Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+8801703315191"))) } })
            ContactRow("☎", "+8801913929920", Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+8801913929920"))) } })
        }
        InfoCard {
            SectionHeading(if (bn) "আমার সম্পর্কে" else "About Me")
            Text(intro, color = C.text, textAlign = TextAlign.Start)
        }
        InfoCard {
            SectionHeading(if (bn) "আমার কিছু গুণাবলী" else "My Qualities")
            qualities.forEach { Text("✓  $it", color = C.text, modifier = Modifier.padding(vertical = 3.dp)) }
        }
        InfoCard {
            SectionHeading(if (bn) "অনুপ্রেরণামূলক উক্তি" else "Inspirational Quote")
            Text("“$quote”", color = C.blue, fontWeight = FontWeight.SemiBold)
            Text("— MD Robiul Hasan", color = C.dim)
        }
        InfoCard {
            SectionHeading(if (bn) "শেখার অভিজ্ঞতা" else "Learning Journey")
            Text(learning, color = C.text)
        }
        InfoCard {
            SectionHeading(if (bn) "ব্যবহারের নির্দেশনা" else "Quick Instructions")
            instructions.forEachIndexed { index, item -> Text("${index + 1}. $item", color = C.text, modifier = Modifier.padding(vertical = 3.dp)) }
        }
        InfoCard {
            SectionHeading(if (bn) "নিরাপত্তা নির্দেশনা" else "Safety Notice")
            Text(safety, color = C.text)
        }
        InfoCard {
            Text("FlashForge", fontWeight = FontWeight.Bold, color = C.blue)
            Text(if (bn) "Android Device Diagnostic & Firmware Utility" else "Android Device Diagnostic & Firmware Utility", color = C.dim)
            Text(if (bn) "ধন্যবাদ FlashForge ব্যবহার করার জন্য।" else "Thank you for using FlashForge.", color = C.text)
            Text("Build ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) · ${BuildConfig.UI_LAYOUT_ID}", color = C.blue, fontWeight = FontWeight.Bold)
            Text(if (bn) "Developed with Passion" else "Developed with Passion", color = C.blue, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
        .background(Brush.verticalGradient(listOf(C.panel.copy(alpha = 1f), C.panel.copy(alpha = 0.94f))))
        .border(1.2.dp, C.blue.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
        .padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
private fun SectionHeading(text: String) {
    Text(text, color = Color(0xFF43206F), fontWeight = FontWeight.ExtraBold)
}

@Composable
private fun ContactRow(icon: String, value: String, modifier: Modifier = Modifier) {
    Row(Modifier.fillMaxWidth().then(modifier).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(icon, color = C.blue, fontWeight = FontWeight.Bold)
        Text(value, color = C.text)
    }
}
