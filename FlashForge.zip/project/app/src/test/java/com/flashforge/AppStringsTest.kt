package com.flashforge

import org.junit.Assert.assertEquals
import org.junit.Test

class AppStringsTest {
    @Test fun banglaDictionaryTranslatesKnownLabels() {
        assertEquals("সেটিংস", AppStrings.text("SETTINGS", "bn"))
        assertEquals("প্রস্তুত", AppStrings.text("Ready", "bn"))
    }
    @Test fun englishKeepsOriginalLabels() {
        assertEquals("SETTINGS", AppStrings.text("SETTINGS", "en"))
    }
    @Test fun unknownStringsRemainUnmodified() {
        assertEquals("model-xyz", AppStrings.text("model-xyz", "bn"))
    }
}
