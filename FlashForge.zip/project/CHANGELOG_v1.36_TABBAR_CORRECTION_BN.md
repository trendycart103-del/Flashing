# v1.36 — Top Tab Bar Correction
- Fixed top-level navigation: horizontal tabs instead of a radial wheel.
- Tabs: DEVICE, FLASH, ROM, LOG, SAFETY, SETTINGS, ABOUT.
- Added compact 3D-style tab containers, selected-state neon border and press feedback.
- Preserved the in-page radial action wheels for Flash and ROM & Root.
- Android build was not run in this environment.
