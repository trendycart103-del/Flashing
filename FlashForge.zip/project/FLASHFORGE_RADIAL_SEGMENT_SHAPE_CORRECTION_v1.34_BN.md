# FlashForge Radial Segment Shape Correction — v1.34

## User Reference Shape (Locked)

The required button shape is the segmented radial/pie-wedge shape shown in the supplied circular wheel reference. It is **not** an individual circular button, round icon badge, rounded rectangle, or generic card.

- Circular center hub with radial segments around it.
- Each feature occupies a wedge bounded by inner and outer arcs and radial edges.
- Keep the wedge arrangement, proportions, spacing, and neon-outline language aligned to the reference image.
- Use supplied 3D icon pack assets without redesigning their artwork.
- Labels must stay within segment bounds. If a label cannot fit clearly, omit it and use the icon only.
- On press: the wedge should have a 3D down/up feedback, not morph into a circle.
- Border color transitions are slow and smooth; no abrupt flashing.
- Do not introduce unrelated colors, drawings, shapes, or redesigns.

## Existing project components inspected

- `Ui.kt`: main navigation already draws seven radial wedge segments around the center hub. Its tap zones are based on radius and angle; labels and icon assets are overlaid within wedges.
- `Pages.kt`: Flash tools and ROM & Root action wheels already draw radial wedge segments. These are the correct shape family to retain, not the rectangular tile mockups.
- `ModeWheel.kt`: device-mode selection is already a segmented radial wheel.

## Scope and verification

This archive records the corrected reference-shape requirement and retains the existing radial-segment implementations. A complete conversion of every remaining conventional action control across Device, Log, Safety, Settings, and other content pages to radial-segment menus is **not yet implemented** in this revision. No Gradle wrapper is included in this project archive and a build has not been verified.
