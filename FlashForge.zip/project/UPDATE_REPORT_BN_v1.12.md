# FlashForge v1.12 Update Report (Bangla)

## User-requested fixes
- `Pages.kt` Device Analyzer guidance duplicate “the reported product ID” corrected.
- Logical partition CREATE/RESIZE/DELETE controls now require explicit confirmation and call guarded Fastboot commands. The Safety Gate checks exact expected product, confident OEM, controller battery, Fastbootd mode, verified `super` size, logical-partition existence state, name and size. Generic dynamic-partition group free-space/metadata geometry cannot be proven; bootloader/OEM validation remains required and may reject operations.
- Removed analysis-only `FlashReadinessAudit.kt`, its unit test and its standalone report.
- Firmware downloads now retain URL-specific partial files and attempt HTTP Range resume with strict `206 Content-Range` offset/total validation. If the server ignores Range, transfer restarts from byte zero.
- App-created backup restore added: product ID, metadata, exact file size and SHA-256 must match; restore is sent through the existing flash Safety Analyzer.
- Interrupted current-image flash recovery added: it rehashes saved URI and restarts the image from byte zero after fresh checks. Arbitrary byte-level Fastboot transfer resume is not claimed.
- Device database expanded from 6 to 34 model/codename profiles, vendor map remains 18 entries, firmware brand-link groups expanded from 17 to 22. Profile notes warn that variants/regions are not interchangeable.
- README and current report updated; old reports labeled historical/superseded.
- Version bumped to 1.12 / versionCode 11.

## Device database
### USB Vendor IDs (18)
`04e8` Samsung, `18d1` Google, `05c6` Qualcomm, `0e8d` MediaTek, `22b8` Motorola, `2717` Xiaomi, `2a70` OnePlus, `12d1` Huawei, `0fce` Sony, `1004` LG, `0bb4` HTC, `1782` Unisoc, `0b05` ASUS, `19d2` ZTE, `22d9` OPPO, `2d95` Vivo, `0489` Foxconn/HMD, `1bbb` TCL/Alcatel.

### Model/codename profiles (34)
Google: sunfish (Pixel 4a), oriole (Pixel 6), panther (Pixel 7), redfin (Pixel 5), bluejay (Pixel 6a), cheetah (Pixel 7 Pro), lynx (Pixel 7a), shiba (Pixel 8), husky (Pixel 8 Pro), akita (Pixel 8a), tokay (Pixel 9), caiman (Pixel 9 Pro), komodo (Pixel 9 Pro XL).
Xiaomi: ginkgo (Redmi Note 8), fire (Redmi 12 4G), sweet (Redmi Note 10 Pro), surya (POCO X3 NFC), alioth (POCO F3/selected Redmi K40 variants), rosemary (Redmi Note 10S), spes (selected Redmi Note 11 4G), redwood (POCO X5 Pro), marble (POCO F5/selected Redmi Note 12 Turbo), peridot (POCO F6).
OnePlus: fajita (OnePlus 6T), hotdogb (OnePlus 7T), kebab (OnePlus 8T), lemonade (OnePlus 9), avicii (Nord), billie (Nord N10 5G).
Motorola: rhode (Moto G52), bang (Moto G84 5G), nio (Moto G100).
Nothing: spacewar (Phone 1), pong (Phone 2).

### Firmware link groups (22)
Samsung, Xiaomi, Google, Motorola, OnePlus, Sony, Huawei, OPPO, Vivo, ASUS, LG, HTC, ZTE, Foxconn/HMD, Infinix, Tecno, Walton, Realme, Nothing, Honor, Fairphone, Lenovo.

## Validation
- ZIP integrity and XML/JSON resource parsing: performed after packaging.
- Source review: performed for changed controls, download flow, backup restore and interrupted-image recovery.
- Full Android compile, Android lint, unit test suite, emulator and real USB hardware validation: **not performed** because this environment has no Gradle wrapper/Gradle Android SDK.
- Logical partition operations remain high-risk; fastbootd and OEM group metadata are not universally queryable. Use only with a verified device-specific recovery path.
- Download resume requires server support for HTTP Range; backup restore and flash resume are app-created backup/current-image recovery only.
