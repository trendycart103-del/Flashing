**ঐতিহাসিক রিপোর্ট:** এই রিপোর্টের বর্তমান-অবস্থা অংশগুলো v1.12 দ্বারা superseded। বর্তমান Logical Partition, Resume, Restore ও Database অবস্থা `UPDATE_REPORT_BN_v1.12.md` এবং README-তে দেখুন।

---

# FlashForge Android — সম্মিলিত আপডেট রিপোর্ট v1.8

## এই সংস্করণে বাস্তব পরিবর্তন
- Version: 1.7 → 1.8 (versionCode 7 → 8)
- নতুন `AppStrings.kt` dictionary যোগ করা হয়েছে। Shared `T()` text helper, Settings-এর PreferenceRow/SettingGroup, এবং bottom navigation labels এখন নির্বাচিত Bangla ভাষায় পরিচিত স্থির UI label অনুবাদ করতে পারে। English নির্বাচন করলে মূল English label রাখা হয়।
- Settings-এর কয়েকটি dialog/action label localization helper ব্যবহার করে।
- Firmware Source Resolver-এ brand-name normalization যোগ করা হয়েছে: Samsung Electronics, Google Pixel, Redmi/Poco, Moto, Nokia/HMD ইত্যাদি সাধারণ alias canonical brand-এ map করে official portal/domain-scoped search links পেতে পারে।
- Localization dictionary-র জন্য unit test source যোগ করা হয়েছে।

## যা এই আপডেটে এখনো সম্পূর্ণ নয়
- সম্পূর্ণ app-wide বাংলা অনুবাদ নয়। Dictionary-তে থাকা স্থির label-গুলো অনুবাদ হয়; dynamic strings, raw Compose `Text`, logs, protocol/error messages, সব dialog এবং সব page-এর text এখনও সম্পূর্ণ localized নয়।
- Firmware Resolver এখনও manufacturer support portal ও domain-scoped search link দেয়; এটি সব model/region-এর authenticated direct firmware URL resolver নয়।
- Qualcomm EDL, MediaTek BROM, Samsung Download, Unisoc FDL write protocol engines এই build-এ enabled নয়। Detection/metadata UI-কে write capability হিসেবে গণ্য করা যাবে না।
- Backup/Restore end-to-end workflow সম্পূর্ণ নয়; Fastboot fetch support সীমিত ডিভাইসে নির্ভরশীল।
- Signature/trust verification, complete package compatibility database, robust download resume, full restore verification এখনও অসম্পূর্ণ।

## যাচাই
- ZIP archive integrity ও source structure পরীক্ষা করা হয়েছে।
- XML/JSON parse validation করা হয়েছে (নিচের final report-এ নির্দিষ্ট ফল)।
- Android Gradle build, APK, emulator, physical USB/device tests চালানো হয়নি: পরিবেশে Gradle/Android SDK/wrapper নেই।
- Unit tests লেখা হয়েছে, কিন্তু চালানো হয়নি।

## নিরাপত্তা/সক্ষমতা
- Chipset write engine fail-closed রাখা হয়েছে। Optional loader/DA/FDL file selection execution নয়। OEM authorization ও model-specific protocol requirements bypass করা হয় না।
- unsupported destructive operations disabled রাখা হয়েছে।
