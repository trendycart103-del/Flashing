# Changelog v1.35
- Fixed Canvas `size` shadowing by renaming outer wheel dimension variable to `wheelSize`.
- Added Compose `offset` import for radial icon/label placement.
- Updated radial wheel size references.
