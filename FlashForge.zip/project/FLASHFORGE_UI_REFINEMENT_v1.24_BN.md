# FlashForge v1.24 — UI refinement (Bangla)

- Bottom tab navigation compact করা হয়েছে: item width 86dp থেকে 74dp, icon/socket, label, indicator ও vertical spacing ছোট করা হয়েছে।
- Tab button palette dark/blurred appearance থেকে bright silver/steel gradient-এ নেওয়া হয়েছে; border ও selected-state contrast হালকা করা হয়েছে।
- Device page-এর স্থায়ী DETECTED DEVICE panel সরানো হয়েছে।
- USB device শনাক্ত হলে অ্যাপের সামনে একটি অ্যাপের UI-এর ওপর সাময়িক floating connection card দেখায় (অন্য অ্যাপের ওপর Android system overlay নয়); এতে vendor, USB ID, mode এবং connection readiness দেখা যায়। × চাপলে ওই সংযোগের জন্য card লুকানো যায়; নতুন device এলে আবার দেখায়।
- Flash/ROM/Safety/Settings এবং device identification/flash safety logic অপরিবর্তিত রাখার লক্ষ্য রাখা হয়েছে।
- Kotlin compile-এর আগের import সমস্যা এড়াতে Ui.kt-তে unsupported Shadow text styling বাদ, Background.kt-তে matchParentSize import যোগ করা হয়েছে।

Build status: এই পরিবেশে Android SDK/Gradle wrapper না থাকায় assembleDebug চালানো হয়নি।
