# FlashForge UI Dashboard Update v1.15

- Flash-page secondary tools are now presented as a 2-column icon dashboard with distinct icons, short descriptions, selected-state styling, and a full-width final tile.
- Selecting a tile shows only that feature's panel below the dashboard, reducing long accordion clutter.
- Original feature actions and panel content are retained.
- Fixed literal escaped newline characters in `Background.kt` imports.
- App version: 1.15 / versionCode 14.

Validation: source structure and archive integrity checked. Full Android Gradle compilation was not available in this environment.
