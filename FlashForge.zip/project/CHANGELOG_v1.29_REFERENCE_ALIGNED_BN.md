# v1.29 — Reference-aligned 3D UI

- Main navigation moved to the top and changed to a 3-column × 2-row glossy dashboard grid.
- About moved into its own wide 3D tile.
- Background updated with theme-aware Light Purple / Deep Violet / Electric Blue / Soft Cyan base and four corner ambient lights.
- Device wheel now has four outer actions (EDL, BROM, Download, Fastboot) and a center Restart action.
- Flash tool sections changed from rectangular dashboard tiles to a 7-segment circular action wheel.
- ROM & Root's eight requested entries changed from a two-column card list to an 8-segment circular action wheel.
- Existing guarded operations and non-implemented placeholder notices preserved.
- Existing four built-in themes and supplied 3D icon assets retained.

Android Gradle compile has not been run in this environment; verify with the included GitHub Actions workflow.
