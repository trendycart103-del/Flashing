# FlashForge Launcher Icon Update — OTG Phone-to-Phone Branding

- Updated the Android launcher artwork used by both `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round` adaptive icon resources.
- The new launcher artwork communicates the app's core OTG phone-to-phone flashing workflow: Host phone, Target phone, OTG link/cable, Android, and flashing modes.
- Kept the full rounded-square artwork inset on a dark navy canvas so circular, squircle, and other adaptive launcher masks have breathing room and do not crop the important logo content.
- Updated the adaptive icon background to matching deep navy.
- Updated the monochrome adaptive icon glyph to a simplified two-phone-and-connection symbol for themed launcher icon support.
- No in-app floating/corner logo was changed. That is a separate item and will be handled only after the user specifies it.
- No application code, flashing behavior, permissions, package ID, or version number was changed.
- Build/compile was not run; the user plans to build through GitHub Actions.
