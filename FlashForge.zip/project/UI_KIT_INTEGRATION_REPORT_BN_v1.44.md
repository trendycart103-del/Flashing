# FlashForge UI Kit Integration — v1.44

## এই আপডেটে যা করা হয়েছে

- UI Kit-এর `WheelMenu.kt`-কে `com.flashforge` প্যাকেজে Native Jetpack Compose component হিসেবে যুক্ত করা হয়েছে; এটি আর `com.example.flashforge.ui` starter package-এ পড়ে নেই।
- UI Kit-এর ২৬টি PNG icon `app/src/main/res/drawable-nodpi/`-তে কপি করা হয়েছে।
- পুরোনো ৭-সেক্টরের `RadialNavigation` সক্রিয় UI থেকে সরানো হয়েছে; নতুন DEVICE / FLASH / ROM & ROOT / LOG চার-ট্যাব নেভিগেশন যুক্ত হয়েছে।
- চারটি মূল পেজেই একই fixed-size, multi-ring wheel layout যুক্ত হয়েছে; item count বাড়লে wheel geometry ring-এ ভাগ হয়।
- নতুন gradient logo header, Settings/Safety/About shortcut, neon tab bar, wheel pedestal এবং 150dp information/action panel যুক্ত হয়েছে।
- Device wheel-এর EDL/BROM/Download/Fastboot ও Restart action-এ confirmation dialog যুক্ত হয়েছে।
- Flash wheel-এর Flash Queue action-এ confirmation রাখা হয়েছে; মূল `MainVM` safety/identity/checksum gates অপরিবর্তিত।
- ROM & ROOT wheel unlock controls-এ নিয়ে যায়; actual unlock-এর জন্য আগের in-app destructive confirmation-ই প্রয়োজন।
- Log wheel-এ export, clipboard copy, error/failure filter এবং confirmation-সহ clear action যুক্ত হয়েছে।
- পুরোনো ModeWheel, FlashActionWheel এবং ROM wheel-এর duplicate visual entry active flow থেকে সরানো হয়েছে।
- About page-এ যাচাইয়ের জন্য BuildConfig identity পরিবর্তন: `FLASHFORGE_UIKIT_V2_144`।
- `versionCode=14`, `versionName=1.44` করা হয়েছে, যাতে Android আগের 1.43 build-কে update হিসেবে গ্রহণ করতে পারে।

## যেসব মূল অংশ ইচ্ছাকৃতভাবে অক্ষত রাখা হয়েছে

`MainVM.kt`, Fastboot/ADB transport, USB receiver, firmware resolver, checksum verification, firmware trust audit, chipset flash engines, Safety Analyzer এবং flash transfer code পরিবর্তন করা হয়নি। Existing page-level guarded operations-ও রাখা হয়েছে।

## যাচাইয়ের সীমাবদ্ধতা

এই build environment-এ Android SDK, Gradle installation বা Gradle wrapper নেই। তাই Android Gradle Plugin দিয়ে APK assemble, Compose compiler validation, emulator run বা বাস্তব USB hardware test করা যায়নি। Kotlin source-গুলো compiler parser দিয়ে syntax scan করা হয়েছে; unresolved Android/Compose references এই environment-এ expected, কারণ Android/Compose dependencies এখানে ইনস্টল নেই।

**গুরুত্বপূর্ণ:** এই ZIP একটি Android Studio source project; এটি APK নয়। Android Studio-তে Gradle sync করে `:app:assembleDebug` চালিয়ে APK তৈরি ও device test করতে হবে।

- UI Kit ZIP-এ Rajdhani/Exo 2 font binary ছিল না এবং build container-এ Google Fonts network access নেই; তাই Compose-এ Android Sans fallback ব্যবহার করা হয়েছে।
