# FlashForge UI Update v1.33 — Radial Gaming Navigation & Exact Icon Pack

## Included
- Replaced the previous multi-row navigation tiles and separate About tile with a seven-segment circular/radial navigation wheel based on the user's reference.
- Wheel uses the supplied 25-icon source pack; the 25 master PNG assets were recropped from the supplied source image into square transparent assets, preserving icon artwork and removing only near-black background pixels.
- Added a dark segmented wheel, cyan/magenta neon borders, slow border-color animation, outer HUD tick marks, central logo hub, selected-segment highlight, and a wheel press scale effect.
- Added varied screen transition styles (slide, zoom/fade, vertical slide/fade) based on the destination screen.
- Existing feature screens and app logic were retained.

## Limitations / verification
- The Android Gradle build was not run because this environment does not have Gradle installed and the ZIP does not contain a Gradle wrapper.
- This update does not yet convert every feature screen into a non-scrollable fixed dashboard. Existing feature-screen content still uses its previous vertical scrolling container.
- The radial wheel is a Compose-drawn implementation guided by the reference, not a pixel-perfect reconstruction of the supplied image. It preserves the reference's circular segmented layout, center hub, HUD rings, cyan/magenta accents, and dark segments.

## v1.34 correction
The intended shape is the radial pie-wedge segment shown in the user's reference image—not individual round buttons. See `FLASHFORGE_RADIAL_SEGMENT_SHAPE_CORRECTION_v1.34_BN.md`.
