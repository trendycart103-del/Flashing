# FlashForge v1.49 — User Update (Bangla)

## UI ও Navigation
- Device Page-এর Circle Menu ছোট করা হয়েছে, যাতে Mode Entry Guide ও Device তথ্যের জন্য বেশি জায়গা থাকে। Mode Entry Guide মূল স্ক্রিনে দৃশ্যমান এবং overflow হলে scroll করা যায়।
- ROM & Root-এর ROM tab-এ আগের v1.48 ZIP-এর Image Flash Queue UI পুনরুদ্ধার করা হয়েছে। Add Image, Unpack ZIP, Manual vbmeta, explicit partition selection, per-item SHA-256 verification, individual flash এবং selected queue flash controls বিদ্যমান MainVM logic-এর সঙ্গে যুক্ত রয়েছে।
- ROM Circle Menu-এর hub এখন ROM QUEUE action হিসেবে tab 1-এ নিয়ে যায়।
- Log Page থেকে উপরের floating USB EVENT LOG action panel সরানো হয়েছে। Save, Copy, Filter, Export ও Clear Log controls সরাসরি Log Page-এ রয়েছে।
- Safety Page-এর প্রধান actions (acknowledge, clear acknowledgement, open ROM queue, interrupted-flash resume যখন উপলব্ধ) সামনে রয়েছে। Read More/Read Less-এর মাধ্যমে বিস্তারিত Safety তথ্য দেখা যায়।
- Device, ROM/Root, Log, Safety ও Flash পেজে bounded content area এবং overflow হলে page-local scrolling যুক্ত করা হয়েছে।

## যা অপরিবর্তিত রাখা হয়েছে
- Background, 3D Neon theme, lighting, subtitle, particles, animations, buttons ও icon artwork-এর বিদ্যমান ডিজাইন পরিবর্তন করা হয়নি।
- MainVM, Device Detection, USB Connectivity, Firmware Verification, Safety Analyzer এবং Flash Engine-এর মূল logic পরিবর্তন করার উদ্দেশ্য ছিল না।
- Firmware Sites ও Fastboot Flash Options-এর পূর্ববর্তী অবস্থান/logic বজায় রাখা হয়েছে।

## Version
- Version Name: `1.49`
- Version Code: `16`
- UI Layout ID: `FLASHFORGE_MODE_GUIDE_V149`

## Git commit message suggestion
`feat(ui): restore ROM queue and reorganize Log/Safety pages for v1.49`

## Verification status
- Edited Kotlin source files were checked with the Kotlin parser; no syntax errors were reported.
- Full Android Gradle compile, lint, unit tests and APK build were not run locally because Gradle and Android SDK are not installed in this environment.
- GitHub Actions workflow is configured to install JDK 17, Gradle 8.7 and Android SDK 34/build-tools 34.0.0, then run `clean testDebugUnitTest lintDebug assembleDebug` and upload the APK/reports.
