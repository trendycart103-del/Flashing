# FlashForge UI Rebuild Report — v1.29

## ব্যবহারকারীর রেফারেন্স অনুযায়ী করা পরিবর্তন

1. **উপরের Main Menu:** FlashForge Header-এর ঠিক নিচে ৩-কলামের × ২-সারির Main Menu grid রাখা হয়েছে। এটি আর স্ক্রিনের নিচে নেই। Device, Flash, ROM & Root, Log, Safety ও Settings উপরের নেভিগেশনে থাকবে।
2. **About:** About-কে আলাদা প্রশস্ত Glossy 3D বাটন করা হয়েছে; এটি সাধারণ Tab Bar-এর অংশ নয়।
3. **মূল ব্যাকগ্রাউন্ড:** Light Purple / Deep Violet ভিত্তিক গ্রেডিয়েন্ট, চার কোণায় Cyan ও Purple ambient corner light; চারটি Built-in Theme অনুযায়ী ব্যাকগ্রাউন্ডের রংও বদলায়, সূক্ষ্ম circuit rail এবং metallic gear motif রাখা হয়েছে। কনটেন্টের পড়ার জায়গায় অতিরিক্ত glow দেওয়া হয়নি।
4. **Device Action Wheel:** চারটি বাইরের সেক্টর EDL, BROM, Download ও Fastboot; মাঝখানে Restart। প্রতিটি সেক্টর আগের guarded device command-এ যুক্ত।
5. **Flash Action Wheel:** সাতটি Flash tool section-কে বৃত্তাকার segmented wheel-এ সাজানো হয়েছে: Phone Profile, Auto Search, Chipset, Firmware Sites, Phone Firmware, Downloaded ও Download। নির্বাচন করলে সংশ্লিষ্ট বিদ্যমান section দেখায়। Flash queue, image add, verify ও flash-এর guarded controls আগের মতোই থাকে।
6. **ROM & Root Action Wheel:** Custom ROM, Install Root, Xposed, ROM Manager, Recovery, Kernel, Manage ROM ও Uninstall Root—আটটি অপশন 3D segmented wheel-এ সাজানো হয়েছে। আগে থেকে থাকা ROM/Root/Partition workflow-তে প্রাসঙ্গিক অপশনগুলো নিয়ে যায়; যেগুলোর বাস্তব অপারেশন নেই সেগুলো স্পষ্ট placeholder হিসেবে থাকে, কোনো ভুয়া কমান্ড চালায় না।
7. **আইকন:** ZIP-এ থাকা `ff_*.png` 3D icon assets ব্যবহার করা হয়েছে, যেগুলো ব্যবহারকারীর দেওয়া icon sheet-এর একই visual family।
8. **Settings:** চারটি Built-in Theme বজায় আছে: Light Purple 3D, Midnight Neon, Electric Blue, Soft Cyan Circuit।

## সংরক্ষণ নীতি

- Device detection, firmware queue, checksum verification, Safety Analyzer, Fastboot/ADB transport এবং বিদ্যমান guarded actions বাদ দেওয়া হয়নি।
- নতুন ROM & Root entries-এর অনুপস্থিত কার্যকারিতা চালু বলে দাবি করা হয়নি।
- মূল project-এর বাকি ফাইল ও workflow অপরিবর্তিত রাখা হয়েছে; পরিবর্তনগুলো মূলত UI/navigation স্তরে।

## যাচাইয়ের অবস্থা

- ZIP integrity: `unzip -t` দিয়ে যাচাই করা হয়েছে।
- Drawable resource reference scan: কোনো missing drawable পাওয়া যায়নি।
- Kotlin syntax scan: Android/Compose dependency classpath ছাড়া পূর্ণ compile সম্ভব নয়; কোনো নির্ভরযোগ্য Android compile ফল দাবি করা হচ্ছে না।
- Android Gradle compile, unit tests, lint ও APK build: এই রানটাইমে Gradle/Android SDK নেই। GitHub Actions-এ `testDebugUnitTest lintDebug assembleDebug --stacktrace` চালিয়ে নিশ্চিত করতে হবে।
