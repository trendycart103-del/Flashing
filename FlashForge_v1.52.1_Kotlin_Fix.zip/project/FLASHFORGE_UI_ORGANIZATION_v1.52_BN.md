# FlashForge v1.52 — Page Organization & Workflow Cleanup

## লক্ষ্য
v1.51-এর ভিত্তিতে আগের ১০-পেজ navigation, Dark Cyber Gaming / 3D Neon theme, wheel artwork, icon pack, existing device/firmware/backup/safety logic অক্ষত রেখে প্রতিটি কাজকে তার উপযুক্ত পেজে গুছিয়ে রাখা।

## UI ও workflow পরিবর্তন
1. **Device page:** একটিমাত্র DEVICE CONNECTION summary; পরিচয় অজানা হলে আলাদা, স্পষ্ট NOT VERIFIED identity panel; বর্তমান mode অনুযায়ী একটি সংক্ষিপ্ত guide। আগে সব mode-এর দীর্ঘ guide একসঙ্গে দেখানো হতো—এখন অপ্রাসঙ্গিক guide আর জমা হয় না। স্পষ্ট করা হয়েছে যে GPS/location দিয়ে USB device শনাক্ত করা হয় না।
2. **Flash page:** Firmware Sites কেবল SITES ট্যাবে দেখা যায়; PHONE FW, DOWNLOAD, FILES এবং নতুন QUEUE ট্যাব আলাদা কাজ দেখায়। আগে Firmware Sites panel অন্য ট্যাবেও দেখা যেত।
3. **Flash Queue:** ADD IMAGE, UNPACK ZIP, explicit partition mapping, SHA-256 verification ও flash controls এখন FLASH > QUEUE-তে। আগে এই queue ROM & ROOT-এর Custom ROM tab-এ ছিল। Flash wheel-এর hub এখন FLASH > QUEUE খোলে; FILES wheel action FILES tab খোলে।
4. **ROM & ROOT:** Unlock, Custom ROM, Root ও Partition workflow রাখা হয়েছে; একই Flash Queue panel আর এখানে duplicate হয় না। Slot controls থাকে; সাধারণ Backup/Restore dedicated BACKUP page-এ নির্দেশিত।
5. **Device page duplicate status strip:** আগের অতিরিক্ত FASTBOOT FLASH OPTIONS summary সরানো হয়েছে; সংযোগ ও device identity এখন Device page-এর এক জায়গায় থাকে।
6. **Reset & Backup:** Clean Flash ও Backup/Restore-এর existing confirmation, safety gate ও capability limitations অপরিবর্তিত। Clean Flash-এর নির্দেশ এখন FLASH > QUEUE-তে পাঠায়।
7. **Version:** app version 1.52, versionCode 19; build identity `FLASHFORGE_PAGE_ORGANIZATION_V152`.

## যা ইচ্ছাকৃতভাবে অপরিবর্তিত
- ১০টি মূল পেজ, top tabs, 3D wheel, supplied icons, colors, background and page transition.
- USB/OTG detection, device database, Fastboot flash safety gates, automatic backup, Clean Flash, firmware download, public Downloads, logs, Safety Analyzer and backup restore logic.
- EDL/BROM/Samsung Download/Unisoc remain detection-only where write engines are not implemented. No FRP bypass or unsupported chipset flash capability is claimed.

## Validation and limits
- Source-level structure and changed call sites reviewed.
- Android SDK/Gradle are not installed in this editing environment; Gradle compile, lint, unit tests and APK build were not run.
- Physical device, OTG and page-render screenshot testing were not run. GitHub Actions must pass before treating this build as verified.
