# FlashForge v1.51 — Smart Connectivity & Safer Flash Workflow

## ভিত্তি ও সংরক্ষণ
- v1.50-এর Kotlin/Compose app structure, package `com.flashforge`, 10-page navigation, theme/assets, DeviceDb, existing Fastboot, checksum gate, Flash Queue, ADB sideload, safety checks, logs, backup/restore এবং detection-only chipset registry রাখা হয়েছে।
- Version: `1.51`; versionCode: `18`; build identity: `FLASHFORGE_SMART_CONNECTIVITY_V151`.

## Source audit (v1.50)
- USB Host + attach/detach receiver + explicit USB permission flow ছিল।
- Fastboot `getvar` থেকে product identity ও local database lookup ছিল; ADB/EDL/BROM/Download mode-এর জন্য universal exact model identification ছিল না।
- Device mode অনুযায়ী navigation ছিল, তবে chipset boot modes সবসময় আলাদা Chipset hub-এ যেত না।
- Firmware download app-private `Android/data/.../files/fw` directory-তে হতো; public Downloads integration ছিল না।
- Backup/restore ছিল, কিন্তু automatic pre-flash backup ছিল না। Backup read path `fastboot fetch` সমর্থনের উপর নির্ভরশীল।
- Userdata/metadata wipe সীমিত Fastboot path-এ ছিল; universal full-device clean flash ছিল না।
- Qualcomm EDL, MediaTek BROM, Samsung Download এবং Unisoc FDL write engines disabled/detection-only ছিল।

## v1.51 changes
1. **Device navigation:** Fastboot + verified OEM identity → Flash; ADB → ROM & ROOT; Qualcomm EDL / MediaTek BROM / Samsung Download / Unisoc → Chipset; unknown identity → Device. Chipset mode is not mislabeled as flash-ready.
2. **Automatic pre-flash backup:** enabled by default. Before every image write, FlashForge verifies the exact selected image hash again, checks product/OEM identity, slot mapping, target partition, partition size and storage, then attempts a `fastboot fetch` snapshot with SHA-256 sidecar metadata. If the device cannot provide a verified backup, the image write stops before sending a flash command. The setting can be explicitly disabled for ordinary flash operations; Clean Flash always requires backup.
3. **Device-compatible Clean Flash:** explicit confirmation, verified product/OEM, acknowledged Safety Analyzer warnings, explicit mapped `.img` queue, publisher SHA-256 recheck for every image, required target-partition backups, then userdata erase; metadata erase is attempted only when the bootloader reports the metadata partition. Only selected queue images are flashed through the existing guarded Fastboot path. Protected calibration/identity partitions are not erased. This is not a universal OEM factory-flash package installer.
4. **Public Downloads:** Android 10+ completed downloads are copied to `Downloads/FlashForge` using MediaStore without broad storage permission. The private Firmware Library copy is retained. Existing public Downloads files can be selected through Android's document picker and added to the queue. Android 8/9 retains private copy and needs an explicit export workflow for public storage.
5. **Workflow:** GitHub Actions can build the current extracted project or extract exactly one root-level uploaded ZIP, then run unit tests, lint, debug APK build and artifact upload.

## Safety and limitations
- FRP/account-lock bypass is not implemented. Factory reset does not guarantee FRP removal.
- Exact model identification remains dependent on what the current USB mode, bootloader, descriptors and local device database expose. EDL/BROM VID:PID is chipset/mode evidence, not exact phone model proof.
- `fastboot fetch` is not supported by every bootloader. With automatic backup enabled, unsupported/unknown/logical partition backup causes normal image flashing to stop before writing. User can turn off the optional automatic backup for ordinary flash, after understanding the risk. Clean Flash never skips its required backup.
- Backup of logical/dynamic partitions is attempted only in confirmed Fastbootd and only where the bootloader supports verified fetch; full-device snapshots are not universally supported.
- Clean Flash currently wipes userdata and, only if reported present, metadata; it does not claim to erase every physical partition or all device security state.
- Firmware sources remain manufacturer portals/searches, not guaranteed direct package feeds. Exact SKU, region/CSC, bootloader revision, signed package and partition mapping must be confirmed by the operator.
- Qualcomm EDL/Sahara/Firehose, MediaTek BROM/DA, Samsung Download flashing and Unisoc FDL write protocols remain disabled. Detection or selecting an optional loader does not enable flashing.
- No FRP bypass, secure-boot bypass, cross-model loader execution, automatic vbmeta patching or protected calibration erase was added.

## Validation performed in this editing environment
- ZIP integrity and source tree inspection: performed.
- AndroidManifest XML parse: performed.
- GitHub Actions YAML parse / shell structure review: performed where local parser available.
- Source-level consistency review: performed.
- Gradle unit tests, Android Lint, APK compilation: **not run** because this environment has no Android SDK and no Gradle executable.
- Physical OTG/phone testing: **not run**.

GitHub Actions workflow in `.github/workflows/build.yml` runs:
`gradle clean testDebugUnitTest lintDebug assembleDebug --no-build-cache --stacktrace`

The CI result must be checked in GitHub Actions before treating the APK as build-verified. The workflow file must already be committed in the repository; after that, a single root-level ZIP can trigger extraction and build.
