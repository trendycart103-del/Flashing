# FlashForge v1.50 — 10-Page Service Architecture Update

## Navigation
- Existing Device, Flash, ROM & ROOT, Log, Safety, Settings and About screens are retained.
- Added dedicated Reset & Repair, Chipset and Backup screens.
- The top navigation now contains ten horizontally scrollable 3D tabs; it remains top navigation (no bottom navigation added).

## New screens
- Reset & Repair: device/mode status, safe supported workflows and explicit notes that destructive reset actions require verified identity and confirmation. No FRP/account/screen-lock bypass is offered.
- Chipset: separate Qualcomm EDL, MediaTek BROM, Samsung Download and Unisoc FDL capability cards. Each currently reports detection-only / write engine locked unless an implementation is genuinely enabled in the capability registry. No generic loader execution or security bypass is added.
- Backup: partition backup entry using the existing guarded `MainVM.backup` path; lists only complete local backups with metadata; restore uses the existing product, partition, size and SHA-256 checks before the guarded Fastboot flash path.

## Preserved functionality
- Existing Device detection, Fastboot, firmware sources/download queue, ROM & ROOT tools, Safety Analyzer, Log, Settings, About, 3D theme assets and existing operation guards remain in place.

## Version
- versionName: 1.50
- versionCode: 17
- UI_LAYOUT_ID: FLASHFORGE_TEN_PAGE_SERVICE_HUB_V150

## Verification status
- Source edits and ZIP integrity checks are performed for this package.
- Full Android Gradle build, lint and unit tests require Android SDK/Gradle and must be run by the included GitHub Actions workflow. They were not run in this container because no Gradle executable or Android SDK is installed. Do not treat the APK as build-verified until the workflow succeeds.
