package com.flashforge

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * All user-changeable values of the app. Everything is stored in its own SharedPreferences file and read
 * through Compose state, so a change on the Settings page is applied immediately.
 * Safety gates (product ID check, checksums, slot and partition-size checks) are NOT settings and cannot be turned off here.
 */
object AppSettings {
    const val MIN_BATTERY_FLOOR = 40

    val colorDefaults: Map<String, Long> = linkedMapOf(
        "bg" to 0xFF03040AL,
        "panel" to 0xFF11101CL,
        "text" to 0xFFF4F2FFL,
        "dim" to 0xFFB6B2C9L,
        "blue" to 0xFF35DFFFL,
        "orange" to 0xFFB75CFFL,
        "amber" to 0xFFFFC66BL,
        "green" to 0xFF49E6A3L,
        "red" to 0xFFFF5E83L,
        "yellow" to 0xFFFFD45AL
    )

    val colorLabels: Map<String, String> = linkedMapOf(
        "bg" to "Background",
        "panel" to "Cards and panels",
        "text" to "Main text",
        "dim" to "Secondary text",
        "blue" to "Accent (selected tab, focus)",
        "orange" to "Section dot",
        "amber" to "Section titles and warnings",
        "green" to "Success",
        "red" to "Error and danger",
        "yellow" to "Connecting lamp"
    )

    /** Core workflow tabs that must never be hidden: device, flashing, partition, ROM/root, safety and settings. Only the secondary log tab may be hidden. */
    private val alwaysVisible = setOf(Screen.DEVICE, Screen.FLASH, Screen.ROM, Screen.RESET, Screen.CHIPSET, Screen.BACKUP, Screen.LOG, Screen.SAFETY, Screen.SETTINGS, Screen.ABOUT)

    private var sp: SharedPreferences? = null
    private val overrides = mutableStateMapOf<String, Long>()
    private val hidden = mutableStateListOf<String>()

    var blobs by mutableStateOf(false)
    var builtInTheme by mutableIntStateOf(0)
    /** App language is intentionally limited to Bangla and English. */
    var language by mutableStateOf("bn")
    var textScale by mutableStateOf(1.0f)
    var slowMbs by mutableStateOf(2.0)
    var flapLimit by mutableIntStateOf(3)
    var slowSamples by mutableIntStateOf(3)
    var logMax by mutableIntStateOf(400)
    var minBattery by mutableIntStateOf(MIN_BATTERY_FLOOR)
    var defBackup by mutableStateOf("boot")
    var defRecovery by mutableStateOf("recovery")
    var defPatched by mutableStateOf("boot")

    /** Bumped on reset so text fields on the Settings page reload their value. */
    var resetTick by mutableIntStateOf(0)

    /** Background image: 2 = optional user image, 3..10 = the eight current abstract stock wallpapers. */
    var bgChoice by mutableIntStateOf(10)
    var bgUri by mutableStateOf("")

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("flashforge_settings", Context.MODE_PRIVATE)
        try {
            colorDefaults.keys.forEach { k -> if (p.contains("c_$k")) overrides[k] = p.getLong("c_$k", colorDefaults.getValue(k)) }
            blobs = p.getBoolean("blobs", true)
            builtInTheme = p.getInt("built_in_theme", 0).coerceIn(0, 3)
            language = if (p.getString("language", "bn") == "en") "en" else "bn"
            textScale = p.getFloat("scale", 1.0f).coerceIn(0.8f, 1.4f)
            slowMbs = p.getFloat("slow", 2.0f).toDouble().coerceIn(0.5, 10.0)
            flapLimit = p.getInt("flap", 3).coerceIn(2, 6)
            slowSamples = p.getInt("samples", 3).coerceIn(2, 10)
            logMax = p.getInt("logmax", 400).coerceIn(100, 2000)
            minBattery = p.getInt("minbat", MIN_BATTERY_FLOOR).coerceIn(MIN_BATTERY_FLOOR, 90)
            defBackup = cleanPart(p.getString("d_backup", "boot") ?: "boot")
            defRecovery = cleanPart(p.getString("d_recovery", "recovery") ?: "recovery")
            defPatched = cleanPart(p.getString("d_patched", "boot") ?: "boot")
            // Restore custom wallpaper URI and selection. OpenDocument grants are persisted
            // by SettingsPage; if the URI is stale or unavailable, AppBackground falls back
            // to the bundled stock wallpaper without crashing.
            bgUri = p.getString("bg_uri", "") ?: ""
            val savedBgChoice = p.getInt("bg_choice", 10)
            bgChoice = when {
                savedBgChoice in 3..10 -> savedBgChoice
                savedBgChoice == 2 && bgUri.isNotBlank() -> 2
                else -> 10
            }
            hidden.clear()
            (p.getString("hidden", "") ?: "").split(",").filter { n -> Screen.values().any { it.name == n && it !in alwaysVisible } }.forEach { hidden.add(it) }
        } catch (e: Exception) {
            android.util.Log.w("FlashForge", "Settings could not be read; defaults are used", e)
        }
        sp = p
        if (!p.contains("built_in_theme") && colorDefaults.keys.none { p.contains("c_$it") }) selectBuiltInTheme(0)
    }

    private fun persist() {
        val e = sp?.edit() ?: return
        e.clear()
        overrides.forEach { (k, v) -> e.putLong("c_$k", v) }
        e.putBoolean("blobs", blobs)
        e.putInt("built_in_theme", builtInTheme)
        e.putString("language", language)
        e.putFloat("scale", textScale)
        e.putFloat("slow", slowMbs.toFloat())
        e.putInt("flap", flapLimit)
        e.putInt("samples", slowSamples)
        e.putInt("logmax", logMax)
        e.putInt("minbat", minBattery)
        e.putString("d_backup", defBackup)
        e.putString("d_recovery", defRecovery)
        e.putString("d_patched", defPatched)
        e.putString("hidden", hidden.joinToString(","))
        e.putInt("bg_choice", bgChoice)
        e.putString("bg_uri", bgUri)
        e.apply()
    }

    fun selectLanguage(code: String) { language = if (code == "en") "en" else "bn"; persist() }

    // ---- built-in visual themes ----
    fun selectBuiltInTheme(index: Int) {
        val palettes = listOf(
            // Light Purple 3D
            mapOf("bg" to 0xFFF4F0FFL, "panel" to 0xFFFFFFFFL, "text" to 0xFF30204FL, "dim" to 0xFF685A83L, "blue" to 0xFF7545D6L, "orange" to 0xFFB66BFFL, "amber" to 0xFF8A4CBCL, "green" to 0xFF168A62L, "red" to 0xFFD04468L, "yellow" to 0xFFE5A52DL),
            // Midnight Neon
            mapOf("bg" to 0xFF080B2BL, "panel" to 0xFF171044L, "text" to 0xFFF8F5FFL, "dim" to 0xFFB9B1E8L, "blue" to 0xFF28DDF5L, "orange" to 0xFFB66CFFL, "amber" to 0xFFFFC15AL, "green" to 0xFF3CE68BL, "red" to 0xFFFF607CL, "yellow" to 0xFFFFD45AL),
            // Electric Blue
            mapOf("bg" to 0xFF071B3DL, "panel" to 0xFF102B58L, "text" to 0xFFF3FAFFL, "dim" to 0xFFB5CDE9L, "blue" to 0xFF32B9FFL, "orange" to 0xFF9B7BFFL, "amber" to 0xFFFFC35CL, "green" to 0xFF42E69BL, "red" to 0xFFFF647CL, "yellow" to 0xFFFFD65AL),
            // Soft Cyan Circuit
            mapOf("bg" to 0xFFEAFBFFL, "panel" to 0xFFFFFFFFL, "text" to 0xFF123B57L, "dim" to 0xFF55788CL, "blue" to 0xFF00AFC8L, "orange" to 0xFF7E5BD6L, "amber" to 0xFF9A6400L, "green" to 0xFF16845EL, "red" to 0xFFD34458L, "yellow" to 0xFFE4A21AL)
        )
        val chosen = index.coerceIn(0, 3)
        overrides.clear()
        palettes[chosen].forEach { (key, value) -> overrides[key] = value }
        builtInTheme = chosen
        persist()
    }

    // ---- colours ----
    fun color(key: String): Color = Color(overrides[key] ?: colorDefaults.getValue(key))

    fun hex(key: String): String = "%06X".format(color(key).toArgb() and 0xFFFFFF)

    /** rgb = six hex digits. Returns false (and changes nothing) for anything else. */
    fun setColor(key: String, rgb: String): Boolean {
        if (key !in colorDefaults || rgb.length != 6 || !rgb.all { it in "0123456789ABCDEFabcdef" }) return false
        overrides[key] = 0xFF000000L or rgb.toLong(16)
        persist()
        return true
    }

    fun resetColors() {
        overrides.clear()
        resetTick++
        persist()
    }

    // ---- display ----
    fun changeBlobs() { blobs = !blobs; persist() }

    // ---- background image ----
    fun chooseBg(i: Int) { bgChoice = if (i == 2 && bgUri.isNotBlank()) 2 else i.coerceIn(3, 10); persist() }
    fun setCustomBg(uri: String) { bgUri = uri; bgChoice = 2; persist() }

    fun stepTextScale(d: Float) {
        textScale = (Math.round((textScale + d) * 100f) / 100f).coerceIn(0.8f, 1.4f)
        persist()
    }

    // ---- tabs ----
    /** All tabs are always shown; the tab on/off option was removed from the Settings page. */
    fun tabVisible(s: Screen): Boolean = true
    fun tabCanHide(s: Screen): Boolean = s !in alwaysVisible

    fun toggleTab(s: Screen) {
        if (!tabCanHide(s)) return
        if (s.name in hidden) hidden.remove(s.name) else hidden.add(s.name)
        persist()
    }

    // ---- defaults ----
    fun cleanPart(s: String): String = s.trim().filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(40)

    fun updateDefBackup(s: String) { defBackup = cleanPart(s); persist() }
    fun updateDefRecovery(s: String) { defRecovery = cleanPart(s); persist() }
    fun updateDefPatched(s: String) { defPatched = cleanPart(s); persist() }

    // ---- USB cable alert and log ----
    fun stepSlowMbs(d: Double) { slowMbs = (Math.round((slowMbs + d) * 10.0) / 10.0).coerceIn(0.5, 10.0); persist() }
    fun stepFlapLimit(d: Int) { flapLimit = (flapLimit + d).coerceIn(2, 6); persist() }
    fun stepSlowSamples(d: Int) { slowSamples = (slowSamples + d).coerceIn(2, 10); persist() }
    fun stepLogMax(d: Int) { logMax = (logMax + d).coerceIn(100, 2000); persist() }

    // ---- safety limit (can only be raised above the built-in minimum) ----
    fun stepMinBattery(d: Int) { minBattery = (minBattery + d).coerceIn(MIN_BATTERY_FLOOR, 90); persist() }

    fun resetAll() {
        overrides.clear()
        hidden.clear()
        blobs = true
        builtInTheme = 0
        textScale = 1.0f
        slowMbs = 2.0
        flapLimit = 3
        slowSamples = 3
        logMax = 400
        minBattery = MIN_BATTERY_FLOOR
        defBackup = "boot"
        defRecovery = "recovery"
        defPatched = "boot"
        // Reset custom wallpaper selection too; otherwise Reset leaves a stale URI active.
        bgChoice = 10
        bgUri = ""
        resetTick++
        persist()
    }
}
