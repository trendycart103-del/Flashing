@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.flashforge

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.hypot
import kotlin.math.PI
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.draw.alpha
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush

private fun nm(u: Uri?): String = u?.lastPathSegment?.substringAfterLast('/') ?: "no file chosen"

@Composable
fun DevicePage(vm: MainVM) {
    val unknownDevice = vm.usbId.isNotBlank() && (vm.brandName().isBlank() || vm.modelName.isBlank() || vm.modelName == "Not in database" || vm.modelNote.contains("not in the local model database", ignoreCase = true))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("DEVICE CONNECTION", false, R.drawable.ff_master_icon_01, C.blue) {
            KV("USB / OTG", if (vm.link == Link.GREEN) "Connected" else vm.link.label)
            KV("Detected mode", vm.mode.label)
            KV("Device", if (unknownDevice) "Connected · identity not verified" else vm.modelName.ifBlank { "Waiting for device" })
            if (vm.link == Link.GREEN && vm.mode != Mode.NONE && !unknownDevice) {
                KV("Product ID", vm.product.ifBlank { "Unavailable" })
                KV("OEM / Brand", vm.brandName().ifBlank { "Not confirmed" })
                KV("Active slot", vm.slot)
                KV("A/B partitions", if (vm.isAB) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
                KV("Fastbootd", if (vm.userspace) "Yes" else if (vm.mode == Mode.FASTBOOT) "No / unknown" else "Unavailable")
                Btn("CONFIRM DETECTED PRODUCT ID", vm.mode == Mode.FASTBOOT && vm.product.isNotBlank() && !vm.busy, compact = true) { vm.adoptDetectedProduct() }
            }
        }
        if (unknownDevice) UnknownDeviceAnalyzer(vm)
        Panel("MODE GUIDE", true, R.drawable.ic_modes, C.blue, false) {
            val guide = when (vm.mode) {
                Mode.FASTBOOT -> "FASTBOOT: use the wheel's FASTBOOT control or the phone's model-specific Volume + Power key combination. Confirm the product ID before firmware operations."
                Mode.ADB -> "ADB: unlock the phone and authorize this computer on the phone screen. Use ROM & ROOT for supported ADB sideload/root workflows."
                Mode.SAMSUNG_DOWNLOAD -> "SAMSUNG DOWNLOAD: use the model-specific hardware-key sequence and confirm the Download screen. Detection does not confirm the exact model."
                Mode.QUALCOMM_EDL -> "QUALCOMM EDL: model-specific entry is required. This build detects EDL only; it does not provide an enabled Firehose flash engine."
                Mode.MEDIATEK_BROM -> "MEDIATEK BROM: model-specific key/USB entry is required. This build detects BROM only; it does not execute a Download Agent."
                Mode.UNISOC -> "UNISOC: use the model-specific download-key sequence. Current support is detection only."
                else -> "Connect the phone with a data-capable USB cable. FlashForge detects supported USB/ADB/Fastboot modes automatically. Use the wheel above only for supported reboot requests; powered-off hardware modes usually require the phone's physical keys."
            }
            T(guide, C.text, 11)
            T("Mode controls are in the 3D wheel above. GPS/location is not used for USB device identification.", C.dim, 10, mod = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun UnknownDeviceAnalyzer(vm: MainVM) {
    Panel("DEVICE IDENTITY — NOT VERIFIED", true, R.drawable.ic_device, C.amber) {
        KV("OEM / Brand", vm.brandName().ifBlank { "Unknown" })
        KV("Model", vm.modelName.ifBlank { "Unknown" })
        KV("USB VID:PID", vm.usbId.ifBlank { "Unavailable" })
        KV("USB descriptor", vm.usbDescriptor.ifBlank { "Not supplied" })
        KV("Vendor hint", vm.vendor.ifBlank { "Unknown" })
        KV("Chipset hint", vm.chip.ifBlank { "Not identified" })
        T("Read-only identification only. USB vendor or chipset information is not proof of the phone's exact OEM/model. Firmware write and erase remain blocked until identity is verified.", C.red, 10, true)
    }
}

@Composable
fun BubblePanel(vm: MainVM) {
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms() }
    Panel("FLOATING BUBBLE", false) {
        KV("Overlay permission", if (vm.overlayOk) "granted" else "not granted")
        KV("Notifications", if (vm.notifOk) "allowed" else "not allowed")
        KV("Bubble", if (vm.bubbleOn) "ON" else "OFF")
        T("While a flash, backup, sideload or download runs, a bubble floats over every app with the progress and cable warnings. Tap it to come back here, drag it to move it.", C.dim, 11, mod = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        if (!vm.overlayOk) {
            Rw {
                Btn("GRANT OVERLAY PERMISSION", mod = Modifier.weight(1f)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }
            }
        }
        if (!vm.notifOk && Build.VERSION.SDK_INT >= 33) {
            Rw { Btn("ALLOW NOTIFICATIONS", mod = Modifier.weight(1f)) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) } }
        }
        Rw {
            Btn(if (vm.bubbleOn) "BUBBLE: ON" else "BUBBLE: OFF", mod = Modifier.weight(1f)) { vm.toggleBubble() }
            Btn("TEST BUBBLE", !vm.busy, mod = Modifier.weight(1f)) { vm.testBubble() }
        }
    }
}

@Composable
fun FlashPage(
    vm: MainVM,
    activeToolsSection: String = "sites",
    onSectionChange: (String) -> Unit = {},
    wheelAction: String? = null,
    onWheelActionConsumed: () -> Unit = {}
) {
    LaunchedEffect(wheelAction) { if (wheelAction != null) onWheelActionConsumed() }
    var url by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(0.dp)) {
        listOf("sites" to "SITES", "phoneFirmware" to "PHONE FW", "download" to "DOWNLOAD", "downloads" to "FILES", "queue" to "QUEUE").forEach { (key, label) ->
            TextButton(onClick = { onSectionChange(key) }, modifier = Modifier.weight(1f)) { Text(label, color = if (activeToolsSection == key) C.blue else C.dim, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
        }
    }
    FlashToolBanner(vm)
    val ctx = LocalContext.current
    val brandLinks = vm.brandLinks()
    val publicFirmwarePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFirmwareUri(uri)
    }
    if (activeToolsSection == "sites") Panel("FIRMWARE SITES: ${vm.brandName().ifBlank { "-" }.uppercase()}", true) {
        if (brandLinks.isEmpty()) T("Connect a phone to see the firmware sites of its brand.", C.dim, 11)
        brandLinks.forEach { (n, u) ->
            T(n, C.blue, 12, true, Modifier.fillMaxWidth().clickable {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { android.util.Log.e("FlashForge", "Could not open firmware link $u", e) }
            }.padding(vertical = 7.dp))
        }
        if (brandLinks.isNotEmpty()) T("Tap opens the site in your browser. After downloading, open FLASH > QUEUE to add images and prepare the flash order.", C.dim, 11)
    }
    val links = vm.fwLinks()
    if (activeToolsSection == "phoneFirmware") Panel("FIRMWARE FOR ${vm.modelName.ifBlank { "THIS PHONE" }.uppercase()}", false) {
        if (vm.product.isBlank()) T("Connect a phone in fastboot mode to see its firmware list.", C.dim, 11)
        else if (links.isEmpty()) T("No firmware link for '${vm.product}' in the database yet. Update the database in the Log tab or paste a URL below.", C.dim, 11)
        links.forEach { (n, u) ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.download(u) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.b_download) { if (!vm.busy) vm.download(u) }
                Spacer(Modifier.padding(start = 8.dp))
                T(n, C.text, 12, mod = Modifier.weight(1f))
            }
        }
    }
    var filesTick by remember { mutableStateOf(0) }
    val files = remember(vm.busy, vm.queue.size, filesTick) { vm.fwFiles() }
    if (activeToolsSection == "downloads") Panel("DOWNLOADED FILES (${files.size})", false) {
        T(vm.fwDir().absolutePath, C.dim, 10)
        Btn("PICK FROM PUBLIC DOWNLOADS / STORAGE", !vm.busy, compact = true) { publicFirmwarePicker.launch(arrayOf("application/octet-stream", "application/zip", "image/*")) }
        T("New downloads are copied to Downloads/FlashForge on Android 10+. You can also select existing firmware from the public Downloads folder above.", C.dim, 10)
        if (files.isEmpty()) T("Nothing downloaded yet.", C.dim, 11)
        files.forEach { f ->
            Row(Modifier.fillMaxWidth().clickable(enabled = !vm.busy) { vm.useFwFile(f) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T(f.name, C.text, 12)
                    T("${f.length() / 1024 / 1024} MB  - tap to add to queue", C.dim, 11)
                }
                IconBtn(R.drawable.b_trash) { f.delete(); vm.queue.removeAll { it.name == f.name }; filesTick++ }
            }
        }
    }
    if (activeToolsSection == "download") Panel("FIRMWARE DOWNLOAD", false) {
        Field(url, { url = it }, "Firmware URL (.img or .zip)")
        Btn("DOWNLOAD TO QUEUE", !vm.busy && url.isNotBlank()) { vm.download(url) }
        Btn("PICK EXISTING FILE FROM DOWNLOADS", !vm.busy, compact = true) { publicFirmwarePicker.launch(arrayOf("application/octet-stream", "application/zip", "image/*")) }
    }
    if (activeToolsSection == "queue") {
        T("Add firmware images, assign their exact target partitions, verify publisher SHA-256, then flash only after Safety checks pass.", C.dim, 10)
        RomRootFilesQueue(vm)
    }
}


@Composable
fun PartPage(vm: MainVM, toolTab: Int = 0, onToolTabChange: (Int) -> Unit = {}) {
    var p by remember { mutableStateOf("") }
    var n by remember { mutableStateOf("") }
    var sz by remember { mutableStateOf("") }
    val on = vm.mode == Mode.FASTBOOT && !vm.busy
    SegTabs(
        listOf("TABLE", "BACKUP", "LOGICAL"),
        listOf(R.drawable.ic_part, R.drawable.b_backup, R.drawable.b_resize),
        listOf(C.blue, C.green, C.orange), toolTab
    ) { onToolTabChange(it) }
    when (toolTab) {
        0 -> {
            Panel("PARTITION TABLE (${vm.parts.size})", true, R.drawable.ic_part, C.blue, true) {
                if (vm.parts.isEmpty()) T("The partition table is populated when supported device information is read.", C.dim, 11)
                vm.parts.forEach { l ->
                    T(l, C.text, 12, mod = Modifier.fillMaxWidth().clickable { p = l.substringBefore(':').trim() }.padding(vertical = 5.dp))
                }
            }
            Panel("SELECTED PARTITION", true, R.drawable.ic_part, C.blue, true) {
                Field(p, { p = it }, "Partition name")
                Rw {
                    ConfirmBtn("ERASE", "Erase partition '$p'? This cannot be undone.", on && p.isNotBlank(), true, Modifier.weight(1f)) { vm.confirmedFbCmd("erase:$p") }
                    Btn("BACKUP", on && p.isNotBlank(), false, Modifier.weight(1f)) { vm.backup(p) }
                }
                T("Backup uses fastboot fetch, which needs bootloader support. Files go to the app's files/backups folder.", C.dim, 11)
            }
        }
        1 -> Panel("BACKUPS AND RESTORE", true, R.drawable.b_backup, C.green, true) {
            Field(p, { p = it }, "Partition to back up")
            Btn("BACKUP SELECTED PARTITION", on && p.isNotBlank(), compact = true) { vm.backup(p) }
            Spacer(Modifier.height(6.dp))
            val backups = vm.backupFiles()
            if (backups.isEmpty()) T("No verified backup with metadata is available yet. Create a backup above; app-created backups can be restored below.", C.dim, 11)
            backups.forEach { file ->
                Rw {
                    Column(Modifier.weight(1f)) {
                        T(file.name, C.text, 11)
                        T("${file.length()} bytes · metadata present", C.dim, 10)
                    }
                    ConfirmBtn("RESTORE", "Restore ${file.name} to its recorded partition? The app will verify the device product, backup size and SHA-256, then run the standard flash safety checks.", on, true) { vm.restoreBackup(file) }
                }
            }
            T("Restore is only offered for app-created backups with a metadata sidecar. The local hash verifies backup integrity, not OEM authenticity.", C.amber, 10)
        }
        else -> Panel("LOGICAL PARTITIONS (FASTBOOTD)", true, R.drawable.b_resize, C.orange, true) {
            Field(n, { n = it }, "Name, for example product_a")
            Field(sz, { sz = it }, "Size in bytes")
            Rw {
                ConfirmBtn("CREATE", "Create logical partition '$n' with size $sz bytes? This changes super metadata and can make the device unbootable. Verify OEM instructions and have a recovery package ready.", on && vm.userspace && n.matches(Regex("[A-Za-z0-9_]{1,48}")) && sz.toLongOrNull()?.let { it > 0 } == true, true, Modifier.weight(1f)) { vm.logicalPartitionOperation("create", n, sz) }
                ConfirmBtn("RESIZE", "Resize logical partition '$n' to $sz bytes? This can destroy data or prevent boot. Verify group capacity and OEM instructions first.", on && vm.userspace && n.matches(Regex("[A-Za-z0-9_]{1,48}")) && sz.toLongOrNull()?.let { it > 0 } == true, true, Modifier.weight(1f)) { vm.logicalPartitionOperation("resize", n, sz) }
            }
            ConfirmBtn("DELETE", "Delete logical partition '$n'? This is destructive and may make the phone unbootable.", on && vm.userspace && n.matches(Regex("[A-Za-z0-9_]{1,48}")), true) { vm.logicalPartitionOperation("delete", n, sz) }
            T("Operations require exact product confirmation, OEM identity, controller battery threshold, Fastbootd mode, and a verified super partition. Fastbootd/bootloader may still reject the operation if dynamic-partition group constraints are exceeded. Use OEM recovery instructions.", C.amber, 11)
            if (!vm.userspace) T("Fastbootd mode is required. These controls remain unavailable in bootloader Fastboot.", C.dim, 11)
        }
    }
}

@Composable
private fun SlotButtons(vm: MainVM, enabled: Boolean, compact: Boolean = false) {
    Rw {
        for (s in listOf("a", "b")) {
            if (vm.slot == s) {
                Box(
                    Modifier.weight(1f).padding(vertical = 4.dp).heightIn(min = if (compact) 44.dp else 56.dp)
                        .background(C.amber.copy(alpha = 0.12f), FieldShape)
                        .border(2.dp, C.amber, FieldShape).padding(if (compact) 8.dp else 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    T("SLOT ${s.uppercase()}  ACTIVE", C.amber, 12, true)
                }
            } else {
                ConfirmBtn(
                    "SLOT ${s.uppercase()}",
                    "Make slot ${s.uppercase()} active? If that slot holds no valid system the phone will not boot.",
                    enabled = enabled && vm.isAB, danger = false, mod = Modifier.weight(1f), compact = compact
                ) { vm.changeSlot(s) }
            }
        }
    }
    if (!vm.isAB && vm.mode == Mode.FASTBOOT) T("This phone has no A/B slots.", C.dim, 11)
}

@Composable
private fun Sub(title: String) {
    Spacer(Modifier.height(10.dp))
    T(title, C.blue, 12, true)
    Spacer(Modifier.height(4.dp))
}

/** One compact line: choose-file button on the left, the chosen file name on the right. */
@Composable
private fun FilePick(label: String, uri: Uri?, on: (Uri) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PickBtn(label, Modifier.weight(1f), compact = true, on = on)
        T(nm(uri), C.dim, 11, mod = Modifier.weight(1f))
    }
}

@Composable
private fun Verdict(ok: Boolean) {
    T(if (ok) "PUBLISHER CHECKSUM VERIFIED" else "IMAGE NOT VERIFIED", if (ok) C.green else C.amber, 10, true)
}

@Composable
private fun RomRootFilesQueue(vm: MainVM) {
    var part by remember { mutableStateOf("") }
    val addImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFile(uri, part)
    }
    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.unzipToQueue(uri)
    }
    val fastbootReady = vm.mode == Mode.FASTBOOT && !vm.busy
    Panel("ADD IMAGE & FIRMWARE ZIP", true, R.drawable.b_image, C.blue, true) {
        Field(part, { part = it }, "Explicit target partition (required; never inferred from filename)")
        Rw {
            Btn("ADD IMAGE", !vm.busy, mod = Modifier.weight(1f), compact = true) { addImagePicker.launch(arrayOf("*/*")) }
            Btn("UNPACK ZIP", !vm.busy, mod = Modifier.weight(1f), compact = true) { zipPicker.launch(arrayOf("*/*")) }
        }
        PickBtn("ADD VBMETA IMAGE (MANUAL)", Modifier.fillMaxWidth()) { vm.addFile(it, "vbmeta") }
        T("Manual vbmeta only. No automatic vbmeta patching; every image still requires exact partition selection and the Safety Analyzer.", C.amber, 10)
    }
    Panel("FLASH QUEUE (${vm.queue.size})", true, R.drawable.ic_stack, C.blue, true) {
        if (vm.queue.isEmpty()) T("Queue is empty. Add images above in the order they must be flashed.", C.dim, 11)
        val toolBrand = flashBrandOf(vm)
        val partRegex = Regex("[A-Za-z0-9_]{1,48}")
        vm.queue.forEachIndexed { i, q ->
            Column(Modifier.fillMaxWidth().alpha(if (q.enabled) 1f else 0.45f)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SlotToggle(q.enabled, !vm.busy, toolBrand) { vm.toggleQueueItem(i) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        T("${i + 1}. ${q.name}", C.text, 12)
                        T("${q.size / 1024} KB" + if (q.enabled) "" else "  - SKIPPED", C.dim, 10)
                    }
                    IconBtn(R.drawable.b_up) { vm.move(i) }
                    IconBtn(R.drawable.b_trash) { vm.verifiedFirmware.remove(q.uri.toString() + "|" + q.size); vm.queue.removeAt(i) }
                }
                var queuePartition by remember(q.uri.toString()) { mutableStateOf(q.part) }
                Field(queuePartition, { queuePartition = it; vm.setQueuePartition(i, it) }, "Target partition for ${q.name}")
                var expectedHash by remember(q.uri.toString()) { mutableStateOf("") }
                Field(expectedHash, { expectedHash = it }, "Trusted SHA-256 for ${q.name}")
                val itemVerified = vm.verifiedFirmware[q.uri.toString() + "|" + q.size] != null
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Btn("VERIFY SHA-256", !vm.busy && expectedHash.isNotBlank(), compact = true) { vm.hash(q, expectedHash) }
                    T(if (itemVerified) "VERIFIED" else "NOT VERIFIED", if (itemVerified) C.green else C.amber, 10, true, Modifier.padding(start = 8.dp))
                }
                val itemReady = q.part.matches(partRegex) && itemVerified
                ConfirmBtn("FLASH ONLY THIS", "Flash only '${q.name}' to '${q.part}'? All other queue files are left out of this run.", fastbootReady && itemReady && vm.safetyWarningsAcknowledged, true) { vm.flashQueue(i) }
            }
        }
        val selected = vm.queue.filter { it.enabled }
        val queueReady = selected.isNotEmpty() && selected.all { item ->
            item.part.matches(partRegex) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
        }
        ConfirmBtn("FLASH SELECTED (${selected.size})", "Flash ${selected.size} selected image(s) in order? Each image needs an explicit partition and matching publisher SHA-256.", fastbootReady && queueReady && vm.safetyWarningsAcknowledged, true) { vm.flashQueue() }
    }
}

@Composable
fun RomRootPage(
    vm: MainVM,
    selectedTab: Int = 0,
    onTabChange: (Int) -> Unit = {},
    selectedPartTab: Int = 0,
    onPartTabChange: (Int) -> Unit = {}
) {
    var tab by remember(selectedTab) { mutableStateOf(selectedTab) }
    var recPart by remember { mutableStateOf(AppSettings.defRecovery) }
    var rec by remember { mutableStateOf<Uri?>(null) }
    var recHash by remember { mutableStateOf("") }
    var rom by remember { mutableStateOf<Uri?>(null) }
    var romHash by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf<Uri?>(null) }
    var extraHash by remember { mutableStateOf("") }
    var boot by remember { mutableStateOf<Uri?>(null) }
    var bootHash by remember { mutableStateOf("") }
    var bootPart by remember { mutableStateOf(AppSettings.defPatched) }
    val fb = vm.mode == Mode.FASTBOOT && !vm.busy
    val adb = vm.mode == Mode.ADB && !vm.busy
    val hex64 = Regex("[0-9a-fA-F]{64}")
    val gUnlock = C.green
    val gRom = C.blue
    val gRoot = C.orange
    val hashLabel = "Publisher SHA-256 checksum (64 hex characters)"

    Column(Modifier.fillMaxSize()) {
        StatusStrip(listOf(
            "Mode" to vm.mode.label,
            "Bootloader" to vm.unlocked,
            "Warnings read" to (if (vm.safetyWarningsAcknowledged) "yes" else "no")
        ))
        Box(Modifier.weight(1f).fillMaxWidth()) {
        when (tab) {
        // ---------------- UNLOCK ----------------
        0 -> {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Panel("UNLOCK BOOTLOADER", true, R.drawable.b_unlock, gUnlock, true) {
                T("Erases all data on the phone.", C.red, 12, true)
                Rw {
                    ConfirmBtn("UNLOCK (flashing unlock)", "Unlock the bootloader and erase all data on the connected phone?", fb, mod = Modifier.weight(1f), compact = true) { vm.confirmedFbCmd("flashing unlock") }
                    ConfirmBtn("UNLOCK (legacy oem unlock)", "Send the legacy 'oem unlock' command and erase all data?", fb, mod = Modifier.weight(1f), compact = true) { vm.confirmedFbCmd("oem unlock") }
                }
            }
            Panel("GOOD TO KNOW", true, R.drawable.b_shield, gUnlock, true) {
                NoteTable(listOf(
                    "Before" to "Turn on OEM unlocking in Developer options. Confirm on the phone's screen when asked.",
                    "May refuse" to "Xiaomi, Huawei and carrier models often block this command.",
                    "Relock" to "Disabled. The app cannot prove every flashed partition is stock-compatible, so never lock after modified firmware."
                ), gUnlock)
            }
            }
        }

        // ---------------- CUSTOM ROM ----------------
        1 -> {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                Panel("SLOT CONTROLS", true, R.drawable.b_slot, gRom, true) {
                SlotButtons(vm, fb, true)
                T("Create and manage backups from the dedicated BACKUP page.", C.dim, 10)
            }
            Panel("RECOVERY IMAGE", true, R.drawable.b_image, gRom, true) {
                Field(recPart, { recPart = it }, "Target partition")
                FilePick("CHOOSE RECOVERY IMAGE", rec) { rec = it; recHash = "" }
                Field(recHash, { recHash = it }, hashLabel)
                Rw {
                    Btn("VERIFY RECOVERY IMAGE", !vm.busy && rec != null && recHash.isNotBlank(), mod = Modifier.weight(1f), compact = true) { vm.verifyStandaloneImage(rec!!, recHash) }
                    ConfirmBtn("FLASH RECOVERY", "Flash this verified image to '$recPart'?", fb && rec != null && vm.isImageVerified(rec) && vm.safetyWarningsAcknowledged, mod = Modifier.weight(1f), compact = true) { vm.flashOne(recPart, rec!!) }
                }
                Verdict(vm.isImageVerified(rec))
            }
            Panel("WIPE AND BOOT RECOVERY", true, R.drawable.b_recovery, gRom, true) {
                Rw {
                    ConfirmBtn("WIPE USERDATA (optional)", "Erase userdata and metadata on the connected phone?", fb, mod = Modifier.weight(1f), compact = true) { vm.wipe() }
                    Btn("REBOOT TO RECOVERY", fb, mod = Modifier.weight(1f), compact = true) { vm.fbCmd("reboot-recovery") }
                }
            }
            Panel("ROM ZIP (SIDELOAD)", true, R.drawable.b_upload, gRom, true) {
                T("Experimental. The phone must show the recovery's ADB sideload screen.", C.amber, 11)
                FilePick("CHOOSE ROM ZIP", rom) { rom = it; romHash = "" }
                Field(romHash, { romHash = it }, hashLabel)
                Btn("SIDELOAD ROM", adb && rom != null && romHash.matches(hex64), compact = true) { vm.sideload(rom!!, romHash) }
            }
            Panel("EXTRA ZIP (GAPPS, ADD-ONS)", false, R.drawable.b_zip, gRom, true) {
                T("Experimental. Start 'Apply update from ADB' again before each ZIP.", C.amber, 11)
                FilePick("CHOOSE EXTRA ZIP", extra) { extra = it; extraHash = "" }
                Field(extraHash, { extraHash = it }, hashLabel)
                Btn("SIDELOAD EXTRA", adb && extra != null && extraHash.matches(hex64), compact = true) { vm.sideload(extra!!, extraHash) }
            }
            Panel("GOOD TO KNOW", true, R.drawable.b_shield, gRom, true) {
                NoteTable(listOf(
                    "Order" to "Slot, backup, recovery, wipe, boot recovery, ROM ZIP, extra ZIP.",
                    "Needs" to "Unlocked bootloader, data cable, charged phones, and the publisher SHA-256 of every file.",
                    "A/B phones" to "The recovery may live in boot or vendor_boot. Set the partition name in Recovery image.",
                    "On the phone" to "Choose Apply update, then Apply update from ADB. The app switches to ADB mode when it sees the recovery.",
                    "Extra ZIPs" to "Each package is checksum-verified on its own. Finish with Reboot system now on the phone.",
                    "Sideload" to "Not hardware-tested. Check package compatibility using the OEM's instructions.",
                    "Backup" to "Also back up boot (or init_boot) before rooting."
                ), gRom)
            }
            }
        }

        // ---------------- ROOT ----------------
        2 -> {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Panel("PATCHED BOOT IMAGE", true, R.drawable.b_bolt, gRoot, true) {
                T("Patch the stock boot (or init_boot) image with Magisk first.", C.amber, 11)
                Field(bootPart, { bootPart = it }, "Target partition (boot or init_boot)")
                FilePick("CHOOSE PATCHED IMAGE", boot) { boot = it; bootHash = "" }
                Field(bootHash, { bootHash = it }, hashLabel)
                Rw {
                    Btn("VERIFY PATCHED IMAGE", !vm.busy && boot != null && bootHash.isNotBlank(), mod = Modifier.weight(1f), compact = true) { vm.verifyStandaloneImage(boot!!, bootHash) }
                    ConfirmBtn("FLASH PATCHED IMAGE", "Flash this verified image to '$bootPart'?", fb && boot != null && vm.isImageVerified(boot) && vm.safetyWarningsAcknowledged, mod = Modifier.weight(1f), compact = true) { vm.flashOne(bootPart, boot!!) }
                }
                Verdict(vm.isImageVerified(boot))
            }
            Panel("REBOOT AND CHECK", true, R.drawable.b_power, gRoot, true) {
                Btn("REBOOT SYSTEM", fb, compact = true) { vm.fbCmd("reboot") }
            }
            Panel("GOOD TO KNOW", true, R.drawable.b_shield, gRoot, true) {
                NoteTable(listOf(
                    "Needs" to "Unlocked bootloader (see the status at the top).",
                    "Confirm root" to "After the reboot, open the Magisk app on the phone.",
                    "Vbmeta" to "Not flashed by this app. Verified Boot is never switched off silently.",
                    "Backup" to "Back up boot (or init_boot) first, on the ROM tab."
                ), gRoot)
            }
            }
        }
        // ---------------- PARTITION TOOLS (inside ROM & ROOT) ----------------
        else -> {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Panel("PARTITION TOOLS", true, R.drawable.ic_part, C.blue, true) {
                T("Partition inspection, backup and guarded logical-partition tools are grouped here. No separate bottom-navigation page is used.", C.dim, 11)
            }
            PartPage(vm, selectedPartTab, onPartTabChange)
            }
        }
        }
    }
}
}

@Composable
fun LogPage(
    vm: MainVM,
    filterErrors: Boolean = false,
    onFilterToggle: () -> Unit = {},
    onCopy: () -> Unit = {}
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("DEVICE DATABASE (${vm.dbInfo})", true, R.drawable.ff_master_icon_03, C.blue) {
            Field(vm.dbUrl, { vm.dbUrl = it }, "Raw GitHub URL of devices.json")
            Btn("UPDATE DATABASE", !vm.busy) { vm.updateDb(vm.dbUrl) }
        }
        Panel("USB LOG (${vm.logs.size})", true, R.drawable.ff_master_icon_04, C.blue) {
        Rw {
            Btn("SAVE", mod = Modifier.weight(1f), compact = true) { vm.saveLog() }
            Btn("COPY", mod = Modifier.weight(1f), compact = true) { onCopy() }
            Btn(if (filterErrors) "FILTER: ERRORS" else "FILTER: ALL", mod = Modifier.weight(1f), compact = true) { onFilterToggle() }
        }
        Rw {
            Btn("EXPORT", mod = Modifier.weight(1f), compact = true) { vm.exportLog() }
            ConfirmBtn("CLEAR LOG", "Permanently clear the event log stored in this app?", true, true, Modifier.weight(1f), compact = true) { vm.logs.clear() }
        }
        Spacer(Modifier.height(6.dp))
        val visibleLogs = vm.logs.toList().filter { entry ->
            !filterErrors || entry.contains("error", true) || entry.contains("fail", true) || entry.contains("blocked", true)
        }
        T(if (filterErrors) "FILTER: ERRORS / FAILURES / BLOCKED" else "FILTER: ALL EVENTS", C.blue, 10, true)
        if (visibleLogs.isEmpty()) T("No matching log entries.", C.dim, 11)
        visibleLogs.asReversed().forEach { T(it, C.text, 11, mod = Modifier.padding(vertical = 2.dp)) }
        }
    }
}

@Composable
fun SafetyPage(vm: MainVM, onOpenQueue: () -> Unit = { vm.screen = Screen.ROM }) {
    var readMore by remember { mutableStateOf(false) }
    val battery = vm.safetyBatteryPercent()
    val storage = vm.fwDir().usableSpace
    val identityOk = vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN && vm.product.isNotBlank() && vm.expected.isNotBlank() && vm.expected.equals(vm.product, true)
    val queueOk = vm.queue.isNotEmpty() && vm.queue.all { item ->
        item.part.matches(Regex("[A-Za-z0-9_]{1,48}")) && vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null
    }
    val effectiveStatus = if (!identityOk || battery == null || battery < AppSettings.minBattery) "BLOCKED" else vm.analyzerStatus
    val statusColor = when (effectiveStatus) {
        "PASS" -> C.green
        "BLOCKED" -> C.red
        else -> C.amber
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("PRE-FLASH SAFETY ANALYZER", true, R.drawable.ff_master_icon_05, C.blue) {
            T(effectiveStatus, statusColor, 18, true)
            T(vm.analyzerMessage, C.dim, 11)
            T("The analyzer is automatically invoked before every image-flash transport. Opening this page is not a substitute for the mandatory gate.", C.amber, 11)
        }
        Panel("SAFETY ACTIONS", true, R.drawable.ff_master_icon_05, C.blue) {
            Btn(if (vm.safetyWarningsAcknowledged) "WARNINGS ACKNOWLEDGED" else "ACKNOWLEDGE WARNINGS", !vm.busy, mod = Modifier.fillMaxWidth(), compact = true) { vm.acknowledgeSafetyWarnings() }
            Btn("CLEAR ACK", !vm.busy, mod = Modifier.fillMaxWidth(), compact = true) { vm.clearSafetyWarningAcknowledgement() }
            Btn("OPEN ROM FLASH QUEUE", true, mod = Modifier.fillMaxWidth(), icon = R.drawable.ic_stack, compact = true) { onOpenQueue() }
            if (vm.canResumeInterruptedFlash()) ConfirmBtn("RESUME INTERRUPTED FLASH", "Re-verify the interrupted image and target, then restart this image from the beginning?", !vm.busy, true, Modifier.fillMaxWidth(), compact = true) { vm.resumeInterruptedFlash() }
            Btn(if (readMore) "READ LESS" else "READ MORE — SAFETY DETAILS", true, mod = Modifier.fillMaxWidth(), compact = true) { readMore = !readMore }
        }
        if (readMore) {
            Panel("FIRMWARE TRUST & COMPATIBILITY", true, R.drawable.ff_master_icon_10, C.blue) {
                val compatibility = FirmwareTrustAudit.assessCompatibility(
                    detectedModel = vm.product.ifBlank { vm.modelName },
                    expectedModel = vm.expected,
                    detectedRegion = null,
                    expectedRegion = null,
                    detectedChipset = vm.chip,
                    expectedChipset = null
                )
                T(compatibility.status.name, when (compatibility.status) { FirmwareTrustAudit.Status.PASS -> C.green; FirmwareTrustAudit.Status.WARNING -> C.amber; FirmwareTrustAudit.Status.BLOCKED -> C.red }, 12, true)
                T(compatibility.message, C.dim, 11)
                T("Firmware source and publisher signature are not independently authenticated by this report. A supplied SHA-256 can verify file bytes against that digest only; it does not prove who published the digest.", C.amber, 11)
                T("Compatibility evidence: exact product identity is checked where available. Region, chipset variant, bootloader revision and OEM release metadata may remain unknown; unknown is never treated as PASS.", C.dim, 11)
            }
            Panel("FIRMWARE AND PARTITION", false, R.drawable.ff_master_icon_17, C.blue) {
                KV("Flash queue", if (vm.queue.isEmpty()) "No queued images" else "${vm.queue.size} image(s)")
                KV("Queue SHA-256", if (queueOk) "Verified for queued items" else if (vm.queue.isEmpty()) "Standalone image paths verify separately" else "Missing / not verified")
                vm.queue.forEach { item ->
                    T("${item.name} → ${item.part.ifBlank { "PARTITION NOT SELECTED" }} (${item.size} bytes)", C.text, 11)
                    T(if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) "Publisher checksum matched; file is re-hashed before transfer" else "BLOCKED: publisher checksum verification required", if (vm.verifiedFirmware[item.uri.toString() + "|" + item.size] != null) C.green else C.red, 10)
                }
                T("Every image needs an explicit partition. Slot, logical/physical type and actual partition capacity are queried again from the bootloader immediately before transfer.", C.amber, 11)
            }
            Panel("CONTROLLER PHONE HEALTH", false, R.drawable.ff_master_icon_01, C.green) {
                KV("Controller phone battery", battery?.let { "$it%" } ?: "Unavailable")
                KV("Minimum threshold", "${AppSettings.minBattery}% (never below ${AppSettings.MIN_BATTERY_FLOOR}%)")
                KV("Firmware storage free", "${storage / (1024 * 1024)} MB")
                T("This battery value belongs to the FlashForge controller phone, not the connected target phone. Target battery is not assumed.", C.dim, 10)
                if (battery == null || battery < AppSettings.minBattery) T("BLOCKED: controller battery is unavailable or below ${AppSettings.minBattery}%.", C.red, 11, true)
            }
            Panel("WARNINGS — REVIEW BEFORE FLASHING", true, R.drawable.ff_master_icon_05, C.amber) {
                vm.analyzerWarnings.forEach { T("• $it", C.amber, 11, mod = Modifier.padding(vertical = 3.dp)) }
                T(if (vm.safetyWarningsAcknowledged) "Warnings acknowledged for this connected-device session. They remain visible and the result remains WARNING." else "Warnings are not treated as PASS. Explicit acknowledgement is required before the first image write in this session.", C.dim, 11)
            }
            Panel("LAST ANALYZER CHECKS", false, R.drawable.ff_master_icon_10, C.blue) {
                if (vm.analyzerChecks.isEmpty()) T("No image preflight has run in this session yet. The first flash attempt will run it automatically.", C.dim, 11)
                vm.analyzerChecks.forEach { T(it, if (it.startsWith("PASS")) C.green else if (it.startsWith("BLOCKED")) C.red else C.amber, 10, mod = Modifier.padding(vertical = 2.dp)) }
            }
            Panel("USB AND RECOVERY", false, R.drawable.ff_master_icon_13, C.blue) {
                KV("USB state", vm.link.label)
                T("If USB disconnects during a flash, reconnect and identify the target again. Resume restarts the interrupted current image from byte zero after file hash, identity, slot, mode, capacity and battery checks; it does not continue an arbitrary partial USB byte offset.", C.dim, 11)
            }
            Panel("SAFETY DECISION", true, R.drawable.ff_master_icon_05, C.green) {
                T(when (effectiveStatus) {
                    "PASS" -> "PASS — implemented pre-flash checks passed"
                    "BLOCKED" -> "BLOCKED — DO NOT FLASH"
                    else -> "WARNING — REVIEW AND ACKNOWLEDGE; WARNINGS REMAIN"
                }, statusColor, 14, true)
                T("A PASS is not a guarantee against unknown hardware, firmware, or vendor-specific risks. A WARNING never becomes a silent PASS.", C.dim, 11)
            }
        }
    }
}

/** Dedicated reset/repair landing page. It intentionally exposes only verified workflows. */
@Composable
fun ResetRepairPage(vm: MainVM, onOpenRomTools: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("RESET & REPAIR CENTER", false, R.drawable.ic_rescue, C.blue) {
            KV("Connection", vm.link.label)
            KV("Detected mode", vm.mode.label)
            KV("Verified model", vm.modelName.ifBlank { "Not verified" })
            T("Choose a supported recovery workflow. Destructive reset/erase operations remain behind device-identity, compatibility and explicit confirmation checks.", C.dim, 11)
        }
        Panel("AVAILABLE SAFE WORKFLOWS", true, R.drawable.ic_verify, C.green) {
            T("• Reboot to a supported boot mode from the Device page mode controls", C.text, 11)
            T("• Review device identity and connection diagnostics", C.text, 11)
            T("• Open the existing ROM & ROOT tools for verified Fastboot operations", C.text, 11)
            T("Factory reset / userdata erase is not presented as a one-tap action here. It must be explicitly confirmed for the exact connected device.", C.amber, 11, true)
            Btn("OPEN ROM & ROOT TOOLS", !vm.busy) { onOpenRomTools() }
        }
        Panel("DEVICE-COMPATIBLE CLEAN FLASH", true, R.drawable.ic_rescue, C.amber) {
            val selected = vm.queue.filter { it.enabled }
            val queueMappedAndVerified = selected.isNotEmpty() && selected.all { it.part.isNotBlank() && vm.isImageVerified(it.uri) }
            T("Backs up each selected target partition where supported, erases userdata (and metadata only when confirmed present), then flashes only the selected, checksum-verified images. It does not erase protected calibration/identity partitions and is not universal across all phones.", C.dim, 10)
            KV("Selected firmware images", selected.size.toString())
            ConfirmBtn("RUN DEVICE-COMPATIBLE CLEAN FLASH", "This will create required pre-flash backups, erase user data, and flash the selected verified images. This is destructive. Continue only on a device you own or are authorized to service.", vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN && !vm.busy && queueMappedAndVerified && vm.safetyWarningsAcknowledged, true) { vm.cleanFlash() }
            if (!queueMappedAndVerified) T("BLOCKED: open FLASH > QUEUE, add images, assign every partition, and verify each publisher SHA-256 first.", C.amber, 10)
        }
        Panel("REPAIR LIMITATIONS", false, R.drawable.ic_shield, C.amber) {
            T("FRP, account locks, screen locks and security controls are not bypassed. Repair support is limited to owner-authorized, manufacturer-supported procedures.", C.dim, 11)
        }
    }
}

@Composable
fun ChipsetHubPage(vm: MainVM) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("CHIPSET SERVICE CENTER", false, R.drawable.ic_chip_bolt, C.blue) {
            KV("Connected mode", vm.mode.label)
            KV("Chipset hint", vm.chip.ifBlank { "Not identified" })
            T("Detection does not mean the phone is ready to be flashed. Each chipset needs its own verified transport, exact model-matched authorized loader and protocol implementation.", C.amber, 11, true)
        }
        ChipsetFlashEngines.engines.forEach { engine ->
            Panel(engine.title.uppercase(), true, R.drawable.ic_chip_bolt, C.blue) {
                KV("Transport", engine.transport)
                KV("Required authorization", engine.requirements)
                KV("Current capability", "Mode detection only")
                KV("Write engine", if (engine.writeEnabled) "Enabled" else "Not implemented / locked")
                T("FlashForge will not run generic loaders, bypass secure boot/authentication, or write firmware using an unverified cross-model file.", C.dim, 10)
            }
        }
    }
}

@Composable
fun BackupHubPage(vm: MainVM, onOpenRomTools: () -> Unit) {
    var partition by remember { mutableStateOf("boot") }
    var refreshKey by remember { mutableStateOf(0) }
    val backups = remember(refreshKey, vm.link, vm.product) { vm.backupFiles() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Panel("BACKUP & RESTORE CENTER", false, R.drawable.ic_save, C.blue) {
            KV("Device", vm.modelName.ifBlank { "Not identified" })
            KV("Product", vm.product.ifBlank { "Not verified" })
            KV("Connection", vm.link.label)
            KV("Mode", vm.mode.label)
        }
        Panel("AUTOMATIC PRE-FLASH BACKUP", true, R.drawable.ic_verify, C.green) {
            T(if (vm.autoPreFlashBackup) "ON — every image write first attempts a verified backup of its target partition. If the device cannot provide a verified read, flashing stops." else "OFF — no automatic target-partition snapshot is attempted for normal flash operations.", if (vm.autoPreFlashBackup) C.green else C.amber, 11, true)
            Btn(if (vm.autoPreFlashBackup) "TURN AUTOMATIC BACKUP OFF" else "TURN AUTOMATIC BACKUP ON", !vm.busy, compact = true) { vm.setAutoPreFlashBackupEnabled(!vm.autoPreFlashBackup) }
            T("Clean Flash always requires a verified pre-flash backup regardless of this optional setting.", C.dim, 10)
        }
        Panel("CREATE PARTITION BACKUP", true, R.drawable.ic_upload, C.green) {
            T("Backups require a verified device identity and supported Fastboot read capability. Slot-aware partitions may require an explicit _a or _b suffix.", C.dim, 11)
            Field(partition, { partition = it }, "Partition name, e.g. boot_a")
            Btn("CREATE BACKUP", !vm.busy && vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN && partition.matches(Regex("[A-Za-z0-9_]{1,48}"))) {
                vm.backup(partition.trim())
                refreshKey++
            }
        }
        Panel("LOCAL VERIFIED BACKUPS (${backups.size})", true, R.drawable.ic_verify, C.blue) {
            if (backups.isEmpty()) T("No complete backup with metadata found yet.", C.dim, 11)
            backups.forEach { file ->
                Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    T(file.name, C.text, 11, true)
                    T("${file.length() / 1024 / 1024} MB · metadata sidecar present", C.dim, 10)
                    Btn("RESTORE THIS BACKUP", !vm.busy && vm.mode == Mode.FASTBOOT && vm.link == Link.GREEN) { vm.restoreBackup(file) }
                }
            }
            T("Restore re-checks product, partition, file size and SHA-256 before using the guarded Fastboot flash path. A local backup is not an OEM-signed firmware package.", C.amber, 10)
        }
        Panel("MORE PARTITION TOOLS", false, R.drawable.ic_stack, C.blue) {
            Btn("OPEN ROM & ROOT PARTITION TOOLS", !vm.busy) { onOpenRomTools() }
        }
    }
}
