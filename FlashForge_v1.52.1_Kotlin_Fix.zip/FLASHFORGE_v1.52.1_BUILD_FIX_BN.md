# FlashForge v1.52.1 — Kotlin Build Fix

- Fixed Kotlin JVM platform declaration clash in `MainVM`.
- Renamed the explicit preference method from `setAutoPreFlashBackup` to `setAutoPreFlashBackupEnabled`.
- Updated the Backup page call site to use the renamed method.
- Bumped Android version to 1.52.1 (versionCode 20).
- The Kotlin property `autoPreFlashBackup` remains unchanged; its generated setter no longer conflicts with the explicit method.

This source fix addresses the compiler diagnostic from GitHub Actions. A successful Android build still needs to be confirmed by running GitHub Actions.
